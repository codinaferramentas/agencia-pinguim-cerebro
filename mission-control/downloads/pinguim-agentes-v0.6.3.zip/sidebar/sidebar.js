// Pinguim Agentes — Sidebar logic
import { gerarAvatarDataUri } from './pinguim-avatar.js';

const SUPABASE_URL = 'https://wmelierxzpjamiofeemh.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndtZWxpZXJ4enBqYW1pb2ZlZW1oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMyMzY5MzQsImV4cCI6MjA4ODgxMjkzNH0.kbzLkX7yDmNfT_wJ00M4KKphTgyc0QXaVpaplO0i-jk';

const conteudo = document.getElementById('conteudo');
const rodapeStatus = document.getElementById('rodape-status');
const rodapeUsuario = document.getElementById('rodape-usuario');
const rodapeVersao = document.getElementById('rodape-versao');
const btnFixar = document.getElementById('btn-fixar');
const btnFechar = document.getElementById('btn-fechar');
const btnAtualizar = document.getElementById('btn-atualizar');

// Mostra versao da extensao no rodape
try {
  const m = chrome.runtime.getManifest();
  if (rodapeVersao) rodapeVersao.textContent = 'v' + m.version;
} catch (_) {}

let session = null;            // { access_token, user, expira_em }
let agentesCache = null;
let squadsCache = null;
let conversaAtual = null;      // { agente, mensagens: [], conversa_id? }
let textoPendente = null;      // vindo do menu de contexto

// ============== STORAGE HELPERS ==============
function storageGet(keys) {
  return new Promise(r => chrome.storage.local.get(keys, r));
}
function storageSet(obj) {
  return new Promise(r => chrome.storage.local.set(obj, r));
}
function storageRemove(keys) {
  return new Promise(r => chrome.storage.local.remove(keys, r));
}

// ============== FETCH PROXY (passa por service worker) ==============
function fetchProxy(url, options) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { tipo: 'FETCH_PROXY', url, options },
      (resp) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!resp) return reject(new Error('Sem resposta do service worker'));
        resolve(resp);
      }
    );
  });
}

// ============== SUPABASE AUTH ==============
async function loginSupabase(email, senha) {
  const r = await fetchProxy(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: senha }),
  });
  if (!r.ok) {
    const msg = r.body?.error_description || r.body?.msg || r.body?.error || 'Erro de login';
    throw new Error(msg);
  }
  return {
    access_token: r.body.access_token,
    refresh_token: r.body.refresh_token,
    user: r.body.user,
    expira_em: Date.now() + (r.body.expires_in * 1000),
  };
}

async function refreshSession() {
  if (!session?.refresh_token) return null;
  const r = await fetchProxy(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: 'POST',
    headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: session.refresh_token }),
  });
  if (!r.ok) return null;
  return {
    access_token: r.body.access_token,
    refresh_token: r.body.refresh_token,
    user: r.body.user,
    expira_em: Date.now() + (r.body.expires_in * 1000),
  };
}

async function carregarSessao() {
  const data = await storageGet(['session']);
  if (!data.session?.access_token) return;
  session = data.session;
  // Se expirou ou expira em <5min, tenta refresh
  if (session.expira_em && session.expira_em < Date.now() + 5 * 60000) {
    const nova = await refreshSession();
    if (nova) {
      session = nova;
      await storageSet({ session });
    } else {
      // Refresh falhou: tenta usar token atual (pode ainda funcionar) ou limpa
      if (!session.expira_em || session.expira_em < Date.now()) {
        session = null;
        await storageRemove('session');
      }
    }
  }
}

// Garante session valida antes de cada chamada autenticada. Renova se expirou.
async function garantirSessaoValida() {
  if (!session?.access_token) return false;
  if (session.expira_em && session.expira_em < Date.now() + 60000) {
    const nova = await refreshSession();
    if (nova) {
      session = nova;
      await storageSet({ session });
      return true;
    } else {
      session = null;
      await storageRemove('session');
      return false;
    }
  }
  return true;
}

async function logout() {
  if (session?.access_token) {
    try {
      await fetchProxy(`${SUPABASE_URL}/auth/v1/logout`, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
        },
      });
    } catch (_) {}
  }
  session = null;
  agentesCache = null;
  conversaAtual = null;
  await storageRemove(['session']);
  renderLogin();
}

// ============== SUPABASE REST (pinguim schema) ==============
async function sbSelect(tabela, query = '') {
  if (!(await garantirSessaoValida())) throw new Error('Sessao expirou — faca login novamente');
  const url = `${SUPABASE_URL}/rest/v1/${tabela}${query ? '?' + query : ''}`;
  const r = await fetchProxy(url, {
    method: 'GET',
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${session.access_token}`,
      'Accept-Profile': 'pinguim',
    },
  });
  if (!r.ok) throw new Error(r.body?.message || 'Erro ao consultar ' + tabela);
  return r.body;
}

async function carregarAgentesESquads() {
  if (agentesCache && squadsCache) return { agentes: agentesCache, squads: squadsCache };
  const [agentes, squads, execucoes] = await Promise.all([
    sbSelect('agentes', 'select=id,slug,nome,avatar,cor,status,modelo,missao,proposito,squad_id,system_prompt,ferramentas&status=eq.em_producao&order=nome.asc'),
    sbSelect('squads', 'select=id,slug,nome,emoji&order=slug.asc'),
    sbSelect('agente_execucoes', 'select=agente_id&order=executado_em.desc&limit=500').catch(() => []),
  ]);
  // Conta execucoes por agente
  const contaExec = new Map();
  for (const e of (execucoes || [])) {
    if (!e.agente_id) continue;
    contaExec.set(e.agente_id, (contaExec.get(e.agente_id) || 0) + 1);
  }
  // Anexa contagem em cada agente
  agentes.forEach(a => { a._execs = contaExec.get(a.id) || 0; });
  agentesCache = agentes;
  squadsCache = squads;
  return { agentes, squads };
}

// Cor consistente por squad (hash do slug -> paleta)
function corDaSquad(squadSlug) {
  const paleta = ['#FF6B35', '#22c55e', '#3b82f6', '#eab308', '#a855f7', '#06b6d4', '#ec4899', '#14b8a6', '#f59e0b', '#8b5cf6', '#ef4444', '#10b981'];
  if (!squadSlug) return '#888';
  let hash = 0;
  for (let i = 0; i < squadSlug.length; i++) hash = (hash * 31 + squadSlug.charCodeAt(i)) >>> 0;
  return paleta[hash % paleta.length];
}

// Iniciais do nome (até 2 chars)
function iniciaisDoNome(nome) {
  if (!nome) return '?';
  const palavras = nome.trim().split(/\s+/);
  if (palavras.length === 1) return palavras[0].slice(0, 2).toUpperCase();
  return (palavras[0][0] + palavras[palavras.length - 1][0]).toUpperCase();
}

// ============== EDGE FUNCTION: conversar com agente ==============
async function conversarComAgente(agenteSlug, mensagem, anexo = null) {
  if (!(await garantirSessaoValida())) throw new Error('Sessao expirou — faca login novamente');
  const url = `${SUPABASE_URL}/functions/v1/agente-executar`;
  const contextoExtra = {};
  if (anexo?.tipo === 'imagem') contextoExtra.imagem_data_uri = anexo.data;
  // cliente_id = user.id real do logado, pra memoria conversacional por (user, agente).
  // Se nao tiver user.id por algum motivo, cai pro placeholder antigo (sem memoria).
  const clienteId = session.user?.id || '00000000-0000-0000-0000-000000000000';
  const body = {
    agente_slug: agenteSlug,
    tenant_id: '00000000-0000-0000-0000-000000000000',
    cliente_id: clienteId,
    solicitante_id: session.user?.email || session.user?.id || 'extensao-chrome',
    briefing: mensagem,
    contexto_extra: Object.keys(contextoExtra).length > 0 ? contextoExtra : undefined,
  };
  const r = await fetchProxy(url, {
    method: 'POST',
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(r.body?.detalhe || r.body?.error || 'Erro na execucao do agente');
  return r.body;
}

// Whisper API — recebe blob de audio, devolve texto
async function transcreverAudio(blob) {
  if (!(await garantirSessaoValida())) throw new Error('Sessao expirou');
  // Service worker faz o multipart pra OpenAI.
  // Converte ArrayBuffer -> base64 em chunks de 8KB pra nao estourar call stack
  // (spread `...new Uint8Array(buf)` quebra com audio > ~60KB = ~3 segundos)
  const buf = await blob.arrayBuffer();
  const bytes = new Uint8Array(buf);
  let binario = '';
  const CHUNK = 0x8000; // 32KB
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binario += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  const b64 = btoa(binario);
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { tipo: 'WHISPER_TRANSCRIBE', audioBase64: b64, mimeType: blob.type },
      (resp) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!resp?.ok) return reject(new Error(resp?.erro || 'Whisper falhou'));
        resolve(resp.texto);
      }
    );
  });
}

// ============== MEMORIA CONVERSACIONAL ==============
// Lê últimas N mensagens dessa thread (user, agente) direto do Supabase via PostgREST.
// Retorna no formato { papel, texto, meta? } pra hidratar conversaAtual.mensagens.
async function carregarHistoricoDoBanco(agente) {
  if (!session?.access_token || !session?.user?.id) return [];
  try {
    // Acha id do agente pelo slug (pode usar agente.id se a sidebar carregar)
    const agenteId = agente.id;
    if (!agenteId) return [];
    const url = `${SUPABASE_URL}/rest/v1/conversas?select=papel,conteudo,criado_em&cliente_id=eq.${session.user.id}&agente_id=eq.${agenteId}&caso_id=is.null&order=criado_em.desc&limit=20`;
    const r = await fetchProxy(url, {
      method: 'GET',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        'Accept-Profile': 'pinguim',
      },
    });
    if (!r.ok || !Array.isArray(r.body)) return [];
    // r.body veio em ordem DESC; reverte pra cronologica
    const arr = [...r.body].reverse();
    // banco usa CHECK: 'humano'|'chief'|'sistema'|'worker' — UI usa 'usuario'|'agente'
    return arr.map(m => ({
      papel: m.papel === 'humano' ? 'usuario' : 'agente',
      texto: m.conteudo || '',
    }));
  } catch (e) {
    console.warn('[carregarHistoricoDoBanco] erro:', e?.message);
    return [];
  }
}

// Apaga todas as mensagens dessa thread (user, agente).
// Hoje DELETE direto via PostgREST — RLS precisa permitir o user apagar suas proprias linhas.
async function limparHistoricoConversa(agenteSlug) {
  if (!session?.access_token || !session?.user?.id) return { ok: false, erro: 'nao logado' };
  try {
    // Resolve agente_id
    const r1 = await fetchProxy(`${SUPABASE_URL}/rest/v1/agentes?select=id&slug=eq.${agenteSlug}`, {
      method: 'GET',
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Accept-Profile': 'pinguim' },
    });
    if (!r1.ok || !Array.isArray(r1.body) || r1.body.length === 0) return { ok: false, erro: 'agente nao achado' };
    const agenteId = r1.body[0].id;
    // DELETE — precisa Content-Profile pra PostgREST achar a tabela no schema pinguim em modificacoes
    const r2 = await fetchProxy(`${SUPABASE_URL}/rest/v1/conversas?cliente_id=eq.${session.user.id}&agente_id=eq.${agenteId}`, {
      method: 'DELETE',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        'Accept-Profile': 'pinguim',
        'Content-Profile': 'pinguim',
        Prefer: 'return=minimal',
      },
    });
    if (!r2.ok && r2.status !== 204) return { ok: false, erro: r2.body?.message || `HTTP ${r2.status}` };
    return { ok: true };
  } catch (e) {
    return { ok: false, erro: e?.message || 'falha' };
  }
}

// ============== MODAIS PROPRIOS (substituem confirm/alert do browser) ==============
// Retorna Promise<boolean>: true se confirmou, false se cancelou
function mostrarConfirmacao({ titulo, mensagem, textoConfirmar = 'Confirmar', textoCancelar = 'Cancelar', destrutivo = false }) {
  return new Promise(resolve => {
    document.querySelectorAll('.modal-pinguim').forEach(m => m.remove());

    const overlay = el('div', { class: 'modal-pinguim' });
    const box = el('div', { class: 'modal-pinguim-box' });
    const tituloEl = el('h3', { class: 'modal-pinguim-titulo' }, titulo || 'Confirmar');
    const mensagemEl = el('p', { class: 'modal-pinguim-mensagem' }, mensagem || '');

    const btnCancelar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, textoCancelar);
    const btnConfirmar = el('button', {
      class: 'modal-pinguim-btn ' + (destrutivo ? 'modal-pinguim-btn-destrutivo' : 'modal-pinguim-btn-primary'),
      type: 'button',
    }, textoConfirmar);

    function fechar(valor) {
      overlay.remove();
      document.removeEventListener('keydown', onKey);
      resolve(valor);
    }
    function onKey(e) {
      if (e.key === 'Escape') fechar(false);
      if (e.key === 'Enter') fechar(true);
    }
    btnCancelar.addEventListener('click', () => fechar(false));
    btnConfirmar.addEventListener('click', () => fechar(true));
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fechar(false); });
    document.addEventListener('keydown', onKey);

    box.append(tituloEl, mensagemEl, el('div', { class: 'modal-pinguim-botoes' }, [btnCancelar, btnConfirmar]));
    overlay.append(box);
    document.body.append(overlay);
    setTimeout(() => btnConfirmar.focus(), 50);
  });
}

function mostrarAlerta({ titulo, mensagem, textoFechar = 'Fechar', tipo = 'info' }) {
  return new Promise(resolve => {
    document.querySelectorAll('.modal-pinguim').forEach(m => m.remove());

    const overlay = el('div', { class: 'modal-pinguim' });
    const box = el('div', { class: 'modal-pinguim-box' });
    const tituloEl = el('h3', { class: 'modal-pinguim-titulo modal-pinguim-titulo-' + tipo }, titulo || 'Aviso');
    const mensagemEl = el('p', { class: 'modal-pinguim-mensagem' }, mensagem || '');

    const btnFechar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, textoFechar);

    function fechar() {
      overlay.remove();
      document.removeEventListener('keydown', onKey);
      resolve();
    }
    function onKey(e) {
      if (e.key === 'Escape' || e.key === 'Enter') fechar();
    }
    btnFechar.addEventListener('click', fechar);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fechar(); });
    document.addEventListener('keydown', onKey);

    box.append(tituloEl, mensagemEl, el('div', { class: 'modal-pinguim-botoes' }, [btnFechar]));
    overlay.append(box);
    document.body.append(overlay);
    setTimeout(() => btnFechar.focus(), 50);
  });
}

// ============== FEEDBACK 👍/👎 ==============
async function enviarFeedback({ agente_slug, tipo, correcao, pergunta_usuario, resposta_agente }) {
  if (!session?.access_token) return { ok: false, erro: 'nao logado' };
  try {
    const url = `${SUPABASE_URL}/functions/v1/feedback-agente`;
    const body = { agente_slug, tipo, pergunta_usuario, resposta_agente };
    if (tipo === 'negativo') body.correcao = correcao;
    const r = await fetchProxy(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${session.access_token}`,
        apikey: SUPABASE_ANON_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
    if (!r.ok) return { ok: false, erro: r.body?.erro || `HTTP ${r.status}` };
    return r.body;
  } catch (e) {
    return { ok: false, erro: e.message };
  }
}

function abrirModalCorrecao({ agente, pergunta, resposta, onEnviado }) {
  // Remove modal anterior se houver
  document.querySelectorAll('.modal-feedback').forEach(m => m.remove());

  const overlay = el('div', { class: 'modal-feedback' });
  const box = el('div', { class: 'modal-feedback-box' });
  const titulo = el('h3', { style: 'margin:0 0 8px 0;font-size:14px' }, `👎 Feedback negativo — ${agente.nome}`);
  const subt = el('p', { style: 'margin:0 0 12px 0;color:var(--fg-muted);font-size:12px' },
    'O que estava errado nessa resposta? Seja específico — o agente vai ler isso e corrigir nas próximas vezes.');

  const textarea = el('textarea', {
    class: 'modal-feedback-textarea',
    placeholder: 'Ex: "esqueceu de mencionar X", "tom muito formal", "errou no cálculo", "deveria ter consultado Y antes"...',
    rows: '5',
  });

  const erroEl = el('div', { style: 'color:#ff6b6b;font-size:12px;min-height:16px;margin-top:6px' });

  const btnCancelar = el('button', { class: 'modal-feedback-btn', type: 'button' }, 'Cancelar');
  const btnEnviar = el('button', { class: 'modal-feedback-btn modal-feedback-btn-primary', type: 'button' }, 'Enviar correção');

  btnCancelar.addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });

  btnEnviar.addEventListener('click', async () => {
    const correcao = textarea.value.trim();
    if (correcao.length < 3) {
      erroEl.textContent = 'Escreve pelo menos 3 caracteres explicando o que estava errado.';
      return;
    }
    btnEnviar.disabled = true; btnEnviar.textContent = 'Enviando...';
    const r = await enviarFeedback({
      agente_slug: agente.slug, tipo: 'negativo', correcao,
      pergunta_usuario: pergunta, resposta_agente: resposta,
    });
    if (r.ok) {
      overlay.remove();
      onEnviado && onEnviado();
      if (r.alerta_excesso) {
        setTimeout(() => mostrarAlerta({
          titulo: 'Atenção: agente com problemas',
          mensagem: `Esse agente já tem ${r.negativos_ativos} feedbacks negativos ativos. Tá na hora de revisar a configuração dele.`,
          tipo: 'aviso',
        }), 200);
      }
    } else {
      erroEl.textContent = 'Erro: ' + (r.erro || 'desconhecido');
      btnEnviar.disabled = false; btnEnviar.textContent = 'Enviar correção';
    }
  });

  box.append(titulo, subt, textarea, erroEl, el('div', { class: 'modal-feedback-botoes' }, [btnCancelar, btnEnviar]));
  overlay.append(box);
  document.body.append(overlay);
  setTimeout(() => textarea.focus(), 50);
}

// ============== RENDER ==============
function el(tag, props = {}, children = []) {
  const n = document.createElement(tag);
  for (const k in props) {
    if (k === 'class') n.className = props[k];
    else if (k === 'html') n.innerHTML = props[k];
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), props[k]);
    else n.setAttribute(k, props[k]);
  }
  (Array.isArray(children) ? children : [children]).forEach(c => {
    if (c == null) return;
    n.append(c.nodeType ? c : document.createTextNode(String(c)));
  });
  return n;
}

function setStatus(texto) { rodapeStatus.textContent = texto; }
function setUsuario(texto) { rodapeUsuario.textContent = texto; }

// --------- TELA LOGIN ---------
function renderLogin() {
  conteudo.innerHTML = '';
  setUsuario('');
  setStatus('Faça login para continuar');

  const erroBox = el('div', { id: 'login-erro', style: 'display:none' });

  const inputEmail = el('input', { type: 'email', class: 'input-campo', placeholder: 'voce@agenciapinguim.com', autocomplete: 'username' });
  const inputSenha = el('input', { type: 'password', class: 'input-campo', placeholder: 'sua senha', autocomplete: 'current-password' });

  const botaoLogin = el('button', { class: 'botao-primario', type: 'button' }, 'Entrar');
  botaoLogin.addEventListener('click', async () => {
    erroBox.style.display = 'none';
    botaoLogin.disabled = true;
    botaoLogin.textContent = 'Entrando...';
    try {
      session = await loginSupabase(inputEmail.value.trim(), inputSenha.value);
      await storageSet({ session });
      await renderAgentes();
    } catch (e) {
      erroBox.style.display = 'block';
      erroBox.className = 'alerta-erro';
      erroBox.textContent = e.message || 'Falha no login';
    } finally {
      botaoLogin.disabled = false;
      botaoLogin.textContent = 'Entrar';
    }
  });

  // Enter envia
  [inputEmail, inputSenha].forEach(i => i.addEventListener('keydown', e => {
    if (e.key === 'Enter') botaoLogin.click();
  }));

  conteudo.append(
    el('div', { class: 'login-box' }, [
      el('div', { class: 'login-titulo' }, 'Pinguim Agentes'),
      el('div', { class: 'login-subtitulo' }, 'Acesso restrito ao time'),
      erroBox,
      el('div', { class: 'input-grupo' }, [
        el('label', { class: 'input-label' }, 'Email'),
        inputEmail,
      ]),
      el('div', { class: 'input-grupo' }, [
        el('label', { class: 'input-label' }, 'Senha'),
        inputSenha,
      ]),
      botaoLogin,
    ])
  );
}

// --------- TELA LISTA AGENTES ---------
let buscaTexto = '';
let squadFiltro = 'todas';
let buscaResultadoHibrido = null; // resultados ordenados da Edge Function quando busca ativa

async function renderAgentes() {
  conteudo.innerHTML = '';
  setUsuario(session?.user?.email || '');
  setStatus('Carregando agentes...');

  let agentes, squads;
  try {
    ({ agentes, squads } = await carregarAgentesESquads());
  } catch (e) {
    const msg = (e.message || '').toLowerCase();
    if (msg.includes('extension context invalidated') || msg.includes('receiving end does not exist')) {
      // Extensao foi atualizada, contexto da aba ficou orfao
      conteudo.innerHTML = '';
      const box = el('div', { class: 'login-box' }, [
        el('div', { class: 'login-titulo' }, '⚠ Extensão atualizada'),
        el('div', { class: 'login-subtitulo', style: 'margin-bottom:16px' },
          'A versão da extensão foi atualizada. Esta aba ainda está rodando a versão antiga.'),
        (() => {
          const btn = el('button', { class: 'botao-primario', type: 'button' }, '🔄 Recarregar a página');
          btn.addEventListener('click', () => {
            // Fala pro content script recarregar a pagina toda
            window.parent.postMessage({ pinguimTipo: 'RECARREGAR_PAGINA' }, '*');
          });
          return btn;
        })(),
        el('div', { class: 'login-subtitulo', style: 'margin-top:12px;font-size:11px' },
          'Ou aperte F5 manualmente.'),
      ]);
      conteudo.append(box);
      setStatus('Pagina precisa recarregar');
      return;
    }
    conteudo.append(el('div', { class: 'alerta-erro' }, 'Erro ao carregar agentes: ' + e.message));
    setStatus('Erro');
    return;
  }
  setStatus(`${agentes.length} agentes em produção`);

  const squadMap = new Map(squads.map(s => [s.id, s]));

  // Squad chips (filtro)
  const squadsComAgente = [...new Set(agentes.map(a => a.squad_id).filter(Boolean))]
    .map(id => squadMap.get(id))
    .filter(Boolean)
    .sort((a, b) => a.slug.localeCompare(b.slug));

  const chipsBox = el('div', { class: 'squad-selector' });
  const adicionaChip = (slug, nome, emoji) => {
    const chip = el('div', {
      class: 'squad-chip' + (squadFiltro === slug ? ' ativo' : ''),
    }, `${emoji || ''} ${nome}`.trim());
    chip.addEventListener('click', () => {
      squadFiltro = slug;
      buscaTexto = ''; // limpa busca ao trocar squad (evita conflito de filtros)
      renderAgentes();
    });
    chipsBox.appendChild(chip);
  };
  adicionaChip('todas', 'Todas');
  squadsComAgente.forEach(s => adicionaChip(s.slug, s.nome, s.emoji));

  // Busca
  const buscaInput = el('input', {
    type: 'text', class: 'busca-input',
    placeholder: 'Buscar: copy, email, hook, vsl, lançamento...',
    value: buscaTexto,
  });
  // Debounce pra busca híbrida (evita chamar API a cada tecla)
  let buscaTimer = null;
  buscaInput.addEventListener('input', (ev) => {
    buscaTexto = ev.target.value;
    if (buscaTimer) clearTimeout(buscaTimer);
    if (!buscaTexto.trim()) {
      // Limpou busca → re-render imediato (modo grupos)
      buscaResultadoHibrido = null;
      rerenderLista();
      return;
    }
    // Aguarda 350ms sem digitar antes de chamar API
    buscaTimer = setTimeout(async () => {
      try {
        await buscarHibrido(buscaTexto);
        rerenderLista();
      } catch (e) {
        console.warn('[busca] erro:', e.message);
        rerenderLista(); // cai no fallback textual
      }
    }, 350);
  });

  // Card destacado da Pinguim Triagem (porta de entrada opcional)
  const triagemAg = agentes.find(a => a.slug === 'pinguim-triagem');
  if (triagemAg) {
    const cardTriagem = el('div', { class: 'card-triagem' }, [
      el('img', {
        class: 'card-triagem-avatar',
        src: gerarAvatarDataUri('pinguim-triagem', 'agencia-pinguim'),
        alt: 'Pinguim Triagem',
      }),
      el('div', { class: 'card-triagem-conteudo' }, [
        el('div', { class: 'card-triagem-titulo' }, 'Não sabe qual agente usar?'),
        el('div', { class: 'card-triagem-sub' }, 'Conta o que precisa fazer — eu te indico.'),
      ]),
      el('span', { class: 'card-triagem-seta' }, '→'),
    ]);
    cardTriagem.addEventListener('click', () => {
      triagemAg._squad_slug = 'agencia-pinguim';
      renderChat(triagemAg);
    });
    conteudo.append(cardTriagem);
  }

  conteudo.append(
    el('div', { class: 'busca-agentes' }, buscaInput),
    chipsBox,
  );

  const listaBox = el('div', { id: 'lista-agentes' });
  conteudo.append(listaBox);

  function avatarUrl(slug, squadSlug) {
    // Gerador local SVG paramétrico (Pinguim Squad)
    return gerarAvatarDataUri(slug, squadSlug);
  }

  function renderAgenteItem(a, squadMap) {
    const sq = squadMap.get(a.squad_id);
    const squadSlug = sq?.slug;
    const avatarImg = el('img', {
      class: 'agente-item-avatar agente-item-avatar-img',
      src: avatarUrl(a.slug, squadSlug),
      alt: a.nome,
    });
    const item = el('div', { class: 'agente-item' }, [
      el('div', { class: 'agente-item-head' }, [
        avatarImg,
        el('div', { class: 'agente-item-nome' }, a.nome),
        (a._execs > 0)
          ? el('span', { class: 'agente-item-execs', title: `${a._execs} usos recentes` }, `${a._execs}×`)
          : null,
      ].filter(Boolean)),
      el('div', { class: 'agente-item-missao' }, a.missao || a.proposito || ''),
    ]);
    item.addEventListener('click', () => {
      // Anexa squad_slug no obj antes de passar pro chat (pra avatar no header)
      a._squad_slug = squadSlug;
      renderChat(a);
    });
    return item;
  }

  async function buscarHibrido(query) {
    if (!session?.access_token) return;
    try {
      const url = `${SUPABASE_URL}/functions/v1/tool-buscar-agente-hibrido`;
      const body = { query, top_k: 20 };
      if (squadFiltro !== 'todas') body.squad_slug = squadFiltro;
      const r = await fetchProxy(url, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        console.warn('[buscarHibrido] erro:', r.body?.erro || r.status);
        buscaResultadoHibrido = null;
        return;
      }
      // Cruza com lista local pra ter dados completos (_execs etc) — busca devolve slug
      const slugsRanked = (r.body.agentes || []).map(a => a.slug);
      const mapLocal = new Map(agentes.map(a => [a.slug, a]));
      buscaResultadoHibrido = slugsRanked
        .map(slug => mapLocal.get(slug))
        .filter(Boolean);
    } catch (e) {
      console.warn('[buscarHibrido] excecao:', e.message);
      buscaResultadoHibrido = null;
    }
  }

  function rerenderLista() {
    const q = buscaTexto.trim().toLowerCase();
    listaBox.innerHTML = '';

    // MODO BUSCA — usa resultado da Edge híbrida (ranqueado)
    if (q) {
      const filtrados = buscaResultadoHibrido
        || agentes.filter(a => {
          // Fallback textual local enquanto a Edge nao volta
          const hay = [a.nome, a.slug, a.missao, a.proposito].filter(Boolean).join(' ').toLowerCase();
          return hay.includes(q);
        });

      // Aplica filtro de squad se ativo (Edge ja filtra, mas no fallback nao)
      const visivel = filtrados.filter(a => {
        if (squadFiltro === 'todas') return true;
        const sq = squadMap.get(a.squad_id);
        return sq?.slug === squadFiltro;
      });

      if (visivel.length === 0) {
        listaBox.append(el('div', { class: 'alerta-erro', style: 'background:transparent;border:1px dashed var(--border);color:var(--fg-muted);text-align:center' },
          'Nenhum agente encontrado pra "' + q + '". Tenta outras palavras.'));
        return;
      }

      listaBox.append(el('div', { class: 'agente-grupo-titulo' }, `🔍 ${visivel.length} resultado${visivel.length === 1 ? '' : 's'}`));
      visivel.forEach(a => {
        listaBox.appendChild(renderAgenteItem(a, squadMap));
      });
      return;
    }

    // MODO LISTA — agrupa por squad (sem busca ativa)
    const filtrados = agentes.filter(a => {
      if (squadFiltro !== 'todas') {
        const sq = squadMap.get(a.squad_id);
        if (!sq || sq.slug !== squadFiltro) return false;
      }
      return true;
    });

    if (filtrados.length === 0) {
      listaBox.append(el('div', { class: 'alerta-erro', style: 'background:transparent;border:1px dashed var(--border);color:var(--fg-muted);text-align:center' }, 'Nenhum agente nessa squad.'));
      return;
    }

    // SECAO "MAIS USADOS" (so quando nao tem filtro de squad)
    if (squadFiltro === 'todas') {
      const topUsados = [...filtrados]
        .filter(a => (a._execs || 0) > 0)
        .sort((a, b) => (b._execs || 0) - (a._execs || 0))
        .slice(0, 5);
      if (topUsados.length > 0) {
        listaBox.append(el('div', { class: 'agente-grupo-titulo' }, '⭐ Mais usados'));
        topUsados.forEach(a => {
          listaBox.appendChild(renderAgenteItem(a, squadMap));
        });
      }
    }

    // Agrupa por squad
    const porSquad = new Map();
    for (const a of filtrados) {
      const sq = squadMap.get(a.squad_id);
      const key = sq ? sq.slug : '__sem_squad__';
      if (!porSquad.has(key)) porSquad.set(key, { squad: sq, agentes: [] });
      porSquad.get(key).agentes.push(a);
    }

    const ordem = [...porSquad.entries()].sort((x, y) => {
      if (x[0] === '__sem_squad__') return 1;
      if (y[0] === '__sem_squad__') return -1;
      return x[0].localeCompare(y[0]);
    });

    for (const [key, info] of ordem) {
      const titulo = info.squad ? `${info.squad.emoji || ''} ${info.squad.nome}` : '(Sem squad)';
      listaBox.append(el('div', { class: 'agente-grupo-titulo' }, titulo));
      info.agentes.forEach(a => {
        listaBox.appendChild(renderAgenteItem(a, squadMap));
      });
    }
  }

  rerenderLista();

  // Se ha texto pendente do context menu, abre seletor pra escolher agente
  if (textoPendente) {
    const aviso = el('div', { class: 'texto-selecionado' }, [
      el('div', { class: 'texto-selecionado-label' }, '📋 Texto selecionado pra revisar'),
      el('div', { class: 'texto-selecionado-corpo' }, textoPendente),
    ]);
    listaBox.insertBefore(aviso, listaBox.firstChild);
    listaBox.insertBefore(el('div', { class: 'agente-grupo-titulo' }, 'Escolha o agente que vai trabalhar nesse texto:'), aviso.nextSibling);
  }
}

// --------- TELA CHAT ---------
function renderChat(agente) {
  try {
    conteudo.innerHTML = '';
    setStatus(`Conversando com ${agente.nome}`);

    const continuarConversa = conversaAtual?.agente?.slug === agente.slug;
    conversaAtual = continuarConversa
      ? conversaAtual
      : { agente, mensagens: [] };

    const headerVoltar = el('button', { class: 'chat-voltar', type: 'button' }, '←');
    headerVoltar.addEventListener('click', () => {
      conversaAtual = null;
      renderAgentes();
    });

    const btnNovaConversa = el('button', {
      class: 'chat-nova-conversa',
      type: 'button',
      title: 'Começar conversa nova (esquece o histórico anterior)',
    }, 'Nova conversa');
    btnNovaConversa.addEventListener('click', async () => {
      const confirmado = await mostrarConfirmacao({
        titulo: 'Começar conversa nova',
        mensagem: `${agente.nome} vai esquecer tudo que falamos até agora. Quer continuar?`,
        textoConfirmar: 'Limpar histórico',
        textoCancelar: 'Cancelar',
        destrutivo: true,
      });
      if (!confirmado) return;
      btnNovaConversa.disabled = true; btnNovaConversa.textContent = 'Limpando...';
      const r = await limparHistoricoConversa(agente.slug);
      if (r.ok) {
        conversaAtual = { agente, mensagens: [] };
        renderChat(agente);
      } else {
        btnNovaConversa.disabled = false; btnNovaConversa.textContent = 'Nova conversa';
        await mostrarAlerta({
          titulo: 'Não consegui limpar',
          mensagem: 'Erro: ' + (r.erro || 'falha desconhecida'),
          tipo: 'erro',
        });
      }
    });

    // Pega squad slug do agente pra avatar (anexado em renderAgenteItem)
    const squadSlugDoChat = agente._squad_slug || null;
    let avatarSrc = '';
    try {
      avatarSrc = gerarAvatarDataUri(agente.slug, squadSlugDoChat);
    } catch (e) {
      console.error('[renderChat] erro avatar:', e);
    }
    conteudo.append(
      el('div', { class: 'chat-header' }, [
        headerVoltar,
        avatarSrc ? el('img', {
          class: 'chat-header-avatar',
          src: avatarSrc,
          alt: agente.nome,
        }) : null,
        el('div', { class: 'chat-titulo' }, [
          agente.nome,
          el('div', { class: 'chat-titulo-sub' }, agente.modelo || ''),
        ]),
        btnNovaConversa,
      ].filter(Boolean)),
    );

    // Se eh primeira abertura desse chat na sessao (sem mensagens local), busca historico do banco
    if (!continuarConversa) {
      carregarHistoricoDoBanco(agente).then(historico => {
        if (historico && historico.length > 0 && conversaAtual?.agente?.slug === agente.slug) {
          conversaAtual.mensagens = historico;
          renderBolhas();
        }
      }).catch(e => console.warn('[carregarHistorico] falhou:', e?.message));
    }

  const msgsBox = el('div', { class: 'chat-mensagens', id: 'chat-msgs' });
  conteudo.append(msgsBox);

  // Event delegation: clique em link-agente -> abre chat com agente especialista
  msgsBox.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('.link-agente');
    if (!btn) return;
    const slug = btn.getAttribute('data-agente-slug');
    if (!slug) return;
    // Busca o agente na lista cacheada
    const ag = (agentesCache || []).find(a => a.slug === slug);
    if (!ag) {
      alert('Agente "' + slug + '" não encontrado na lista.');
      return;
    }
    // Anexa squad_slug pro avatar do header
    const sq = (squadsCache || []).find(s => s.id === ag.squad_id);
    ag._squad_slug = sq?.slug || null;
    conversaAtual = null;
    renderChat(ag);
  });

  function renderBolhas() {
    msgsBox.innerHTML = '';
    if (conversaAtual.mensagens.length === 0) {
      msgsBox.append(el('div', {
        class: 'bolha bolha-agente',
        html: `<p><strong>${escapar(agente.nome)}</strong> pronto.</p><p style="color:var(--fg-muted)">${escapar(agente.missao || agente.proposito || 'Manda o briefing.')}</p>`,
      }));
    }
    conversaAtual.mensagens.forEach(m => {
      const corpo = m.papel === 'agente' ? markdownPraHtml(m.texto) : escapar(m.texto);
      const bolha = el('div', {
        class: 'bolha ' + (m.papel === 'usuario' ? 'bolha-usuario' : 'bolha-agente'),
        html: corpo,
      });
      // Liga botoes de copiar texto dentro de cards
      bolha.querySelectorAll('.card-prova-btn[data-acao="copiar-texto"]').forEach(btn => {
        btn.addEventListener('click', () => {
          const alvoId = btn.getAttribute('data-alvo');
          const alvo = bolha.querySelector('#' + alvoId);
          if (!alvo) return;
          const textoLimpo = (alvo.innerText || alvo.textContent || '').trim();
          navigator.clipboard.writeText(textoLimpo).then(() => {
            const txtOriginal = btn.textContent;
            btn.textContent = '✓ Copiado';
            btn.classList.add('copiado');
            setTimeout(() => { btn.textContent = txtOriginal; btn.classList.remove('copiado'); }, 1500);
          });
        });
      });
      if (m.meta) {
        bolha.append(el('div', { class: 'bolha-meta' }, m.meta));
      }
      if (m.papel === 'agente') {
        // Pega a pergunta anterior (último 'usuario' antes desta bolha) pra audit
        const idx = conversaAtual.mensagens.indexOf(m);
        const perguntaAnterior = (() => {
          for (let i = idx - 1; i >= 0; i--) {
            if (conversaAtual.mensagens[i].papel === 'usuario') return conversaAtual.mensagens[i].texto;
          }
          return '';
        })();

        const btnCopiar = el('button', { class: 'bolha-acao', type: 'button' }, 'Copiar');
        btnCopiar.addEventListener('click', () => {
          navigator.clipboard.writeText(m.texto).then(() => {
            btnCopiar.textContent = 'Copiado!';
            setTimeout(() => btnCopiar.textContent = 'Copiar', 1500);
          });
        });

        const btnUp = el('button', { class: 'bolha-acao bolha-acao-feedback', type: 'button', title: 'Resposta boa — registra reforço positivo' }, '👍');
        const btnDown = el('button', { class: 'bolha-acao bolha-acao-feedback', type: 'button', title: 'Resposta ruim — abre correção' }, '👎');

        if (m.feedback === 'positivo') { btnUp.classList.add('feedback-ativo'); btnUp.textContent = '👍 enviado'; btnDown.disabled = true; btnUp.disabled = true; }
        if (m.feedback === 'negativo') { btnDown.classList.add('feedback-ativo'); btnDown.textContent = '👎 enviado'; btnUp.disabled = true; btnDown.disabled = true; }

        btnUp.addEventListener('click', async () => {
          btnUp.disabled = true; btnDown.disabled = true; btnUp.textContent = '...';
          const r = await enviarFeedback({ agente_slug: agente.slug, tipo: 'positivo', pergunta_usuario: perguntaAnterior, resposta_agente: m.texto });
          if (r.ok) { m.feedback = 'positivo'; btnUp.textContent = '👍 enviado'; btnUp.classList.add('feedback-ativo'); }
          else {
            btnUp.textContent = '👍'; btnUp.disabled = false; btnDown.disabled = false;
            await mostrarAlerta({ titulo: 'Não consegui registrar', mensagem: r.erro || 'falha desconhecida', tipo: 'erro' });
          }
        });

        btnDown.addEventListener('click', () => {
          abrirModalCorrecao({
            agente,
            pergunta: perguntaAnterior,
            resposta: m.texto,
            onEnviado: () => { m.feedback = 'negativo'; renderBolhas(); },
          });
        });

        const acoes = el('div', { class: 'bolha-acoes' }, [btnCopiar, btnUp, btnDown]);
        bolha.append(acoes);
      }
      msgsBox.append(bolha);
    });
    msgsBox.scrollIntoView({ block: 'end' });
  }

  renderBolhas();

  // Input
  const textarea = el('textarea', {
    class: 'chat-input-textarea',
    placeholder: textoPendente ? 'Diga o que quer fazer com esse texto... (ex: revisar, encurtar, mudar tom)' : 'Sua mensagem... (Ctrl+V cola imagem)',
  });
  const botaoEnviar = el('button', { class: 'chat-enviar', type: 'button' }, 'Enviar');
  const info = el('div', { class: 'chat-input-info' }, '');

  // Anexos pendentes (imagem ou texto colado)
  let anexoPendente = null; // { tipo: 'imagem'|'texto', data, nome? }
  const anexoPreview = el('div', { class: 'anexo-preview', style: 'display:none' });

  function atualizarAnexoPreview() {
    anexoPreview.innerHTML = '';
    if (!anexoPendente) {
      anexoPreview.style.display = 'none';
      return;
    }
    anexoPreview.style.display = 'flex';
    if (anexoPendente.tipo === 'imagem') {
      anexoPreview.append(
        el('img', { src: anexoPendente.data, class: 'anexo-thumb' }),
        el('span', {}, '📎 imagem anexada'),
      );
    } else if (anexoPendente.tipo === 'texto') {
      anexoPreview.append(
        el('span', {}, `📄 ${anexoPendente.nome || 'texto.txt'} (${(anexoPendente.data || '').length} chars)`),
      );
    }
    const btnRemover = el('button', { class: 'anexo-remover', type: 'button' }, '×');
    btnRemover.addEventListener('click', () => { anexoPendente = null; atualizarAnexoPreview(); });
    anexoPreview.append(btnRemover);
  }

  // Botão microfone (Whisper) com feedback visual em tempo real
  let gravando = false;
  let mediaRecorder = null;
  let audioChunks = [];
  let analyserRaf = null;
  let audioContext = null;
  let gravacaoInicio = 0;
  let timerInterval = null;

  const botaoMic = el('button', { class: 'chat-acao-icone', type: 'button', title: 'Gravar áudio (Whisper)' }, '🎤');

  // Painel de gravação ao vivo (aparece só durante gravação)
  const painelGravacao = el('div', { class: 'painel-gravacao', style: 'display:none' });
  const tempoEl = el('span', { class: 'painel-gravacao-tempo' }, '0:00');
  const barrasContainer = el('div', { class: 'painel-gravacao-barras' });
  // 8 LEDs verticais que sobem/descem com o volume
  const barras = [];
  for (let i = 0; i < 12; i++) {
    const b = el('div', { class: 'painel-gravacao-led' });
    barras.push(b);
    barrasContainer.appendChild(b);
  }
  const btnPararGravacao = el('button', { class: 'painel-gravacao-parar', type: 'button', title: 'Parar e transcrever' }, '⏹ Parar');
  painelGravacao.append(
    el('span', { class: 'painel-gravacao-rec' }, '● REC'),
    tempoEl,
    barrasContainer,
    btnPararGravacao,
  );

  function formatarTempo(seg) {
    const m = Math.floor(seg / 60);
    const s = seg % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  function ativarVisualizadorAudio(stream) {
    try {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 64; // pouco detalhe, alta performance
      source.connect(analyser);
      const buffer = new Uint8Array(analyser.frequencyBinCount);

      function tick() {
        analyser.getByteFrequencyData(buffer);
        // Pega energia média em 12 bandas
        const bandasPorBarra = Math.floor(buffer.length / 12);
        for (let i = 0; i < 12; i++) {
          let soma = 0;
          for (let j = 0; j < bandasPorBarra; j++) {
            soma += buffer[i * bandasPorBarra + j];
          }
          const media = soma / bandasPorBarra; // 0-255
          const altura = Math.max(8, Math.min(28, Math.round((media / 255) * 28)));
          barras[i].style.height = altura + 'px';
          // Cor varia: baixo=verde, médio=laranja, alto=vermelho
          if (media > 180) barras[i].style.background = '#EF4444';
          else if (media > 100) barras[i].style.background = '#FFB800';
          else barras[i].style.background = '#22C55E';
        }
        analyserRaf = requestAnimationFrame(tick);
      }
      tick();
    } catch (e) {
      console.warn('[mic] visualizador falhou:', e.message);
    }
  }

  function pararVisualizador() {
    if (analyserRaf) {
      cancelAnimationFrame(analyserRaf);
      analyserRaf = null;
    }
    if (audioContext) {
      try { audioContext.close(); } catch (_) {}
      audioContext = null;
    }
    // Zera as barras
    barras.forEach(b => {
      b.style.height = '8px';
      b.style.background = '#444';
    });
  }

  async function iniciarGravacao() {
    if (gravando) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      audioChunks = [];
      mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunks.push(e.data); };
      mediaRecorder.onstop = async () => {
        gravando = false;
        pararVisualizador();
        clearInterval(timerInterval);
        painelGravacao.style.display = 'none';
        botaoMic.textContent = '🎤';
        botaoMic.classList.remove('gravando');
        stream.getTracks().forEach(t => t.stop());
        if (audioChunks.length === 0) return;
        botaoMic.textContent = '⏳';
        botaoMic.disabled = true;
        try {
          const blob = new Blob(audioChunks, { type: 'audio/webm' });
          const texto = await transcreverAudio(blob);
          if (texto) {
            textarea.value = (textarea.value ? textarea.value + ' ' : '') + texto;
            textarea.focus();
          }
        } catch (e) {
          alert('Falha ao transcrever: ' + e.message);
        } finally {
          botaoMic.textContent = '🎤';
          botaoMic.disabled = false;
        }
      };

      mediaRecorder.start();
      gravando = true;
      gravacaoInicio = Date.now();
      painelGravacao.style.display = 'flex';
      botaoMic.textContent = '⏹';
      botaoMic.classList.add('gravando');
      ativarVisualizadorAudio(stream);
      timerInterval = setInterval(() => {
        const seg = Math.floor((Date.now() - gravacaoInicio) / 1000);
        tempoEl.textContent = formatarTempo(seg);
      }, 250);
    } catch (e) {
      const msg = (e.message || '').toLowerCase();
      if (msg.includes('denied') || msg.includes('not allowed')) {
        alert(
          'Microfone bloqueado pelo Chrome.\n\n' +
          'Pra liberar:\n' +
          '1. Clica no ícone de cadeado na barra de URL (à esquerda do endereço)\n' +
          '2. Em "Permissões do site" → procura "Microfone"\n' +
          '3. Muda pra "Permitir"\n' +
          '4. Recarrega a página e tenta de novo'
        );
      } else if (msg.includes('found')) {
        alert('Nenhum microfone detectado no seu computador.');
      } else {
        alert('Erro ao acessar microfone: ' + e.message);
      }
    }
  }

  function pararGravacao() {
    if (gravando && mediaRecorder?.state !== 'inactive') {
      mediaRecorder.stop();
    }
  }

  botaoMic.addEventListener('click', () => {
    if (gravando) pararGravacao();
    else iniciarGravacao();
  });
  btnPararGravacao.addEventListener('click', pararGravacao);

  // Botão upload txt
  const inputFile = el('input', { type: 'file', accept: '.txt,.md', style: 'display:none' });
  const botaoTxt = el('button', { class: 'chat-acao-icone', type: 'button', title: 'Anexar arquivo de texto' }, '📎');
  botaoTxt.addEventListener('click', () => inputFile.click());
  inputFile.addEventListener('change', async (ev) => {
    const f = ev.target.files?.[0];
    if (!f) return;
    if (f.size > 200 * 1024) { alert('Arquivo > 200KB. Resume o conteúdo e cola direto.'); return; }
    const texto = await f.text();
    anexoPendente = { tipo: 'texto', data: texto, nome: f.name };
    atualizarAnexoPreview();
    inputFile.value = '';
  });

  // Comprime imagem em base64 reduzindo dimensoes pra max 1600px no maior lado
  // (Vision aceita ate 2048x2048 com qualidade alta — 1600 fica leve sem perder qualidade)
  async function comprimirImagemDataURI(dataURI, maxLado = 1600) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const ratio = Math.max(img.width, img.height) / maxLado;
        const w = ratio > 1 ? Math.round(img.width / ratio) : img.width;
        const h = ratio > 1 ? Math.round(img.height / ratio) : img.height;
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        // JPEG 0.85 = boa qualidade, ~4-10x menor que PNG
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = reject;
      img.src = dataURI;
    });
  }

  // Paste image (Ctrl+V) -> anexo
  textarea.addEventListener('paste', (ev) => {
    const items = ev.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        ev.preventDefault();
        const blob = item.getAsFile();
        if (!blob) return;
        const reader = new FileReader();
        reader.onload = async () => {
          try {
            const comprimido = await comprimirImagemDataURI(reader.result);
            anexoPendente = { tipo: 'imagem', data: comprimido };
            atualizarAnexoPreview();
          } catch (e) {
            alert('Falha ao processar imagem: ' + e.message);
          }
        };
        reader.readAsDataURL(blob);
        return;
      }
    }
  });

  // Drag-and-drop de arquivo de imagem
  const dropZone = document.body;
  let dragCount = 0;
  function highlightDrop(on) {
    if (on) document.body.classList.add('arrastando-arquivo');
    else document.body.classList.remove('arrastando-arquivo');
  }
  dropZone.addEventListener('dragenter', (ev) => {
    ev.preventDefault();
    dragCount++;
    highlightDrop(true);
  });
  dropZone.addEventListener('dragleave', (ev) => {
    ev.preventDefault();
    dragCount--;
    if (dragCount <= 0) { dragCount = 0; highlightDrop(false); }
  });
  dropZone.addEventListener('dragover', (ev) => {
    ev.preventDefault();
    ev.dataTransfer.dropEffect = 'copy';
  });
  dropZone.addEventListener('drop', (ev) => {
    ev.preventDefault();
    dragCount = 0;
    highlightDrop(false);
    const file = ev.dataTransfer?.files?.[0];
    if (!file) return;
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const comprimido = await comprimirImagemDataURI(reader.result);
          anexoPendente = { tipo: 'imagem', data: comprimido };
          atualizarAnexoPreview();
        } catch (e) {
          alert('Falha ao processar imagem: ' + e.message);
        }
      };
      reader.readAsDataURL(file);
    } else if (file.type.startsWith('text/') || /\.(txt|md)$/i.test(file.name)) {
      if (file.size > 200 * 1024) {
        alert('Arquivo > 200KB. Resume o conteudo e cola direto.');
        return;
      }
      file.text().then(txt => {
        anexoPendente = { tipo: 'texto', data: txt, nome: file.name };
        atualizarAnexoPreview();
      });
    } else {
      alert('So aceito imagem ou texto. Arquivo: ' + file.type);
    }
  });

  // Se tem texto do context menu, pre-preenche
  if (textoPendente) {
    textarea.value = `Trabalhe esse texto:\n\n"""\n${textoPendente}\n"""\n\nO que fazer: `;
    setTimeout(() => textarea.focus(), 50);
    textoPendente = null; // consome
    storageRemove(['textoPendente', 'textoPendenteOrigem', 'textoPendenteEm']);
  }

  async function enviar() {
    let msg = textarea.value.trim();
    if (!msg && !anexoPendente) return;

    // Compõe mensagem com anexos
    if (anexoPendente?.tipo === 'texto') {
      msg = `${msg}\n\n---\nArquivo anexado (${anexoPendente.nome}):\n"""\n${anexoPendente.data}\n"""`;
    } else if (anexoPendente?.tipo === 'imagem') {
      // Briefing claro: usuario anexou imagem. Agente deve invocar tool com so a instrucao;
      // sistema injeta a imagem automaticamente do contexto_extra.imagem_data_uri.
      if (!msg) msg = 'Analisa essa imagem.';
      msg = `${msg}\n\n(Imagem anexada — chame a ferramenta analisar_imagem passando so a instrucao, o sistema injeta a imagem.)`;
    }
    if (!msg) return;
    botaoEnviar.disabled = true;
    botaoEnviar.textContent = 'Enviando...';
    info.textContent = '';

    conversaAtual.mensagens.push({ papel: 'usuario', texto: msg });
    textarea.value = '';
    renderBolhas();

    // Loading bubble
    const loading = el('div', { class: 'bolha bolha-agente' }, [
      el('div', { class: 'carregando' }, [
        el('span', { class: 'carregando-dot' }),
        el('span', { class: 'carregando-dot' }),
        el('span', { class: 'carregando-dot' }),
        ' Pensando...',
      ]),
    ]);
    msgsBox.append(loading);
    loading.scrollIntoView({ block: 'end' });

    // Salva e limpa anexo
    const anexoPraEnviar = anexoPendente;
    anexoPendente = null;
    atualizarAnexoPreview();

    try {
      const resp = await conversarComAgente(agente.slug, msg, anexoPraEnviar);
      loading.remove();
      const texto = resp.conteudo_md
        || (resp.conteudo_estruturado ? JSON.stringify(resp.conteudo_estruturado, null, 2) : '')
        || resp.titulo
        || '(resposta vazia)';
      const meta = resp.uso
        ? `${resp.uso.modelo || ''} · ${resp.uso.latencia_ms || 0}ms · $${(resp.uso.custo_usd || 0).toFixed(4)}`
        : '';
      conversaAtual.mensagens.push({ papel: 'agente', texto, meta });
      renderBolhas();
    } catch (e) {
      loading.remove();
      conversaAtual.mensagens.push({ papel: 'agente', texto: 'Erro: ' + (e.message || 'falha desconhecida') });
      renderBolhas();
    } finally {
      botaoEnviar.disabled = false;
      botaoEnviar.textContent = 'Enviar';
    }
  }

  botaoEnviar.addEventListener('click', enviar);
  textarea.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      enviar();
    }
  });

  conteudo.append(
    el('div', { class: 'chat-input-box' }, [
      painelGravacao,
      anexoPreview,
      textarea,
      el('div', { class: 'chat-input-acoes' }, [
        botaoMic,
        botaoTxt,
        inputFile,
        el('span', { class: 'chat-input-info', style: 'margin-left:auto;margin-right:8px' }, 'Ctrl+Enter envia'),
        botaoEnviar,
      ]),
    ])
  );
  } catch (erro) {
    console.error('[renderChat] erro fatal:', erro);
    conteudo.innerHTML = '';
    conteudo.append(el('div', { class: 'alerta-erro', style: 'margin:20px' },
      'Erro ao abrir chat: ' + (erro?.message || 'desconhecido') + '. Clica em ↻ pra recarregar.'));
  }
}

// ============== UTILS ==============
function escapar(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// Markdown leve (paragrafos, negrito, italico, codigo, listas, headers, IMAGEM, LINK, CARD)
function markdownPraHtml(md) {
  if (!md) return '';

  // 1. Primeiro, extrai BLOCOS DE CARD (formato: <CARD>...</CARD>) e substitui por placeholders
  // antes do escapar(), pra preservar HTML estruturado dos cards.
  const cards = [];
  let semCards = String(md).replace(/<CARD[^>]*>[\s\S]*?<\/CARD>/g, (bloco) => {
    cards.push(bloco);
    return `__CARD_PLACEHOLDER_${cards.length - 1}__`;
  });

  let h = escapar(semCards);

  // 2. Markdown image: ![alt](url) -> <img>
  h = h.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g,
    (_, alt, url) => `<img class="md-img" alt="${alt}" src="${url}" loading="lazy">`);
  // Code blocks
  h = h.replace(/```([\s\S]*?)```/g, (m, code) => `<pre>${code.trim()}</pre>`);
  // Inline code
  h = h.replace(/`([^`]+)`/g, '<code>$1</code>');
  // Headers
  h = h.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  h = h.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  h = h.replace(/^# (.+)$/gm, '<h1>$1</h1>');
  // Bold + italic
  h = h.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  h = h.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
  // Link especial pra abrir agente: [texto](agente:slug) → botao clicavel
  h = h.replace(/\[([^\]]+)\]\(agente:([a-z0-9-]+)\)/g,
    (_, texto, slug) => `<button class="link-agente" data-agente-slug="${slug}">${texto} →</button>`);
  // Link normal: [texto](url) -> <a target="_blank">
  h = h.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
    (_, texto, url) => `<a href="${url}" target="_blank" rel="noopener">${texto}</a>`);
  // Listas
  h = h.replace(/^(?:[-*] .+(?:\n|$))+/gm, (m) => {
    const items = m.trim().split('\n').map(l => `<li>${l.replace(/^[-*] /, '')}</li>`).join('');
    return `<ul>${items}</ul>`;
  });
  // Numeradas
  h = h.replace(/^(?:\d+\. .+(?:\n|$))+/gm, (m) => {
    const items = m.trim().split('\n').map(l => `<li>${l.replace(/^\d+\. /, '')}</li>`).join('');
    return `<ol>${items}</ol>`;
  });
  // Paragrafos
  const blocos = h.split(/\n{2,}/).map(b => {
    if (/^<(ul|ol|pre|h\d|blockquote|img|__CARD)/.test(b.trim())) return b;
    if (!b.trim()) return '';
    return '<p>' + b.replace(/\n/g, '<br>') + '</p>';
  }).join('\n');

  // 3. Substitui placeholders pelos cards REAIS (HTML cru) e processa atributos
  let final = blocos.replace(/__CARD_PLACEHOLDER_(\d+)__/g, (_, idx) => {
    return renderizarCard(cards[parseInt(idx, 10)]);
  });

  return final;
}

// Renderiza 1 <CARD> em HTML estruturado.
// Formato esperado:
//   <CARD>
//     <THUMB src="..." alt="..."/>     (opcional — thumbnail no topo)
//     <TITULO>...</TITULO>             (linha de titulo)
//     <SUB>...</SUB>                   (subtitulo / categoria)
//     <TEXTO>...</TEXTO>               (texto principal, com botao copiar)
//     <META>...</META>                 (rodape: data, link, etc)
//   </CARD>
function renderizarCard(blocoCard) {
  function pegar(tag) {
    const m = blocoCard.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i'));
    return m ? m[1].trim() : '';
  }
  function pegarAttr(tag, attr) {
    const m = blocoCard.match(new RegExp(`<${tag}[^>]*${attr}\\s*=\\s*"([^"]*)"`, 'i'));
    return m ? m[1] : '';
  }

  // Extrai partes
  const thumbSrc = pegarAttr('THUMB', 'src');
  const thumbAlt = pegarAttr('THUMB', 'alt') || 'Imagem';
  const titulo = pegar('TITULO');
  const sub = pegar('SUB');
  const texto = pegar('TEXTO');
  const meta = pegar('META');

  // ID unico pra botoes saberem qual texto/img copiar
  const cardId = 'card_' + Math.random().toString(36).slice(2, 9);

  // Sanitiza texto interno (escapa, mantem quebras como <br>)
  const tituloHtml = escapar(titulo).replace(/\n/g, '<br>');
  const subHtml = escapar(sub);
  const textoHtml = escapar(texto).replace(/\n/g, '<br>');
  const metaHtml = escapar(meta).replace(/\n/g, '<br>');

  let html = `<div class="card-prova" data-card-id="${cardId}">`;

  if (thumbSrc) {
    html += `<a class="card-prova-thumb-wrap" href="${thumbSrc}" target="_blank" rel="noopener" title="Abrir imagem em tamanho real">
      <img class="card-prova-thumb" src="${thumbSrc}" alt="${escapar(thumbAlt)}" loading="lazy" data-img-url="${thumbSrc}">
    </a>`;
  }

  if (titulo || sub) {
    html += `<div class="card-prova-cabecalho">`;
    if (titulo) html += `<div class="card-prova-titulo">${tituloHtml}</div>`;
    if (sub) html += `<div class="card-prova-sub">${subHtml}</div>`;
    html += `</div>`;
  }

  if (texto) {
    html += `<div class="card-prova-texto" id="${cardId}_txt">${textoHtml}</div>
      <div class="card-prova-acoes">
        <button class="card-prova-btn" type="button" data-acao="copiar-texto" data-alvo="${cardId}_txt">📋 Copiar texto</button>`;
    if (thumbSrc) {
      html += `<a class="card-prova-btn" href="${thumbSrc}" download target="_blank" rel="noopener">🖼 Baixar imagem</a>`;
    }
    html += `</div>`;
  }

  if (meta) {
    // Meta processa links markdown [texto](url) tambem
    let metaFinal = metaHtml.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
      (_, t, u) => `<a href="${u}" target="_blank" rel="noopener">${t}</a>`);
    html += `<div class="card-prova-meta">${metaFinal}</div>`;
  }

  html += `</div>`;
  return html;
}

// ============== EVENTOS TOPO ==============
btnFechar.addEventListener('click', () => {
  window.parent.postMessage({ pinguimTipo: 'FECHAR_SIDEBAR' }, '*');
});

// Auto-refresh quando sidebar reabre (content script avisa)
window.addEventListener('message', (ev) => {
  if (ev.data?.pinguimTipo === 'SIDEBAR_REABRIU') {
    if (session?.access_token) {
      agentesCache = null;
      squadsCache = null;
      if (!conversaAtual) {
        renderAgentes().catch(() => {});
      }
    }
  }
});

btnAtualizar.addEventListener('click', async () => {
  if (!session?.access_token) return;
  btnAtualizar.style.opacity = '0.5';
  btnAtualizar.style.pointerEvents = 'none';
  setStatus('Atualizando agentes...');
  // Invalida caches
  agentesCache = null;
  squadsCache = null;
  // Re-renderiza
  if (conversaAtual) {
    // se está em chat, volta pra lista e atualiza
    conversaAtual = null;
  }
  try {
    await renderAgentes();
  } catch (e) {
    setStatus('Erro ao atualizar: ' + e.message);
  } finally {
    btnAtualizar.style.opacity = '1';
    btnAtualizar.style.pointerEvents = 'auto';
  }
});

btnFixar.addEventListener('click', async () => {
  const data = await storageGet(['sempreFixa']);
  const novo = !data.sempreFixa;
  await storageSet({ sempreFixa: novo });
  window.parent.postMessage({ pinguimTipo: 'SET_FIXA', valor: novo }, '*');
  btnFixar.classList.toggle('ativo', novo);
});

// Sincroniza estado do botao fixar
storageGet(['sempreFixa']).then(d => {
  btnFixar.classList.toggle('ativo', !!d.sempreFixa);
});

// ============== INICIO ==============
function renderCarregando() {
  conteudo.innerHTML = '';
  setStatus('Verificando sessao...');
  conteudo.append(
    el('div', { class: 'login-box' }, [
      el('div', { class: 'carregando', style: 'justify-content:center;margin-top:40px' }, [
        el('span', { class: 'carregando-dot' }),
        el('span', { class: 'carregando-dot' }),
        el('span', { class: 'carregando-dot' }),
        el('span', { style: 'margin-left:8px' }, 'Carregando...'),
      ]),
    ])
  );
}

async function init() {
  renderCarregando();
  await carregarSessao();

  // Pega texto pendente do context menu
  const data = await storageGet(['textoPendente', 'textoPendenteEm']);
  if (data.textoPendente && data.textoPendenteEm && Date.now() - data.textoPendenteEm < 60000) {
    textoPendente = data.textoPendente;
  } else if (data.textoPendente) {
    await storageRemove(['textoPendente', 'textoPendenteOrigem', 'textoPendenteEm']);
  }

  if (session?.access_token) {
    await renderAgentes();
  } else {
    renderLogin();
  }
}

init();
