// Pinguim Agentes — Sidebar logic
import { gerarAvatarDataUri } from './pinguim-avatar.js';

const SUPABASE_URL = 'https://wmelierxzpjamiofeemh.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndtZWxpZXJ4enBqYW1pb2ZlZW1oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMyMzY5MzQsImV4cCI6MjA4ODgxMjkzNH0.kbzLkX7yDmNfT_wJ00M4KKphTgyc0QXaVpaplO0i-jk';

const conteudo = document.getElementById('conteudo');
const rodapeStatus = document.getElementById('rodape-status');
const rodapeUsuario = document.getElementById('rodape-usuario');
const rodapeVersao = document.getElementById('rodape-versao');
const rodapeSair = document.getElementById('rodape-sair');
const btnFixar = document.getElementById('btn-fixar');
const btnFechar = document.getElementById('btn-fechar');
const btnAtualizar = document.getElementById('btn-atualizar');
// v0.13.1: btn-analisar-tela saiu do header. Vira 6 categoria na nav lateral.

// Mostra versao da extensao no rodape
try {
  const m = chrome.runtime.getManifest();
  if (rodapeVersao) rodapeVersao.textContent = 'v' + m.version;
} catch (_) {}

let session = null;            // { access_token, user, expira_em }
let agentesCache = null;
let squadsCache = null;
let conversaAtual = null;      // { agente, mensagens: [], conversa_id? }
let textoPendente = null;      // vindo do menu de contexto

// ============== STORAGE HELPERS ==============
function storageGet(keys) {
  return new Promise(r => chrome.storage.local.get(keys, r));
}
function storageSet(obj) {
  return new Promise(r => chrome.storage.local.set(obj, r));
}
function storageRemove(keys) {
  return new Promise(r => chrome.storage.local.remove(keys, r));
}

// ============== FETCH PROXY (passa por service worker) ==============
function fetchProxy(url, options) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { tipo: 'FETCH_PROXY', url, options },
      (resp) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!resp) return reject(new Error('Sem resposta do service worker'));
        resolve(resp);
      }
    );
  });
}

// ============== SUPABASE AUTH ==============
async function loginSupabase(email, senha) {
  const r = await fetchProxy(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: senha }),
  });
  if (!r.ok) {
    const msg = r.body?.error_description || r.body?.msg || r.body?.error || 'Erro de login';
    throw new Error(msg);
  }
  return {
    access_token: r.body.access_token,
    refresh_token: r.body.refresh_token,
    user: r.body.user,
    expira_em: Date.now() + (r.body.expires_in * 1000),
  };
}

async function refreshSession() {
  if (!session?.refresh_token) return null;
  const r = await fetchProxy(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: 'POST',
    headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: session.refresh_token }),
  });
  if (!r.ok) return null;
  return {
    access_token: r.body.access_token,
    refresh_token: r.body.refresh_token,
    user: r.body.user,
    expira_em: Date.now() + (r.body.expires_in * 1000),
  };
}

async function carregarSessao() {
  const data = await storageGet(['session']);
  if (!data.session?.access_token) return;
  session = data.session;
  // Se expirou ou expira em <5min, tenta refresh
  if (session.expira_em && session.expira_em < Date.now() + 5 * 60000) {
    const nova = await refreshSession();
    if (nova) {
      session = nova;
      await storageSet({ session });
    } else {
      // Refresh falhou: tenta usar token atual (pode ainda funcionar) ou limpa
      if (!session.expira_em || session.expira_em < Date.now()) {
        session = null;
        await storageRemove('session');
      }
    }
  }
}

// Garante session valida antes de cada chamada autenticada. Renova se expirou.
async function garantirSessaoValida() {
  if (!session?.access_token) return false;
  if (session.expira_em && session.expira_em < Date.now() + 60000) {
    const nova = await refreshSession();
    if (nova) {
      session = nova;
      await storageSet({ session });
      return true;
    } else {
      session = null;
      await storageRemove('session');
      return false;
    }
  }
  return true;
}

async function logout() {
  if (session?.access_token) {
    try {
      await fetchProxy(`${SUPABASE_URL}/auth/v1/logout`, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
        },
      });
    } catch (_) {}
  }
  session = null;
  agentesCache = null;
  conversaAtual = null;
  categoriaAtiva = 'home';
  await storageRemove(['session']);
  renderNavCategorias();
  renderLogin();
}

// ============== SUPABASE REST (pinguim schema) ==============
async function sbSelect(tabela, query = '') {
  if (!(await garantirSessaoValida())) throw new Error('Sessao expirou — faca login novamente');
  const url = `${SUPABASE_URL}/rest/v1/${tabela}${query ? '?' + query : ''}`;
  const r = await fetchProxy(url, {
    method: 'GET',
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${session.access_token}`,
      'Accept-Profile': 'pinguim',
    },
  });
  if (!r.ok) throw new Error(r.body?.message || 'Erro ao consultar ' + tabela);
  return r.body;
}

async function carregarAgentesESquads() {
  if (agentesCache && squadsCache) return { agentes: agentesCache, squads: squadsCache };
  const [agentes, squads, execucoes] = await Promise.all([
    // v0.22.4: filtro pronto_pra_uso=true — só mostra agentes que passaram nas 3 baterias de auditoria
    sbSelect('agentes', 'select=id,slug,nome,avatar,cor,status,modelo,missao,proposito,squad_id,system_prompt,ferramentas,capabilities&status=eq.em_producao&pronto_pra_uso=eq.true&order=nome.asc'),
    sbSelect('squads', 'select=id,slug,nome,emoji&order=slug.asc'),
    sbSelect('agente_execucoes', 'select=agente_id&order=executado_em.desc&limit=500').catch(() => []),
  ]);
  // Conta execucoes por agente
  const contaExec = new Map();
  for (const e of (execucoes || [])) {
    if (!e.agente_id) continue;
    contaExec.set(e.agente_id, (contaExec.get(e.agente_id) || 0) + 1);
  }
  // Anexa contagem em cada agente
  agentes.forEach(a => { a._execs = contaExec.get(a.id) || 0; });
  agentesCache = agentes;
  squadsCache = squads;
  return { agentes, squads };
}

// Cor consistente por squad (hash do slug -> paleta)
function corDaSquad(squadSlug) {
  const paleta = ['#FF6B35', '#22c55e', '#3b82f6', '#eab308', '#a855f7', '#06b6d4', '#ec4899', '#14b8a6', '#f59e0b', '#8b5cf6', '#ef4444', '#10b981'];
  if (!squadSlug) return '#888';
  let hash = 0;
  for (let i = 0; i < squadSlug.length; i++) hash = (hash * 31 + squadSlug.charCodeAt(i)) >>> 0;
  return paleta[hash % paleta.length];
}

// Iniciais do nome (até 2 chars)
function iniciaisDoNome(nome) {
  if (!nome) return '?';
  const palavras = nome.trim().split(/\s+/);
  if (palavras.length === 1) return palavras[0].slice(0, 2).toUpperCase();
  return (palavras[0][0] + palavras[palavras.length - 1][0]).toUpperCase();
}

// ============== EDGE FUNCTION: conversar com agente ==============
async function conversarComAgente(agenteSlug, mensagem, anexo = null) {
  if (!(await garantirSessaoValida())) throw new Error('Sessao expirou — faca login novamente');
  const url = `${SUPABASE_URL}/functions/v1/agente-executar`;
  const contextoExtra = {};
  if (anexo?.tipo === 'imagem') contextoExtra.imagem_data_uri = anexo.data;
  // cliente_id = user.id real do logado, pra memoria conversacional por (user, agente).
  // Se nao tiver user.id por algum motivo, cai pro placeholder antigo (sem memoria).
  const clienteId = session.user?.id || '00000000-0000-0000-0000-000000000000';
  const body = {
    agente_slug: agenteSlug,
    tenant_id: '00000000-0000-0000-0000-000000000000',
    cliente_id: clienteId,
    solicitante_id: session.user?.email || session.user?.id || 'extensao-chrome',
    briefing: mensagem,
    contexto_extra: Object.keys(contextoExtra).length > 0 ? contextoExtra : undefined,
  };
  const r = await fetchProxy(url, {
    method: 'POST',
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(r.body?.detalhe || r.body?.error || 'Erro na execucao do agente');
  return r.body;
}

// Whisper API — recebe blob de audio, devolve texto
async function transcreverAudio(blob) {
  if (!(await garantirSessaoValida())) throw new Error('Sessao expirou');
  // Service worker faz o multipart pra OpenAI.
  // Converte ArrayBuffer -> base64 em chunks de 8KB pra nao estourar call stack
  // (spread `...new Uint8Array(buf)` quebra com audio > ~60KB = ~3 segundos)
  const buf = await blob.arrayBuffer();
  const bytes = new Uint8Array(buf);
  let binario = '';
  const CHUNK = 0x8000; // 32KB
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binario += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  const b64 = btoa(binario);
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(
      { tipo: 'WHISPER_TRANSCRIBE', audioBase64: b64, mimeType: blob.type },
      (resp) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!resp?.ok) return reject(new Error(resp?.erro || 'Whisper falhou'));
        resolve(resp.texto);
      }
    );
  });
}

// ============== MEMORIA CONVERSACIONAL ==============
// Lê últimas N mensagens dessa thread (user, agente) direto do Supabase via PostgREST.
// Retorna no formato { papel, texto, meta? } pra hidratar conversaAtual.mensagens.
async function carregarHistoricoDoBanco(agente) {
  if (!session?.access_token || !session?.user?.id) return [];
  try {
    // Acha id do agente pelo slug (pode usar agente.id se a sidebar carregar)
    const agenteId = agente.id;
    if (!agenteId) return [];
    const url = `${SUPABASE_URL}/rest/v1/conversas?select=papel,conteudo,criado_em&cliente_id=eq.${session.user.id}&agente_id=eq.${agenteId}&caso_id=is.null&order=criado_em.desc&limit=20`;
    const r = await fetchProxy(url, {
      method: 'GET',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        'Accept-Profile': 'pinguim',
      },
    });
    if (!r.ok || !Array.isArray(r.body)) return [];
    // r.body veio em ordem DESC; reverte pra cronologica
    const arr = [...r.body].reverse();
    // banco usa CHECK: 'humano'|'chief'|'sistema'|'worker' — UI usa 'usuario'|'agente'
    return arr.map(m => ({
      papel: m.papel === 'humano' ? 'usuario' : 'agente',
      texto: m.conteudo || '',
      em: m.criado_em ? new Date(m.criado_em).getTime() : null,
    }));
  } catch (e) {
    console.warn('[carregarHistoricoDoBanco] erro:', e?.message);
    return [];
  }
}

// Apaga todas as mensagens dessa thread (user, agente).
// Hoje DELETE direto via PostgREST — RLS precisa permitir o user apagar suas proprias linhas.
async function limparHistoricoConversa(agenteSlug) {
  if (!session?.access_token || !session?.user?.id) return { ok: false, erro: 'nao logado' };
  try {
    // Resolve agente_id
    const r1 = await fetchProxy(`${SUPABASE_URL}/rest/v1/agentes?select=id&slug=eq.${agenteSlug}`, {
      method: 'GET',
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Accept-Profile': 'pinguim' },
    });
    if (!r1.ok || !Array.isArray(r1.body) || r1.body.length === 0) return { ok: false, erro: 'agente nao achado' };
    const agenteId = r1.body[0].id;
    // DELETE — precisa Content-Profile pra PostgREST achar a tabela no schema pinguim em modificacoes
    const r2 = await fetchProxy(`${SUPABASE_URL}/rest/v1/conversas?cliente_id=eq.${session.user.id}&agente_id=eq.${agenteId}`, {
      method: 'DELETE',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        'Accept-Profile': 'pinguim',
        'Content-Profile': 'pinguim',
        Prefer: 'return=minimal',
      },
    });
    if (!r2.ok && r2.status !== 204) return { ok: false, erro: r2.body?.message || `HTTP ${r2.status}` };
    return { ok: true };
  } catch (e) {
    return { ok: false, erro: e?.message || 'falha' };
  }
}

// ============== MODAIS PROPRIOS (substituem confirm/alert do browser) ==============
// Retorna Promise<boolean>: true se confirmou, false se cancelou
function mostrarConfirmacao({ titulo, mensagem, textoConfirmar = 'Confirmar', textoCancelar = 'Cancelar', destrutivo = false }) {
  return new Promise(resolve => {
    document.querySelectorAll('.modal-pinguim').forEach(m => m.remove());

    const overlay = el('div', { class: 'modal-pinguim' });
    const box = el('div', { class: 'modal-pinguim-box' });
    const tituloEl = el('h3', { class: 'modal-pinguim-titulo' }, titulo || 'Confirmar');
    const mensagemEl = el('p', { class: 'modal-pinguim-mensagem' }, mensagem || '');

    const btnCancelar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, textoCancelar);
    const btnConfirmar = el('button', {
      class: 'modal-pinguim-btn ' + (destrutivo ? 'modal-pinguim-btn-destrutivo' : 'modal-pinguim-btn-primary'),
      type: 'button',
    }, textoConfirmar);

    function fechar(valor) {
      overlay.remove();
      document.removeEventListener('keydown', onKey);
      resolve(valor);
    }
    function onKey(e) {
      if (e.key === 'Escape') fechar(false);
      if (e.key === 'Enter') fechar(true);
    }
    btnCancelar.addEventListener('click', () => fechar(false));
    btnConfirmar.addEventListener('click', () => fechar(true));
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fechar(false); });
    document.addEventListener('keydown', onKey);

    box.append(tituloEl, mensagemEl, el('div', { class: 'modal-pinguim-botoes' }, [btnCancelar, btnConfirmar]));
    overlay.append(box);
    document.body.append(overlay);
    setTimeout(() => btnConfirmar.focus(), 50);
  });
}

function mostrarAlerta({ titulo, mensagem, textoFechar = 'Fechar', tipo = 'info' }) {
  return new Promise(resolve => {
    document.querySelectorAll('.modal-pinguim').forEach(m => m.remove());

    const overlay = el('div', { class: 'modal-pinguim' });
    const box = el('div', { class: 'modal-pinguim-box' });
    const tituloEl = el('h3', { class: 'modal-pinguim-titulo modal-pinguim-titulo-' + tipo }, titulo || 'Aviso');
    const mensagemEl = el('p', { class: 'modal-pinguim-mensagem' }, mensagem || '');

    const btnFechar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, textoFechar);

    function fechar() {
      overlay.remove();
      document.removeEventListener('keydown', onKey);
      resolve();
    }
    function onKey(e) {
      if (e.key === 'Escape' || e.key === 'Enter') fechar();
    }
    btnFechar.addEventListener('click', fechar);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fechar(); });
    document.addEventListener('keydown', onKey);

    box.append(tituloEl, mensagemEl, el('div', { class: 'modal-pinguim-botoes' }, [btnFechar]));
    overlay.append(box);
    document.body.append(overlay);
    setTimeout(() => btnFechar.focus(), 50);
  });
}

// ============== FEEDBACK 👍/👎 ==============
async function enviarFeedback({ agente_slug, tipo, correcao, pergunta_usuario, resposta_agente }) {
  if (!session?.access_token) return { ok: false, erro: 'nao logado' };
  try {
    const url = `${SUPABASE_URL}/functions/v1/feedback-agente`;
    const body = { agente_slug, tipo, pergunta_usuario, resposta_agente };
    if (tipo === 'negativo') body.correcao = correcao;
    const r = await fetchProxy(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${session.access_token}`,
        apikey: SUPABASE_ANON_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
    if (!r.ok) return { ok: false, erro: r.body?.erro || `HTTP ${r.status}` };
    return r.body;
  } catch (e) {
    return { ok: false, erro: e.message };
  }
}

function abrirModalCorrecao({ agente, pergunta, resposta, onEnviado }) {
  // Remove modal anterior se houver
  document.querySelectorAll('.modal-feedback').forEach(m => m.remove());

  const overlay = el('div', { class: 'modal-feedback' });
  const box = el('div', { class: 'modal-feedback-box' });
  const titulo = el('h3', { style: 'margin:0 0 8px 0;font-size:14px' }, `👎 Feedback negativo — ${agente.nome}`);
  const subt = el('p', { style: 'margin:0 0 12px 0;color:var(--fg-muted);font-size:12px' },
    'O que estava errado nessa resposta? Seja específico — o agente vai ler isso e corrigir nas próximas vezes.');

  const textarea = el('textarea', {
    class: 'modal-feedback-textarea',
    placeholder: 'Ex: "esqueceu de mencionar X", "tom muito formal", "errou no cálculo", "deveria ter consultado Y antes"...',
    rows: '5',
  });

  const erroEl = el('div', { style: 'color:#ff6b6b;font-size:12px;min-height:16px;margin-top:6px' });

  const btnCancelar = el('button', { class: 'modal-feedback-btn', type: 'button' }, 'Cancelar');
  const btnEnviar = el('button', { class: 'modal-feedback-btn modal-feedback-btn-primary', type: 'button' }, 'Enviar correção');

  btnCancelar.addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });

  btnEnviar.addEventListener('click', async () => {
    const correcao = textarea.value.trim();
    if (correcao.length < 3) {
      erroEl.textContent = 'Escreve pelo menos 3 caracteres explicando o que estava errado.';
      return;
    }
    btnEnviar.disabled = true; btnEnviar.textContent = 'Enviando...';
    const r = await enviarFeedback({
      agente_slug: agente.slug, tipo: 'negativo', correcao,
      pergunta_usuario: pergunta, resposta_agente: resposta,
    });
    if (r.ok) {
      overlay.remove();
      onEnviado && onEnviado();
      if (r.alerta_excesso) {
        setTimeout(() => mostrarAlerta({
          titulo: 'Atenção: agente com problemas',
          mensagem: `Esse agente já tem ${r.negativos_ativos} feedbacks negativos ativos. Tá na hora de revisar a configuração dele.`,
          tipo: 'aviso',
        }), 200);
      }
    } else {
      erroEl.textContent = 'Erro: ' + (r.erro || 'desconhecido');
      btnEnviar.disabled = false; btnEnviar.textContent = 'Enviar correção';
    }
  });

  box.append(titulo, subt, textarea, erroEl, el('div', { class: 'modal-feedback-botoes' }, [btnCancelar, btnEnviar]));
  overlay.append(box);
  document.body.append(overlay);
  setTimeout(() => textarea.focus(), 50);
}

// v0.19.4: serializa briefing do Clonador como markdown legível pra exportar
function briefingParaMarkdown(b, meta = {}) {
  if (!b) return '';
  const linhas = [];
  linhas.push(`# Briefing — ${meta.titulo || 'Página clonada'}`);
  if (meta.dominio) linhas.push(`*${meta.dominio}*`);
  if (meta.url_origem) linhas.push(`URL: ${meta.url_origem}`);
  linhas.push('');

  if (b.headline) { linhas.push(`## 🎯 Headline`); linhas.push(b.headline); linhas.push(''); }
  if (b.sub_headline) { linhas.push(`### Sub-headline`); linhas.push(b.sub_headline); linhas.push(''); }

  if (b.oferta) {
    linhas.push(`## 💰 Oferta`);
    if (b.oferta.produto) linhas.push(`- **Produto:** ${b.oferta.produto}`);
    if (b.oferta.promessa) linhas.push(`- **Promessa:** ${b.oferta.promessa}`);
    if (b.oferta.publico) linhas.push(`- **Público:** ${b.oferta.publico}`);
    if (b.oferta.data_evento) linhas.push(`- **Data do evento:** ${b.oferta.data_evento}`);
    linhas.push('');
  }

  if (Array.isArray(b.dores_objecoes) && b.dores_objecoes.length) {
    linhas.push(`## 😩 Dores / objeções do público`);
    b.dores_objecoes.forEach(it => linhas.push(`- ${it}`));
    linhas.push('');
  }

  if (b.cta_principal) {
    linhas.push(`## 🛒 CTA Principal`);
    if (b.cta_principal.texto_botao) linhas.push(`- **Botão:** ${b.cta_principal.texto_botao}`);
    if (b.cta_principal.preco) linhas.push(`- **Preço:** ${b.cta_principal.preco}`);
    if (b.cta_principal.urgencia) linhas.push(`- **Urgência:** ${b.cta_principal.urgencia}`);
    linhas.push('');
  }

  if (Array.isArray(b.beneficios) && b.beneficios.length) {
    linhas.push(`## ✓ Benefícios`);
    b.beneficios.forEach(it => linhas.push(`- ${it}`));
    linhas.push('');
  }

  if (Array.isArray(b.como_funciona) && b.como_funciona.length) {
    linhas.push(`## ⚙ Como funciona / Método`);
    b.como_funciona.forEach((it, i) => linhas.push(`${i+1}. ${it}`));
    linhas.push('');
  }

  if (b.prova_social) {
    const ps = b.prova_social;
    const temPS = (ps.depoimentos?.length || ps.numeros?.length || ps.midia?.length || ps.perfis_atendidos?.length);
    if (temPS) {
      linhas.push(`## ⭐ Prova social`);
      if (ps.numeros?.length) { linhas.push(`**Números:**`); ps.numeros.forEach(n => linhas.push(`- ${n}`)); }
      if (ps.perfis_atendidos?.length) { linhas.push(`**Perfis atendidos:** ${ps.perfis_atendidos.join(', ')}`); }
      if (ps.depoimentos?.length) { linhas.push(`**Depoimentos:**`); ps.depoimentos.forEach(d => linhas.push(`- ${d}`)); }
      if (ps.midia?.length) { linhas.push(`**Mídia:**`); ps.midia.forEach(m => linhas.push(`- ${m}`)); }
      linhas.push('');
    }
  }

  if (b.garantia) { linhas.push(`## 🛡 Garantia`); linhas.push(b.garantia); linhas.push(''); }
  if (b.urgencia_scarcity) { linhas.push(`## ⏰ Urgência / Escassez`); linhas.push(b.urgencia_scarcity); linhas.push(''); }

  if (b.especificacoes) {
    linhas.push(`## 📋 Especificações`);
    if (b.especificacoes.formato) linhas.push(`- **Formato:** ${b.especificacoes.formato}`);
    if (b.especificacoes.duracao) linhas.push(`- **Duração:** ${b.especificacoes.duracao}`);
    if (Array.isArray(b.especificacoes.bonus) && b.especificacoes.bonus.length) {
      linhas.push(`- **Bônus:** ${b.especificacoes.bonus.join(', ')}`);
    }
    linhas.push('');
  }

  if (Array.isArray(b.bonus_ofertas) && b.bonus_ofertas.length) {
    linhas.push(`## 🎁 Bônus / Ofertas extras`);
    b.bonus_ofertas.forEach(it => linhas.push(`- ${it}`));
    linhas.push('');
  }

  if (Array.isArray(b.faqs) && b.faqs.length) {
    linhas.push(`## ❓ FAQ`);
    b.faqs.forEach(f => {
      linhas.push(`**P:** ${f.pergunta}`);
      linhas.push(`**R:** ${f.resposta}`);
      linhas.push('');
    });
  }

  if (Array.isArray(b.frases_destaque) && b.frases_destaque.length) {
    linhas.push(`## ✨ Frases de destaque`);
    b.frases_destaque.forEach(it => linhas.push(`> "${it}"`));
    linhas.push('');
  }

  if (b.sobre_autor) { linhas.push(`## 👤 Sobre o autor`); linhas.push(b.sobre_autor); linhas.push(''); }

  if (Array.isArray(b.sugestoes_otimizacao) && b.sugestoes_otimizacao.length) {
    linhas.push(`## 💡 Sugestões pra subir conversão`);
    b.sugestoes_otimizacao.forEach((s, i) => linhas.push(`${i+1}. ${s}`));
    linhas.push('');
  }

  linhas.push('---');
  linhas.push(`*Briefing gerado pelo Pinguim Agentes em ${new Date().toLocaleString('pt-BR')}*`);
  return linhas.join('\n');
}

// v0.19.3: helper global pra comprimir data-URI PNG -> JPEG (resize + recompress)
function comprimirImagem(dataURI, maxLado = 1600, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const ratio = Math.max(img.width, img.height) / maxLado;
      const w = ratio > 1 ? Math.round(img.width / ratio) : img.width;
      const h = ratio > 1 ? Math.round(img.height / ratio) : img.height;
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = reject;
    img.src = dataURI;
  });
}

// ============== RENDER ==============
function el(tag, props = {}, children = []) {
  const n = document.createElement(tag);
  for (const k in props) {
    if (k === 'class') n.className = props[k];
    else if (k === 'html') n.innerHTML = props[k];
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), props[k]);
    else n.setAttribute(k, props[k]);
  }
  (Array.isArray(children) ? children : [children]).forEach(c => {
    if (c == null) return;
    n.append(c.nodeType ? c : document.createTextNode(String(c)));
  });
  return n;
}

function setStatus(texto) { rodapeStatus.textContent = texto; }
function setUsuario(texto) {
  rodapeUsuario.textContent = texto;
  if (rodapeSair) rodapeSair.style.display = texto && texto.trim() ? '' : 'none';
}
if (rodapeSair) {
  rodapeSair.addEventListener('click', async () => {
    if (!confirm('Sair da conta? Você precisará logar de novo.')) return;
    try { await logout(); } catch (_) {}
    location.reload();
  });
}

// ============== FASE 2: NAVEGACAO POR CATEGORIAS ==============
// Sidebar virou mini Mission Control. 5 categorias verticais a esquerda.
// Cada categoria tem um slug, label, icone e funcao de render.

// SVGs minimalistas estilo Lucide (linha 1.5, currentColor — monocromaticos)
// v0.9.1 — Andre cobrou: "icones coloridos parecem amador, nao Linear/Vercel".
// Avatares de agentes continuam coloridos (identidade). Nav fica monocromatica.
const SVG_BASE = (path) => `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;

const ICONES = {
  // Chat: balao de fala (Lucide message-square)
  chat:         SVG_BASE('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>'),
  // Agentes: silhuetas (users)
  agentes:      SVG_BASE('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'),
  // Agendamentos: calendario com relogio
  agendamentos: SVG_BASE('<path d="M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/><circle cx="18" cy="18" r="4"/><path d="M18 16.5v1.5l.75.75"/>'),
  // Cerebros: brain
  cerebros:     SVG_BASE('<path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 4.44-2.04Z"/><path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-4.44-2.04Z"/>'),
  // Skills: chave inglesa (wrench)
  skills:       SVG_BASE('<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>'),
  // Home: grid de quadrados
  home:         SVG_BASE('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>'),
  // v0.13.1 — Tela ativa: olho (Lucide eye)
  tela:         SVG_BASE('<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>'),
  // v0.19.0 — Arsenal: caixa empilhada (package)
  arsenal:      SVG_BASE('<path d="M16.5 9.4 7.55 4.24"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="m3.27 6.96 8.73 5.05 8.73-5.05"/><path d="M12 22.08V12"/>'),
};

const CATEGORIAS = [
  { slug: 'home',          label: 'Início',        icone: ICONES.home,         desc: 'Atalhos rápidos pra todas as categorias.', mostrarNoNav: false },
  { slug: 'chat',          label: 'Chat',          icone: ICONES.chat,         desc: 'Pergunta rápida — Triagem encontra o agente certo automaticamente.' },
  { slug: 'agentes',       label: 'Agentes',       icone: ICONES.agentes,      desc: 'Catálogo dos 131 agentes — busca, filtros por squad, abrir chat direto.' },
  { slug: 'agendamentos',  label: 'Agendamentos',  icone: ICONES.agendamentos, desc: 'Crons diários de relatórios e tarefas agendadas.' },
  // v0.19.0 — Arsenal substitui Cérebros visivelmente. Páginas clonadas, futuro transcripts, etc.
  { slug: 'arsenal',       label: 'Arsenal',       icone: ICONES.arsenal,      desc: 'Itens capturados pela extensão — páginas clonadas, transcripts, análises.' },
  // v0.19.0 — Cérebros e Skills ocultos até estarem prontos (funcionalidade futura)
  { slug: 'cerebros',      label: 'Cérebros',      icone: ICONES.cerebros,     desc: 'Inventário de produtos com conhecimento curado.', oculto: true },
  { slug: 'skills',        label: 'Skills',        icone: ICONES.skills,       desc: 'Habilidades reutilizáveis dos agentes.', oculto: true },
  // v0.13.1 — Tela ativa: NAO muda de tela, abre modal direto
  { slug: 'tela',          label: 'Analisar tela', icone: ICONES.tela,         desc: 'Pergunte sobre o conteúdo da aba ativa (Gmail, planilha, Supabase etc).', acao: 'modal' },
];

let categoriaAtiva = 'home';
let modoExpandido = false;

function renderNavCategorias() {
  const nav = document.getElementById('nav-categorias');
  if (!nav) return;
  nav.innerHTML = '';
  // Esconde nav inteira durante login
  if (!session?.access_token) {
    nav.style.display = 'none';
    return;
  }
  nav.style.display = '';
  for (const cat of CATEGORIAS) {
    if (cat.mostrarNoNav === false) continue;
    if (cat.oculto) continue; // v0.19.0 — cerebros/skills escondidos até estarem prontos
    const btn = el('button', {
      class: 'px-nav__item' + (categoriaAtiva === cat.slug ? ' px-nav__item--ativo' : ''),
      'data-label': cat.label,
      'aria-label': cat.label,
      title: cat.label,
      html: cat.icone,    // SVG monocromatico inline
    });
    btn.addEventListener('click', () => irPara(cat.slug));
    nav.append(btn);
  }
}

function irPara(slug) {
  // v0.13.1: "tela" eh acao (abre modal) — nao muda categoria nem re-renderiza
  if (slug === 'tela') {
    abrirAnalisarTela();
    return;
  }
  categoriaAtiva = slug;
  renderNavCategorias();
  switch (slug) {
    case 'home':         return renderHome();
    case 'chat':         return renderAgentes('chat');     // v0.9.1: so hero + auto-route
    case 'agentes':      return renderAgentes('agentes');  // v0.9.1: so catalogo navegavel
    case 'agendamentos': return renderAgendamentos();
    case 'arsenal':      return renderArsenal();
    case 'cerebros':     return renderCerebros();
    case 'skills':       return renderSkills();
    default:             return renderHome();
  }
}

// Re-renderiza a categoria atual (preserva modo de Chat vs Agentes)
function renderCategoriaAtual() {
  return irPara(categoriaAtiva);
}

// v0.22.4: Modal com agentes em desenvolvimento (pronto_pra_uso=false)
async function abrirModalBacklogAgentes() {
  document.querySelectorAll('.modal-pinguim').forEach(m => m.remove());
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:560px;max-height:88vh;overflow-y:auto' });

  box.append(el('h3', { class: 'modal-pinguim-titulo' }, '🔧 Agentes em desenvolvimento'));
  box.append(el('p', { class: 'modal-pinguim-mensagem', style: 'color:var(--cor-texto-2);margin-bottom:14px' },
    'Estes agentes existem no catálogo mas ainda não passaram na auditoria de qualidade. Ficam ocultos do catálogo principal até serem ajustados.'));

  const lista = el('div', { style: 'margin-bottom:12px' });
  lista.append(el('div', { class: 'px-meta', style: 'padding:12px;text-align:center' }, 'Carregando…'));
  box.append(lista);

  const btnFechar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  box.append(el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end' }, [btnFechar]));

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);

  try {
    const url = `${SUPABASE_URL}/rest/v1/agentes?select=slug,nome,missao,auditoria_resultado,auditoria_motivo,status,squad_id&pronto_pra_uso=eq.false&order=nome.asc`;
    const r = await fetchProxy(url, {
      method: 'GET',
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Accept-Profile': 'pinguim' },
    });
    lista.innerHTML = '';
    if (!r.ok) throw new Error(r.body?.message || `HTTP ${r.status}`);
    const itens = Array.isArray(r.body) ? r.body : [];
    if (itens.length === 0) {
      lista.append(el('div', { class: 'px-meta', style: 'text-align:center;padding:14px' }, '🎉 Todos os agentes estão prontos!'));
      return;
    }
    const motivoLabel = {
      'PROMPT_RUIM': '✏ Prompt em ajuste',
      'CEREBRO_VAZIO': '🧠 Cérebro sendo alimentado',
      'OUTRO_ERRO': '🐛 Investigação técnica',
      null: '⏳ Aguardando auditoria',
    };
    for (const it of itens) {
      const card = el('div', {
        style: 'padding:10px 12px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);margin-bottom:8px;opacity:0.75',
      });
      card.append(el('div', { style: 'font-weight:500;color:var(--cor-texto);font-size:13px;margin-bottom:3px' }, it.nome || it.slug));
      if (it.missao) card.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:6px' }, it.missao.slice(0, 140)));
      const status = motivoLabel[it.auditoria_resultado] || motivoLabel[null];
      card.append(el('div', { class: 'px-badge', style: 'background:transparent;border:1px solid var(--cor-borda-forte);color:var(--cor-texto-2);font-size:11px' }, status));
      if (it.auditoria_motivo) {
        card.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-top:4px;font-style:italic' }, '"' + it.auditoria_motivo.slice(0, 200) + '"'));
      }
      lista.append(card);
    }
  } catch (e) {
    lista.innerHTML = '';
    lista.append(el('div', { class: 'alerta-erro' }, 'Erro: ' + e.message));
  }
}

// --------- HOME DASHBOARD (tela inicial nova) ---------
function renderHome() {
  conteudo.innerHTML = '';
  setStatus('');
  const nomeUser = session?.user?.email?.split('@')[0] || 'você';

  const home = el('div', { class: 'px-home' });

  // Saudacao + hero
  const saudacao = el('div', { class: 'px-home__saudacao' }, [
    el('span', {}, '👋'),
    el('span', {}, `Olá, ${nomeUser}`),
  ]);

  const hero = el('h1', { class: 'px-home__hero' }, [
    'O que você precisa hoje?',
    // v0.22.4: contador dinâmico — atualiza depois que carregarAgentesESquads termina
    el('span', { class: 'px-home__hero-sub', id: 'px-home-hero-sub' }, 'Carregando agentes prontos…'),
  ]);
  // Carrega contador real (só conta pronto_pra_uso=true)
  setTimeout(async () => {
    try {
      const { agentes } = await carregarAgentesESquads();
      const sub = document.getElementById('px-home-hero-sub');
      if (sub) sub.textContent = `${agentes.length} agentes prontos pra usar. Escolha por onde começar.`;
    } catch (_) {}
  }, 0);

  // Grid de cards
  const grid = el('div', { class: 'px-cat-grid' });

  for (const cat of CATEGORIAS) {
    if (cat.slug === 'home') continue;
    if (cat.oculto) continue; // v0.19.0 — cerebros/skills escondidos
    const card = el('button', { class: 'px-cat-card', 'data-cat': cat.slug }, [
      el('div', { class: 'px-cat-card__icone', html: cat.icone }),
      el('div', { class: 'px-cat-card__corpo' }, [
        el('h3', { class: 'px-cat-card__titulo' }, cat.label),
        el('div', { class: 'px-cat-card__desc' }, cat.desc),
      ]),
      el('span', { class: 'px-cat-card__seta' }, '→'),
    ]);
    card.addEventListener('click', () => irPara(cat.slug));
    grid.append(card);
  }

  home.append(saudacao, hero, grid);
  conteudo.append(home);
}

// --------- AGENDAMENTOS / CEREBROS / SKILLS (placeholders elegantes Fase 2) ---------
// Versao grande do SVG monocromatico — usada no estado vazio das categorias.
function svgGrande(svgString) {
  // troca width/height de 20 pra 48 + stroke-width 1.2 pra ficar mais fino quando grande
  return svgString
    .replace('width="20" height="20"', 'width="48" height="48"')
    .replace('stroke-width="1.5"', 'stroke-width="1.2"');
}

function renderPlaceholderCategoria({ titulo, iconeSvg, mensagem, dica }) {
  conteudo.innerHTML = '';
  const wrap = el('div', { class: 'px-home' });

  // Cabecalho: rotulo + botao expandir
  const cabecalho = el('div', { class: 'px-row', style: 'justify-content:space-between;margin-bottom:8px' }, [
    el('div', { class: 'px-rotulo' }, titulo),
    el('button', {
      class: 'px-icon-btn px-icon-btn--sm',
      title: modoExpandido ? 'Recolher' : 'Expandir',
      'aria-label': modoExpandido ? 'Recolher' : 'Expandir',
    }, [modoExpandido ? '⊟' : '⊞']),
  ]);
  cabecalho.querySelector('button').addEventListener('click', toggleExpandir);

  const vazio = el('div', { class: 'px-vazio' }, [
    el('div', { class: 'px-vazio__icone', html: svgGrande(iconeSvg) }),
    el('h2', { class: 'px-vazio__titulo' }, titulo),
    el('p', { class: 'px-vazio__msg' }, mensagem),
    dica ? el('p', { class: 'px-meta', style: 'margin-top:12px;max-width:280px' }, dica) : null,
  ].filter(Boolean));

  wrap.append(cabecalho, vazio);
  conteudo.append(wrap);
}

// =====================================================================
// AGENDAMENTOS — v0.10.0 (consome Edge Function `agendamentos` no Supabase)
// =====================================================================

async function agendamentoEdge(acao, body = {}) {
  const url = `${SUPABASE_URL}/functions/v1/agendamentos`;
  const r = await fetchProxy(url, {
    method: 'POST',
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ acao, ...body }),
  });
  if (!r.ok) throw new Error(`Edge agendamentos ${r.status}: ${(r.body?.erro || JSON.stringify(r.body || {})).slice(0, 200)}`);
  return r.body;
}

function descreverProximaExecucao(cron_expr) {
  // Best-effort: parse "M H * * D" pra dar hora de execucao. Sem libraria de cron.
  // Suporta padroes simples (diario, semanal). Cai pro cron_expr cru se nao conseguir.
  if (!cron_expr) return null;
  const partes = String(cron_expr).trim().split(/\s+/);
  if (partes.length !== 5) return null;
  const [m, h, dom, mes, dow] = partes;
  if (m.includes(',') || h.includes(',')) return null;  // multi-disparo
  if (m === '*' || h === '*') return null;
  const hh = String(h).padStart(2, '0');
  const mm = String(m).padStart(2, '0');
  // UTC → BRT (-3h)
  let hutc = parseInt(h, 10);
  let mbrt = parseInt(m, 10);
  let hbrt = hutc - 3;
  if (hbrt < 0) hbrt += 24;
  const hbrtStr = String(hbrt).padStart(2, '0');
  const mbrtStr = String(mbrt).padStart(2, '0');
  if (dom === '*' && mes === '*' && dow === '*') return `Todo dia às ${hbrtStr}:${mbrtStr} BRT`;
  if (dow !== '*' && dom === '*') {
    const dias = { '0':'dom','1':'seg','2':'ter','3':'qua','4':'qui','5':'sex','6':'sab' };
    const lista = dow.split(',').map(d => dias[d.trim()] || d.trim()).join('/');
    return `${lista} às ${hbrtStr}:${mbrtStr} BRT`;
  }
  return `${hbrtStr}:${mbrtStr} BRT (${cron_expr})`;
}

function badgeStatus(ultimo_status) {
  if (!ultimo_status) return el('span', { class: 'px-badge' }, '—');
  const s = String(ultimo_status);
  if (s.startsWith('ok')) return el('span', { class: 'px-badge', style: 'color:var(--cor-sucesso)' }, 'OK');
  if (s.startsWith('falhou') || s.startsWith('erro')) return el('span', { class: 'px-badge', style: 'color:var(--cor-erro)' }, 'Falhou');
  if (s.startsWith('pulado')) return el('span', { class: 'px-badge' }, 'Pulado');
  if (s.startsWith('rodando') || s.startsWith('em_progresso')) return el('span', { class: 'px-badge' }, 'Rodando');
  return el('span', { class: 'px-badge' }, s.slice(0, 16));
}

function formatarTimestampBR(ts) {
  if (!ts) return '—';
  try {
    const d = new Date(ts);
    if (isNaN(d.getTime())) return '—';
    const data = d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    const hora = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    return `${data} ${hora}`;
  } catch { return '—'; }
}

async function confirmar(msg) {
  return mostrarConfirmacao({
    titulo: 'Confirma?',
    mensagem: msg,
    textoConfirmar: 'Sim',
    textoCancelar: 'Cancelar',
    destrutivo: msg.toLowerCase().includes('excluir') || msg.toLowerCase().includes('deletar'),
  });
}

// =====================================================================
// v0.12.0: renderAgendamentos com paridade Mission Control
// =====================================================================
// Estrutura:
//   [Cabecalho: rotulo + expandir]
//   [Hero "Agendamentos" + subtitulo]
//   [Cards stats: Ativos / Pausados / Total]  + botao "+ Novo agendamento" a direita
//   [Proximos Disparos: toggle Lista | Semana]
//   [Filtros: busca + status + canal + destinatario]
//   [Grupo ATIVOS — grid responsivo de cards]
//   [Grupo PAUSADOS — idem]

// Estado de filtros — mantido entre re-renders dentro da mesma sessao
let agendFiltros = { busca: '', status: 'todos', canal: 'todos', destinatario: 'todos' };
let agendModoView = 'lista';  // 'lista' | 'semana'

async function renderAgendamentos() {
  conteudo.innerHTML = '';
  setStatus('Carregando agendamentos...');

  const wrap = el('div', { class: 'px-home' });

  // Cabecalho (rotulo + expandir)
  const cabecalho = el('div', { class: 'px-row', style: 'justify-content:space-between;margin-bottom:8px' }, [
    el('div', { class: 'px-rotulo' }, 'Agendamentos'),
    el('button', {
      class: 'px-icon-btn px-icon-btn--sm',
      title: modoExpandido ? 'Recolher' : 'Expandir',
      'aria-label': modoExpandido ? 'Recolher' : 'Expandir',
    }, [modoExpandido ? '⊟' : '⊞']),
  ]);
  cabecalho.querySelector('button').addEventListener('click', toggleExpandir);
  wrap.append(cabecalho);

  // Hero
  const hero = el('h1', { class: 'px-home__hero' }, [
    'Agendamentos',
    el('span', { class: 'px-home__hero-sub' }, 'Relatórios automáticos rodando via cron. Mesmo poder do Mission Control.'),
  ]);
  wrap.append(hero);

  // Container raiz pro corpo dinamico
  const corpoWrap = el('div', { id: 'agend-corpo', style: 'margin-top:16px' });
  wrap.append(corpoWrap);

  conteudo.append(wrap);

  // Pinguim animado durante carga inicial
  const loadEl = el('div', { class: 'px-pinguim-load', style: 'padding:32px 0' }, []);
  const svgWrap = el('div', { html: PINGUIM_SVG });
  loadEl.append(svgWrap.firstElementChild);
  loadEl.append(el('div', { class: 'px-pinguim-load__msg' }, 'Buscando seus agendamentos...'));
  corpoWrap.append(loadEl);

  // Carrega
  let agendamentos = [];
  try {
    const resp = await agendamentoEdge('listar');
    agendamentos = resp.agendamentos || [];
  } catch (e) {
    corpoWrap.innerHTML = '';
    const msg = (e.message || '').toLowerCase();
    if (msg.includes('extension context invalidated') || msg.includes('receiving end does not exist')) {
      const box = el('div', { class: 'px-vazio' }, [
        el('div', { class: 'px-vazio__icone' }, '⚠'),
        el('h2', { class: 'px-vazio__titulo' }, 'Extensão atualizada'),
        el('p', { class: 'px-vazio__msg' },
          'Esta aba ainda está rodando a versão antiga. Precisa recarregar pra usar a nova.'),
        (() => {
          const btn = el('button', { class: 'px-btn px-btn--primario', style: 'margin-top:12px' }, '🔄 Recarregar a página');
          btn.addEventListener('click', () => {
            window.parent.postMessage({ pinguimTipo: 'RECARREGAR_PAGINA' }, '*');
          });
          return btn;
        })(),
        el('p', { class: 'px-meta', style: 'margin-top:8px' }, 'Ou aperte F5 manualmente.'),
      ]);
      corpoWrap.append(box);
      setStatus('Aba desatualizada');
      return;
    }
    corpoWrap.append(el('div', { class: 'alerta-erro' }, 'Erro ao carregar: ' + e.message));
    setStatus('Erro');
    return;
  }

  setStatus(`${agendamentos.length} agendamento${agendamentos.length === 1 ? '' : 's'}`);
  corpoWrap.innerHTML = '';

  if (agendamentos.length === 0) {
    corpoWrap.append(el('div', { class: 'px-vazio' }, [
      el('div', { class: 'px-vazio__icone', html: svgGrande(ICONES.agendamentos) }),
      el('h2', { class: 'px-vazio__titulo' }, 'Nenhum agendamento'),
      el('p', { class: 'px-vazio__msg' }, 'Quando você criar um cron de relatório, ele aparece aqui.'),
      (() => {
        const btn = el('button', { class: 'px-btn px-btn--primario', style: 'margin-top:12px' }, '+ Criar primeiro agendamento');
        btn.addEventListener('click', async () => {
          const r = await abrirFormAgendamento({});
          if (r) renderAgendamentos();
        });
        return btn;
      })(),
    ]));
    return;
  }

  // ----- 1) STATS + botao novo -----
  const ativos = agendamentos.filter(a => a.ativo);
  const pausados = agendamentos.filter(a => !a.ativo);
  const statsBox = el('div', { class: 'agend-stats' }, [
    (() => {
      const c = el('div', { class: 'agend-stat-card agend-stat-card--ativos' }, [
        el('div', { class: 'agend-stat-num', id: 'stat-ativos' }, String(ativos.length)),
        el('div', { class: 'agend-stat-rotulo' }, 'ATIVOS'),
      ]);
      return c;
    })(),
    (() => {
      const c = el('div', { class: 'agend-stat-card' }, [
        el('div', { class: 'agend-stat-num', id: 'stat-pausados' }, String(pausados.length)),
        el('div', { class: 'agend-stat-rotulo' }, 'PAUSADOS'),
      ]);
      return c;
    })(),
    (() => {
      const c = el('div', { class: 'agend-stat-card' }, [
        el('div', { class: 'agend-stat-num', id: 'stat-total' }, String(agendamentos.length)),
        el('div', { class: 'agend-stat-rotulo' }, 'TOTAL'),
      ]);
      return c;
    })(),
    (() => {
      const btn = el('button', { class: 'px-btn px-btn--primario', style: 'flex:1;min-width:140px;justify-content:center' }, '+ Novo agendamento');
      btn.addEventListener('click', async () => {
        const r = await abrirFormAgendamento({});
        if (r) renderAgendamentos();
      });
      return btn;
    })(),
  ]);
  corpoWrap.append(statsBox);

  // ----- 2) PROXIMOS DISPAROS — toggle Lista | Semana -----
  corpoWrap.append(renderProximosDisparos(agendamentos));

  // ----- 3) FILTROS -----
  // Coleta valores únicos pra dropdowns
  const canaisDisponiveis = new Set();
  const destinatariosDisponiveis = new Map();  // valor → label
  for (const ag of agendamentos) {
    for (const d of (ag.destinatarios || [])) {
      if (d.canal) canaisDisponiveis.add(d.canal);
      if (d.valor) destinatariosDisponiveis.set(d.valor, d.nome || d.valor);
    }
  }

  const filtrosBox = el('div', { class: 'agend-filtros' }, [
    (() => {
      const inp = el('input', {
        type: 'text', class: 'px-input', placeholder: '🔎 buscar nome, slug, destinatário...',
        value: agendFiltros.busca,
        style: 'flex:1;min-width:200px',
      });
      inp.addEventListener('input', (ev) => {
        agendFiltros.busca = ev.target.value;
        atualizarListaFiltrada(agendamentos);
      });
      return inp;
    })(),
    (() => {
      const sel = el('select', { class: 'px-input', style: 'flex:0 0 auto;min-width:120px' }, [
        el('option', { value: 'todos' }, 'Status: todos'),
        el('option', { value: 'ativos' }, 'Só ativos'),
        el('option', { value: 'pausados' }, 'Só pausados'),
      ]);
      sel.value = agendFiltros.status;
      sel.addEventListener('change', (ev) => {
        agendFiltros.status = ev.target.value;
        atualizarListaFiltrada(agendamentos);
      });
      return sel;
    })(),
    (() => {
      const opts = [el('option', { value: 'todos' }, 'Canal: todos')];
      for (const c of [...canaisDisponiveis].sort()) opts.push(el('option', { value: c }, c));
      const sel = el('select', { class: 'px-input', style: 'flex:0 0 auto;min-width:120px' }, opts);
      sel.value = agendFiltros.canal;
      sel.addEventListener('change', (ev) => {
        agendFiltros.canal = ev.target.value;
        atualizarListaFiltrada(agendamentos);
      });
      return sel;
    })(),
    (() => {
      const opts = [el('option', { value: 'todos' }, 'Destinatário: todos')];
      for (const [v, lab] of destinatariosDisponiveis) opts.push(el('option', { value: v }, lab.length > 24 ? lab.slice(0, 22) + '…' : lab));
      const sel = el('select', { class: 'px-input', style: 'flex:0 0 auto;min-width:140px' }, opts);
      sel.value = agendFiltros.destinatario;
      sel.addEventListener('change', (ev) => {
        agendFiltros.destinatario = ev.target.value;
        atualizarListaFiltrada(agendamentos);
      });
      return sel;
    })(),
  ]);
  corpoWrap.append(filtrosBox);

  // ----- 4) LISTA DE CARDS (com grid responsivo) -----
  const grupoAtivos = el('div', { class: 'agend-grupo' });
  const grupoPausados = el('div', { class: 'agend-grupo', style: 'margin-top:24px' });
  corpoWrap.append(grupoAtivos, grupoPausados);

  // Funcao que aplica filtros e renderiza
  function atualizarListaFiltrada(todos) {
    const filtrados = todos.filter(ag => {
      // Status
      if (agendFiltros.status === 'ativos' && !ag.ativo) return false;
      if (agendFiltros.status === 'pausados' && ag.ativo) return false;
      // Busca textual
      if (agendFiltros.busca) {
        const q = agendFiltros.busca.toLowerCase();
        const hay = [ag.nome, ag.slug, ag.descricao, ...(ag.destinatarios || []).map(d => (d.nome || '') + ' ' + d.valor)].join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      // Canal
      if (agendFiltros.canal !== 'todos') {
        const temCanal = (ag.destinatarios || []).some(d => d.canal === agendFiltros.canal);
        if (!temCanal) return false;
      }
      // Destinatario
      if (agendFiltros.destinatario !== 'todos') {
        const temDest = (ag.destinatarios || []).some(d => d.valor === agendFiltros.destinatario);
        if (!temDest) return false;
      }
      return true;
    });

    const filtAtivos = filtrados.filter(a => a.ativo);
    const filtPausados = filtrados.filter(a => !a.ativo);

    // Re-render grupo ATIVOS
    grupoAtivos.innerHTML = '';
    if (filtAtivos.length > 0) {
      grupoAtivos.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:8px' },
        `ATIVOS · ${filtAtivos.length}`));
      const grid = el('div', { class: 'agend-grid' });
      for (const ag of filtAtivos) grid.append(renderCardAgendamento(ag));
      grupoAtivos.append(grid);
    }

    // Re-render grupo PAUSADOS
    grupoPausados.innerHTML = '';
    if (filtPausados.length > 0) {
      grupoPausados.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:8px' },
        `PAUSADOS · ${filtPausados.length}`));
      const grid = el('div', { class: 'agend-grid' });
      for (const ag of filtPausados) grid.append(renderCardAgendamento(ag));
      grupoPausados.append(grid);
    }

    // Se nenhum resultado
    if (filtAtivos.length === 0 && filtPausados.length === 0) {
      grupoAtivos.append(el('div', { class: 'px-vazio', style: 'padding:24px' }, [
        el('h2', { class: 'px-vazio__titulo' }, 'Nenhum agendamento corresponde'),
        el('p', { class: 'px-vazio__msg' }, 'Ajusta os filtros ou limpa a busca.'),
      ]));
    }
  }

  atualizarListaFiltrada(agendamentos);
}

// =====================================================================
// v0.12.0: Bloco "Próximos Disparos" — projeção dos crons em janela de 7 dias
// =====================================================================

function renderProximosDisparos(agendamentos) {
  const box = el('div', { class: 'agend-proximos' });

  const header = el('div', { class: 'px-row', style: 'justify-content:space-between;margin-bottom:8px' }, [
    el('div', { class: 'px-rotulo' }, '📅 Próximos disparos · 7 dias'),
    (() => {
      const toggle = el('div', { class: 'agend-toggle' });
      const btnLista = el('button', { class: 'agend-toggle-btn' + (agendModoView === 'lista' ? ' agend-toggle-btn--ativo' : ''), type: 'button' }, '☰ Lista');
      const btnSemana = el('button', { class: 'agend-toggle-btn' + (agendModoView === 'semana' ? ' agend-toggle-btn--ativo' : ''), type: 'button' }, '🗓 Semana');
      btnLista.addEventListener('click', () => {
        if (agendModoView === 'lista') return;
        agendModoView = 'lista';
        renderAgendamentos();  // re-render rápido (já tem dados)
      });
      btnSemana.addEventListener('click', () => {
        if (agendModoView === 'semana') return;
        agendModoView = 'semana';
        renderAgendamentos();
      });
      toggle.append(btnLista, btnSemana);
      return toggle;
    })(),
  ]);
  box.append(header);

  // Calcula todos próximos disparos dos agendamentos ATIVOS nas próximas 7 dias
  const ativos = agendamentos.filter(a => a.ativo && a.cron_expr);
  const eventos = [];  // { ag, dataUtc, brt }
  for (const ag of ativos) {
    const proximos = proximasNExecucoes(ag.cron_expr, 30);  // até 30 por agendamento
    for (const dataUtc of proximos) {
      const brt = dateUtcParaBRT(dataUtc);
      eventos.push({ ag, dataUtc, brt });
    }
  }
  // Ordena por horário
  eventos.sort((a, b) => a.dataUtc - b.dataUtc);

  // Limita: só próximos 7 dias
  const hoje = new Date();
  const limite7d = new Date(hoje.getTime() + 7 * 24 * 60 * 60 * 1000);
  const dentro7d = eventos.filter(e => e.dataUtc < limite7d);

  if (dentro7d.length === 0) {
    box.append(el('div', { class: 'px-meta', style: 'padding:20px;text-align:center' },
      'Nenhum disparo programado nos próximos 7 dias.'));
    return box;
  }

  // Render conforme modo
  if (agendModoView === 'lista') {
    box.append(renderProximosListaView(dentro7d));
  } else {
    box.append(renderProximosSemanaView(dentro7d));
  }

  // Sumario rodapé
  const diasUnicos = new Set(dentro7d.map(e => e.brt.data));
  box.append(el('div', { class: 'px-meta', style: 'margin-top:8px;text-align:right' },
    `7d · ${dentro7d.length} disparos · ${diasUnicos.size} dias`));

  return box;
}

function renderProximosListaView(eventos) {
  // Agrupa por dia BRT
  const porDia = new Map();
  for (const ev of eventos) {
    if (!porDia.has(ev.brt.data)) porDia.set(ev.brt.data, []);
    porDia.get(ev.brt.data).push(ev);
  }

  const wrap = el('div', { class: 'agend-prox-lista' });
  const hojeBrt = dateUtcParaBRT(new Date()).data;

  for (const [data, items] of porDia) {
    const dataObj = new Date(data + 'T12:00:00Z');
    const ehHoje = data === hojeBrt;
    // Calcula amanhã BRT
    const amanha = new Date(Date.now() + 24 * 60 * 60 * 1000);
    const amanhaBrt = dateUtcParaBRT(amanha).data;
    const ehAmanha = data === amanhaBrt;
    const diasSem = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB'];
    const rotulo = ehHoje ? 'HOJE' : ehAmanha ? 'AMANHÃ' : diasSem[dataObj.getUTCDay()];

    const colDia = el('div', { class: 'agend-prox-col' });
    colDia.append(el('div', { class: 'agend-prox-col__header' + (ehHoje ? ' agend-prox-col__header--hoje' : '') }, [
      el('div', { class: 'agend-prox-col__rotulo' }, rotulo),
      el('div', { class: 'agend-prox-col__data' }, data.split('-').reverse().slice(0, 2).join('/')),
    ]));

    for (const ev of items.slice(0, 12)) {  // limita 12 por dia pra evitar muito scroll
      const item = el('div', { class: 'agend-prox-item' });
      item.append(
        el('span', { class: 'agend-prox-item__hora' }, `${ev.brt.hora}:${ev.brt.minuto}`),
        el('span', { class: 'agend-prox-item__nome' }, ev.ag.nome),
      );
      colDia.append(item);
    }
    if (items.length > 12) {
      colDia.append(el('div', { class: 'px-meta', style: 'padding:4px 8px' }, `+${items.length - 12} mais`));
    }
    wrap.append(colDia);
  }
  return wrap;
}

function renderProximosSemanaView(eventos) {
  // Agrupa por dia + hora (grid 7 colunas × horas)
  // Coleta horas únicas dos eventos pra montar linhas (5h-23h só se houver)
  const hojeBrt = dateUtcParaBRT(new Date()).data;
  const diasOrdenados = [];
  const eventosPorChave = new Map();  // "data|hora" → [eventos]
  const horasComEvento = new Set();

  for (const ev of eventos) {
    const chave = `${ev.brt.data}|${ev.brt.hora}`;
    if (!eventosPorChave.has(chave)) eventosPorChave.set(chave, []);
    eventosPorChave.get(chave).push(ev);
    horasComEvento.add(ev.brt.hora);
    if (!diasOrdenados.includes(ev.brt.data)) diasOrdenados.push(ev.brt.data);
  }
  diasOrdenados.sort();
  const horasOrdenadas = [...horasComEvento].sort();

  const diasSem = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SAB'];

  const grid = el('div', { class: 'agend-prox-semana' });
  // Header com dias da semana
  const headerRow = el('div', { class: 'agend-prox-semana__header' });
  headerRow.append(el('div', { class: 'agend-prox-semana__cantoH' }, ''));
  for (const data of diasOrdenados) {
    const dataObj = new Date(data + 'T12:00:00Z');
    const ehHoje = data === hojeBrt;
    headerRow.append(el('div', { class: 'agend-prox-semana__diaCol' + (ehHoje ? ' agend-prox-semana__diaCol--hoje' : '') }, [
      el('div', { class: 'agend-prox-semana__diaRot' }, diasSem[dataObj.getUTCDay()]),
      el('div', { class: 'agend-prox-semana__diaData' }, data.split('-').reverse().slice(0, 2).join('/')),
    ]));
  }
  grid.append(headerRow);

  // Linhas: uma por hora
  for (const hora of horasOrdenadas) {
    const linha = el('div', { class: 'agend-prox-semana__linha' });
    linha.append(el('div', { class: 'agend-prox-semana__horaH' }, `${hora}h`));
    for (const data of diasOrdenados) {
      const cell = el('div', { class: 'agend-prox-semana__cell' });
      const lista = eventosPorChave.get(`${data}|${hora}`) || [];
      for (const ev of lista) {
        const pill = el('div', { class: 'agend-prox-semana__pill' });
        pill.append(
          el('span', { class: 'agend-prox-semana__pillMin' }, `:${ev.brt.minuto}`),
          el('span', { class: 'agend-prox-semana__pillNome' }, ev.ag.nome),
        );
        cell.append(pill);
      }
      linha.append(cell);
    }
    grid.append(linha);
  }
  return grid;
}

function renderCardAgendamento(ag) {
  const card = el('div', {
    class: 'px-card px-card--sm',
    style: 'padding:14px 16px;cursor:default;display:flex;flex-direction:column;gap:8px' + (ag.ativo ? '' : ';opacity:0.55'),
    'data-id': ag.id,
    'data-ag-id': ag.id,  // v0.12.0: usado pelo refreshCardAgendamento
  });

  // Linha 1: nome + status
  const linha1 = el('div', { class: 'px-row', style: 'justify-content:space-between;gap:8px' }, [
    el('div', { style: 'flex:1;min-width:0' }, [
      el('div', { class: 'px-cat-card__titulo', style: 'font-size:14px;margin:0' }, ag.nome || ag.slug),
      el('div', { class: 'px-meta' }, ag.slug + ' · ' + (ag.ativo ? '🟢 ativo' : '⏸ pausado')),
    ]),
    badgeStatus(ag.ultimo_status),
  ]);
  card.append(linha1);

  // Linha 2: cron + ultima execucao
  const linha2 = el('div', { class: 'px-row', style: 'gap:8px;flex-wrap:wrap;font-size:12px;color:var(--cor-texto-2)' }, [
    el('span', {}, '⏰ ' + (ag.cron_descricao || descreverProximaExecucao(ag.cron_expr) || ag.cron_expr || '—')),
    el('span', {}, '·'),
    el('span', {}, 'última: ' + formatarTimestampBR(ag.ultima_execucao)),
  ]);
  card.append(linha2);

  // Linha 3: destinatarios resumo
  const destLista = Array.isArray(ag.destinatarios) ? ag.destinatarios : [];
  const destAtivos = destLista.filter(d => d.ativo);
  if (destLista.length > 0) {
    const linhaDest = el('div', { style: 'font-size:12px;color:var(--cor-texto-3)' },
      `📱 ${destAtivos.length}/${destLista.length} destinatário${destLista.length === 1 ? '' : 's'} ativo${destAtivos.length === 1 ? '' : 's'}`);
    card.append(linhaDest);
  }

  // Linha 4: acoes
  const acoes = el('div', { class: 'px-row', style: 'gap:6px;margin-top:4px;flex-wrap:wrap' });

  // Disparar
  const btnDisparar = el('button', { class: 'px-btn px-btn--sm', title: 'Disparar agora (gera relatório imediato)' }, '▶ Disparar');
  btnDisparar.addEventListener('click', async () => {
    const ok = await confirmar(`Disparar "${ag.nome}" agora? Vai gerar relatório imediato.`);
    if (!ok) return;
    btnDisparar.disabled = true;
    btnDisparar.textContent = 'Disparando...';
    try {
      await agendamentoEdge('disparar_agora', { id: ag.id });
      mostrarAlerta({ titulo: 'Job enfileirado', mensagem: 'O relatório vai ser gerado em alguns segundos. Volta no Mission Control pra ver o entregável quando ficar pronto.' });
      renderAgendamentos();
    } catch (e) {
      mostrarAlerta({ titulo: 'Falha', mensagem: e.message, tipo: 'erro' });
      btnDisparar.disabled = false;
      btnDisparar.textContent = '▶ Disparar';
    }
  });
  acoes.append(btnDisparar);

  // Pausar / Reativar
  if (ag.ativo) {
    const btnPausar = el('button', { class: 'px-btn px-btn--sm', title: 'Pausar (não dispara mais até reativar)' }, '⏸ Pausar');
    btnPausar.addEventListener('click', async () => {
      const ok = await confirmar(`Pausar "${ag.nome}"? Não vai mais disparar até você reativar.`);
      if (!ok) return;
      btnPausar.disabled = true;
      try {
        await agendamentoEdge('pausar', { id: ag.id });
        renderAgendamentos();
      } catch (e) {
        mostrarAlerta({ titulo: 'Falha', mensagem: e.message, tipo: 'erro' });
        btnPausar.disabled = false;
      }
    });
    acoes.append(btnPausar);
  } else {
    const btnReativar = el('button', { class: 'px-btn px-btn--sm px-btn--primario', title: 'Reativar (volta a rodar no horário)' }, '▶ Reativar');
    btnReativar.addEventListener('click', async () => {
      const ok = await confirmar(`Reativar "${ag.nome}"? Vai voltar a rodar no horário (${ag.cron_descricao || ag.cron_expr}).`);
      if (!ok) return;
      btnReativar.disabled = true;
      try {
        await agendamentoEdge('reativar', { id: ag.id });
        renderAgendamentos();
      } catch (e) {
        mostrarAlerta({ titulo: 'Falha', mensagem: e.message, tipo: 'erro' });
        btnReativar.disabled = false;
      }
    });
    acoes.append(btnReativar);
  }

  // v0.11.0: Editar
  const btnEditar = el('button', { class: 'px-btn px-btn--sm px-btn--ghost', title: 'Editar nome, descrição, horário, módulos' }, '✏ Editar');
  btnEditar.addEventListener('click', async () => {
    const r = await abrirFormAgendamento({ agendamento: ag });
    if (r) renderAgendamentos();
  });
  acoes.append(btnEditar);

  // v0.11.0: Destinatários
  const btnDest = el('button', { class: 'px-btn px-btn--sm px-btn--ghost', title: 'Gerenciar destinatários' }, '👥 Destinatários');
  btnDest.addEventListener('click', () => abrirModalDestinatarios(ag));
  acoes.append(btnDest);

  // Ver últimos disparos
  const btnHistorico = el('button', { class: 'px-btn px-btn--sm px-btn--ghost', title: 'Ver últimas 10 execuções' }, '📋 Histórico');
  btnHistorico.addEventListener('click', () => mostrarHistoricoDisparos(ag));
  acoes.append(btnHistorico);

  // Excluir
  const btnExcluir = el('button', { class: 'px-btn px-btn--sm px-btn--ghost', title: 'Excluir (irreversível)' }, '🗑');
  btnExcluir.addEventListener('click', async () => {
    const ok = await confirmar(`EXCLUIR definitivamente "${ag.nome}"? Essa ação é IRREVERSÍVEL — cron + destinatários + histórico vão sumir.`);
    if (!ok) return;
    btnExcluir.disabled = true;
    try {
      await agendamentoEdge('excluir', { id: ag.id });
      renderAgendamentos();
    } catch (e) {
      mostrarAlerta({ titulo: 'Falha', mensagem: e.message, tipo: 'erro' });
      btnExcluir.disabled = false;
    }
  });
  acoes.append(btnExcluir);

  card.append(acoes);
  return card;
}

async function mostrarHistoricoDisparos(ag) {
  // Modal usando padrão `modal-pinguim` que já existe nos confirmadores
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:520px' });
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, `Histórico — ${ag.nome}`));
  const corpo = el('div', { style: 'max-height:60vh;overflow-y:auto;margin:12px 0' });
  corpo.append(el('div', { class: 'px-meta' }, 'Carregando...'));
  box.append(corpo);

  const acoesModal = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end' });
  const btnFechar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  acoesModal.append(btnFechar);
  box.append(acoesModal);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);

  try {
    const resp = await agendamentoEdge('ultimos_disparos', { id: ag.id, limite: 10 });
    corpo.innerHTML = '';
    const lista = resp.disparos || [];
    if (lista.length === 0) {
      corpo.append(el('div', { class: 'px-meta' }, 'Nenhum disparo registrado ainda.'));
      return;
    }
    for (const d of lista) {
      const ok = String(d.status) === 'succeeded';
      const item = el('div', {
        class: 'px-card px-card--sm',
        style: 'padding:10px 12px;margin-bottom:6px;display:flex;flex-direction:column;gap:4px',
      });
      item.append(el('div', { class: 'px-row', style: 'justify-content:space-between' }, [
        el('span', { style: 'font-size:12px' }, formatarTimestampBR(d.start_time)),
        el('span', { class: 'px-badge', style: 'color:' + (ok ? 'var(--cor-sucesso)' : 'var(--cor-erro)') }, ok ? 'OK' : String(d.status || '?')),
      ]));
      if (d.return_message) {
        item.append(el('div', { class: 'px-meta', style: 'word-break:break-word' }, String(d.return_message).slice(0, 200)));
      }
      corpo.append(item);
    }
  } catch (e) {
    corpo.innerHTML = '';
    corpo.append(el('div', { class: 'alerta-erro' }, 'Erro ao buscar histórico: ' + e.message));
  }
}

// =====================================================================
// v0.11.0: Helpers de CRON em portugues coloquial → UTC
// =====================================================================
// Andre digita "todo dia 8h" — converte pra cron_expr UTC + cron_descricao em PT-BR.
// Sem libraria — handcrafted pros padroes mais comuns.

const DIAS_MAP_PT = {
  'dom': 0, 'domingo': 0,
  'seg': 1, 'segunda': 1, 'segunda-feira': 1,
  'ter': 2, 'terca': 2, 'terça': 2, 'terça-feira': 2,
  'qua': 3, 'quarta': 3, 'quarta-feira': 3,
  'qui': 4, 'quinta': 4, 'quinta-feira': 4,
  'sex': 5, 'sexta': 5, 'sexta-feira': 5,
  'sab': 6, 'sabado': 6, 'sábado': 6,
};

const DIAS_NOME_CURTO = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'];

// Converte hora BRT (humana) pra UTC, retorna { hUtc, mUtc, hBrt, mBrt }
function brtParaUtc(hBrt, mBrt) {
  let hUtc = hBrt + 3;
  if (hUtc >= 24) hUtc -= 24;
  return { hUtc, mUtc: mBrt };
}

// Tenta parsear "8h", "8h30", "8:30", "08:00", "8" → {h, m}
function parsearHora(t) {
  if (!t) return null;
  let m = String(t).trim().toLowerCase();
  // "8h30" ou "8:30"
  let match = m.match(/^(\d{1,2})\s*(?:h|:)\s*(\d{1,2})\s*(?:h|min|m)?$/);
  if (match) return { h: parseInt(match[1], 10), m: parseInt(match[2], 10) };
  // "8h" ou "8"
  match = m.match(/^(\d{1,2})\s*h?$/);
  if (match) return { h: parseInt(match[1], 10), m: 0 };
  return null;
}

// Tenta parsear "todo dia", "diariamente", "todos os dias"
function ehDiario(t) {
  const m = String(t).toLowerCase();
  return /todo\s*dia|todos\s*os\s*dias|diariamente|toda\s*hora/.test(m);
}

// Tenta parsear "seg/qua/sex", "segunda e quarta", "seg, qua, sex"
function parsearDiasSemana(t) {
  const m = String(t).toLowerCase();
  const dias = new Set();
  const tokens = m.split(/[\s,/+&]|\se\s/).filter(x => x.length >= 3);
  for (const tk of tokens) {
    const limpo = tk.replace(/-feira$/, '').replace(/[^a-zçãéúí]/g, '');
    if (DIAS_MAP_PT[limpo] !== undefined) dias.add(DIAS_MAP_PT[limpo]);
  }
  return dias.size > 0 ? [...dias].sort() : null;
}

// PARSER PRINCIPAL: texto humano → { cron_expr (UTC), cron_descricao (BRT) }
// Aceita: "todo dia 8h", "todo dia 8h30", "seg/qua/sex 9h", "toda segunda 8h",
//         "a cada 15 minutos", "*/15 * * * *" (cron cru passa direto)
function parsearCronHumano(texto) {
  if (!texto) return null;
  const t = String(texto).trim();
  // Caso 1: cron cru (5 partes separadas por espaco)
  const partes = t.split(/\s+/);
  if (partes.length === 5 && /[\d*/,-]+/.test(partes[0])) {
    return { cron_expr: t, cron_descricao: `cron cru: ${t}` };
  }
  // Caso 2: "a cada N minutos"
  const minMatch = t.match(/a\s*cada\s*(\d+)\s*min/i);
  if (minMatch) {
    const n = parseInt(minMatch[1], 10);
    if (n >= 1 && n <= 59) return { cron_expr: `*/${n} * * * *`, cron_descricao: `a cada ${n} minutos` };
  }

  // Caso 3: tem hora + (todo dia OU dias da semana)
  const hora = parsearHora(t.match(/\d{1,2}\s*(?:h|:)\s*\d{0,2}/)?.[0] || t.match(/\b\d{1,2}h\b/)?.[0] || t.match(/\b\d{1,2}:\d{2}\b/)?.[0] || '');
  if (!hora || hora.h < 0 || hora.h > 23 || hora.m < 0 || hora.m > 59) return null;
  const { hUtc, mUtc } = brtParaUtc(hora.h, hora.m);

  const dias = parsearDiasSemana(t);
  const diario = ehDiario(t) || (!dias && /^[\d\s:h,]+$/.test(t.replace(/h/g, '')));

  const hBrtStr = String(hora.h).padStart(2, '0');
  const mBrtStr = String(hora.m).padStart(2, '0');

  if (diario || !dias) {
    return {
      cron_expr: `${mUtc} ${hUtc} * * *`,
      cron_descricao: `todo dia às ${hBrtStr}:${mBrtStr} BRT`,
    };
  }
  // Dias da semana
  const diasStr = dias.join(',');
  const diasNome = dias.map(d => DIAS_NOME_CURTO[d]).join('/');
  return {
    cron_expr: `${mUtc} ${hUtc} * * ${diasStr}`,
    cron_descricao: `${diasNome} às ${hBrtStr}:${mBrtStr} BRT`,
  };
}

// =====================================================================
// v0.12.0: Projeta próximas N execuções de um cron (cron simples — min hora dom mes dow)
// =====================================================================
// Suporta: minuto fixo (0-59), hora fixa (0-23), dia da semana (0-6 ou ',' separado),
//          asterisco. NÃO suporta: ranges (1-5), step (*/15) misto, lista de horas (8,12).
// Pra casos complexos, devolve [] (silencioso — cron continua valido mas sem preview).
// Retorna Array<Date> em ordem cronológica, no fuso BRT (mas Date eh sempre UTC internamente).
function proximasNExecucoes(cron_expr, n = 20, partidaUtc = new Date()) {
  if (!cron_expr) return [];
  const partes = String(cron_expr).trim().split(/\s+/);
  if (partes.length !== 5) return [];
  const [pM, pH, pDom, pMes, pDow] = partes;

  // Parse cada componente em conjunto permitido
  function parseField(spec, min, max) {
    if (spec === '*') return null;  // null = qualquer
    if (spec.startsWith('*/')) {
      const step = parseInt(spec.slice(2), 10);
      if (!step) return null;
      const out = [];
      for (let v = min; v <= max; v += step) out.push(v);
      return out;
    }
    const out = [];
    for (const tk of spec.split(',')) {
      const v = parseInt(tk, 10);
      if (!isNaN(v) && v >= min && v <= max) out.push(v);
    }
    return out.length > 0 ? out : null;
  }

  const minutos = parseField(pM, 0, 59);
  const horas = parseField(pH, 0, 23);
  const dias = parseField(pDom, 1, 31);
  const meses = parseField(pMes, 1, 12);
  const dows = parseField(pDow, 0, 6);

  // Caso de partida: hoje UTC + 1 minuto (evita executar agora mesmo)
  const inicio = new Date(partidaUtc.getTime() + 60 * 1000);
  // Limite de busca: 14 dias futuros (suficiente pra cobrir 7 dias × N disparos diários)
  const limite = new Date(partidaUtc.getTime() + 14 * 24 * 60 * 60 * 1000);

  const result = [];
  // Iteração linear: a cada minuto verifica se bate cron (ineficiente mas seguro pra cron simples)
  // Otimização: pula direto pros minutos permitidos
  const minSet = minutos ? new Set(minutos) : null;
  const horaSet = horas ? new Set(horas) : null;
  const diaSet = dias ? new Set(dias) : null;
  const mesSet = meses ? new Set(meses) : null;
  const dowSet = dows ? new Set(dows) : null;

  // Avança em saltos de hora pra eficiência. Pra cada hora, testa os minutos do cron.
  const cur = new Date(Date.UTC(
    inicio.getUTCFullYear(), inicio.getUTCMonth(), inicio.getUTCDate(),
    inicio.getUTCHours(), 0, 0, 0
  ));

  while (cur < limite && result.length < n) {
    const yy = cur.getUTCFullYear();
    const mm = cur.getUTCMonth() + 1;
    const dd = cur.getUTCDate();
    const hh = cur.getUTCHours();
    const dow = cur.getUTCDay();

    const matchMes = !mesSet || mesSet.has(mm);
    const matchDia = !diaSet || diaSet.has(dd);
    const matchDow = !dowSet || dowSet.has(dow);
    const matchHora = !horaSet || horaSet.has(hh);

    if (matchMes && matchDow && matchDia && matchHora) {
      // Itera nos minutos válidos dessa hora
      const minutosValidos = minSet ? [...minSet].sort((a, b) => a - b) : Array.from({ length: 60 }, (_, i) => i);
      for (const m of minutosValidos) {
        const candidato = new Date(Date.UTC(yy, mm - 1, dd, hh, m, 0, 0));
        if (candidato > inicio && candidato < limite) {
          result.push(candidato);
          if (result.length >= n) break;
        }
      }
    }
    // Avança 1 hora
    cur.setUTCHours(cur.getUTCHours() + 1);
  }
  return result;
}

// Converte Date UTC → componentes BRT (UTC-3, sem horário de verão hoje no Brasil)
function dateUtcParaBRT(d) {
  const brt = new Date(d.getTime() - 3 * 60 * 60 * 1000);
  return {
    data: brt.toISOString().slice(0, 10),       // YYYY-MM-DD em BRT
    hora: String(brt.getUTCHours()).padStart(2, '0'),
    minuto: String(brt.getUTCMinutes()).padStart(2, '0'),
    diaSemana: brt.getUTCDay(),
    obj: brt,
  };
}

// =====================================================================
// v0.11.0: Modal — Criar / Editar agendamento
// =====================================================================
// Mesma UI pra criar e editar. Se passar `agendamento`, abre em modo edicao.

function abrirFormAgendamento({ agendamento = null, modulosDisponiveis = ['financeiro', 'highlights', 'meta-ads', 'hotmart', 'triagem-emails', 'agenda', 'discord'] } = {}) {
  return new Promise(resolve => {
    const ehEdicao = !!agendamento;
    const overlay = el('div', { class: 'modal-pinguim' });
    const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:520px;max-height:90vh;overflow-y:auto' });
    box.append(el('h3', { class: 'modal-pinguim-titulo' }, ehEdicao ? `✏ Editar ${agendamento.nome}` : '+ Novo agendamento'));

    // Campos
    // v0.12.1: sanitizador de slug (lowercase, espaço/acento → hífen, sem caracteres especiais)
    function sanitizarSlug(s) {
      return String(s || '')
        .toLowerCase()
        .normalize('NFD').replace(/[̀-ͯ]/g, '')  // tira acentos
        .replace(/[^a-z0-9-]+/g, '-')                       // tudo que não é a-z/0-9/- vira hífen
        .replace(/-+/g, '-')                                // colapsa hífens repetidos
        .replace(/^-|-$/g, '')                              // tira hífen do começo/fim
        .slice(0, 60);                                      // limite razoável
    }

    const inputNome = el('input', {
      type: 'text', class: 'px-input',
      placeholder: 'Ex: Relatório Executivo Diário',
      value: agendamento?.nome || '',
    });
    const inputSlug = el('input', {
      type: 'text', class: 'px-input',
      placeholder: 'gerado automaticamente — pode editar',
      value: agendamento?.slug || '',
    });
    if (ehEdicao) inputSlug.disabled = true;  // slug não muda em edição

    // v0.12.1: auto-gera slug do nome ENQUANTO usuario digita (até ele mexer no slug manualmente)
    let slugTocadoManualmente = ehEdicao || !!agendamento?.slug;
    inputNome.addEventListener('input', () => {
      if (!slugTocadoManualmente) {
        inputSlug.value = sanitizarSlug(inputNome.value);
      }
    });
    inputSlug.addEventListener('input', (ev) => {
      // Marca que usuario quer controlar o slug manualmente
      slugTocadoManualmente = true;
      // Sanitiza em tempo real (corrige espaço → hífen, maiúscula → minúscula, etc)
      const valorAntigo = ev.target.value;
      const sanitizado = sanitizarSlug(valorAntigo);
      if (sanitizado !== valorAntigo) {
        // Preserva posição do cursor da melhor forma possível
        const pos = ev.target.selectionStart;
        ev.target.value = sanitizado;
        try { ev.target.setSelectionRange(pos, pos); } catch (_) {}
      }
    });

    const inputDescricao = el('textarea', {
      class: 'px-textarea',
      placeholder: 'O que esse relatório entrega (opcional)',
      rows: 2,
    });
    if (agendamento?.descricao) inputDescricao.value = agendamento.descricao;

    const inputCron = el('input', {
      type: 'text', class: 'px-input',
      placeholder: 'Ex: "todo dia 8h", "seg/qua/sex 9h", "a cada 15 minutos"',
      value: agendamento?.cron_descricao || (agendamento?.cron_expr || ''),
    });
    const previewCron = el('div', { class: 'px-meta', style: 'margin-top:4px' }, '');

    function atualizarPreview() {
      const r = parsearCronHumano(inputCron.value);
      if (r) {
        previewCron.textContent = `→ ${r.cron_descricao} (UTC: ${r.cron_expr})`;
        previewCron.style.color = 'var(--cor-sucesso)';
      } else {
        previewCron.textContent = '⚠ Não consegui interpretar. Use "todo dia 8h", "seg/qua/sex 9h" ou cron cru.';
        previewCron.style.color = 'var(--cor-aviso)';
      }
    }
    inputCron.addEventListener('input', atualizarPreview);
    setTimeout(atualizarPreview, 0);

    // Módulos (checkboxes)
    const modulosAtuais = new Set(agendamento?.modulos || []);
    const modulosBox = el('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;margin-top:4px' });
    const modulosCheckboxes = {};
    for (const m of modulosDisponiveis) {
      const chk = el('input', { type: 'checkbox' });
      if (modulosAtuais.has(m)) chk.checked = true;
      const lab = el('label', {
        class: 'px-badge',
        style: 'cursor:pointer;padding:6px 10px;display:inline-flex;align-items:center;gap:6px;font-size:12px;height:auto',
      }, [chk, m]);
      modulosCheckboxes[m] = chk;
      modulosBox.append(lab);
    }

    // Campo: telefone WhatsApp (só pra CRIAR — edição usa modal de destinatários)
    const inputWhatsapp = el('input', {
      type: 'text', class: 'px-input',
      placeholder: 'Telefone com DDD: 5511999999999',
    });

    // Monta o form
    function rotulo(txt) {
      return el('div', { class: 'px-rotulo', style: 'margin-top:14px;margin-bottom:6px' }, txt);
    }

    const corpo = el('div', { style: 'display:flex;flex-direction:column' }, [
      rotulo('Nome'),
      inputNome,
      rotulo('Slug ' + (ehEdicao ? '(não muda em edição)' : '(identificador único)')),
      inputSlug,
      rotulo('Descrição'),
      inputDescricao,
      rotulo('Quando rodar'),
      inputCron,
      previewCron,
      rotulo('Módulos a incluir'),
      modulosBox,
    ]);

    // Em criação, oferecer 1 destinatário inicial (caso queira já)
    if (!ehEdicao) {
      corpo.append(rotulo('WhatsApp do destinatário inicial (opcional)'));
      corpo.append(inputWhatsapp);
    } else {
      corpo.append(el('div', { class: 'px-meta', style: 'margin-top:14px' },
        'Pra gerenciar destinatários, use o botão "👥 Destinatários" no card.'));
    }

    box.append(corpo);

    // Botões
    const erroBox = el('div', { class: 'alerta-erro', style: 'margin-top:12px;display:none' });
    box.append(erroBox);

    const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end;gap:8px;margin-top:14px' });
    const btnCancelar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Cancelar');
    btnCancelar.addEventListener('click', () => { overlay.remove(); resolve(null); });

    const btnSalvar = el('button', {
      class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button',
    }, ehEdicao ? 'Salvar alterações' : 'Criar agendamento');

    btnSalvar.addEventListener('click', async () => {
      erroBox.style.display = 'none';
      const nome = inputNome.value.trim();
      let slug = inputSlug.value.trim();  // mutavel — sera sanitizado abaixo
      const descricao = inputDescricao.value.trim() || null;
      const cronTexto = inputCron.value.trim();
      const parsed = parsearCronHumano(cronTexto);
      const modulos = Object.entries(modulosCheckboxes).filter(([, c]) => c.checked).map(([m]) => m);
      const whatsapp = inputWhatsapp.value.trim();

      if (!nome) { erroBox.textContent = 'Nome obrigatório.'; erroBox.style.display = 'block'; return; }
      if (!ehEdicao) {
        // v0.12.1: garante sanitização final (caso o usuário cole algo direto)
        slug = sanitizarSlug(slug);
        if (!slug || slug.length < 3) {
          erroBox.textContent = 'Slug muito curto. Digite um nome maior ou edite o slug.';
          erroBox.style.display = 'block'; return;
        }
        inputSlug.value = slug;  // reflete o sanitizado no input
      }
      if (!parsed) { erroBox.textContent = 'Cron inválido — confere o preview.'; erroBox.style.display = 'block'; return; }

      btnSalvar.disabled = true;
      btnSalvar.textContent = 'Salvando...';

      try {
        if (ehEdicao) {
          // Atualizar
          await agendamentoEdge('atualizar', {
            id: agendamento.id,
            campos: { nome, descricao, modulos, cron_expr: parsed.cron_expr, cron_descricao: parsed.cron_descricao },
          });
        } else {
          // Criar
          const destinatarios = [];
          if (whatsapp) {
            destinatarios.push({ canal: 'whatsapp', valor: whatsapp.replace(/\D/g, ''), nome: null });
          }
          await agendamentoEdge('criar', {
            cliente_id: session.user.id,
            slug, nome, descricao, modulos,
            cron_expr: parsed.cron_expr,
            cron_descricao: parsed.cron_descricao,
            destinatarios,
            ativo_inicial: true,
          });
        }
        overlay.remove();
        resolve(true);
      } catch (e) {
        erroBox.textContent = 'Falha: ' + (e.message || 'erro desconhecido');
        erroBox.style.display = 'block';
        btnSalvar.disabled = false;
        btnSalvar.textContent = ehEdicao ? 'Salvar alterações' : 'Criar agendamento';
      }
    });

    acoes.append(btnCancelar, btnSalvar);
    box.append(acoes);

    overlay.append(box);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) { overlay.remove(); resolve(null); } });
    document.body.append(overlay);
    inputNome.focus();
  });
}

// =====================================================================
// v0.11.0: Modal — Gerenciar destinatários (listar, adicionar, editar, toggle, remover)
// =====================================================================

async function abrirModalDestinatarios(ag) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:520px;max-height:90vh;overflow-y:auto' });
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, `👥 Destinatários — ${ag.nome}`));

  const lista = el('div', { style: 'display:flex;flex-direction:column;gap:8px;margin:12px 0' });
  box.append(lista);

  // Form de adicionar (sempre visível)
  box.append(el('div', { class: 'px-rotulo', style: 'margin-top:14px;margin-bottom:6px' }, '+ Adicionar destinatário'));
  const inputNumero = el('input', {
    type: 'text', class: 'px-input',
    placeholder: 'Telefone com DDD: 5511999999999',
    style: 'margin-bottom:6px',
  });
  const inputNomeDest = el('input', {
    type: 'text', class: 'px-input',
    placeholder: 'Nome (opcional)',
    style: 'margin-bottom:6px',
  });
  const erroAdd = el('div', { class: 'alerta-erro', style: 'display:none;margin-top:6px' });
  const btnAdd = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button', style: 'width:100%' }, 'Adicionar');
  box.append(inputNumero, inputNomeDest, btnAdd, erroAdd);

  // v0.12.0: flag indica que houve mudanca — usado pra atualizar card depois
  let houveMudanca = false;

  // Marca que mudou + refresh em background do card pai (sem esperar)
  function notificarMudanca() {
    houveMudanca = true;
    // Refresh do card pai SEM bloquear modal (fire-and-forget)
    refreshCardAgendamento(ag.id);
  }

  async function carregar() {
    lista.innerHTML = '';
    const loadEl = el('div', { class: 'px-meta', style: 'text-align:center;padding:14px' }, 'Carregando...');
    lista.append(loadEl);
    try {
      const resp = await agendamentoEdge('destinatarios_listar', { relatorio_id: ag.id });
      const dests = resp.destinatarios || [];
      lista.innerHTML = '';
      if (dests.length === 0) {
        lista.append(el('div', { class: 'px-meta', style: 'text-align:center;padding:12px' }, 'Nenhum destinatário ainda. Adiciona um abaixo.'));
        return;
      }
      for (const d of dests) {
        lista.append(renderItemDestinatario(d, () => { notificarMudanca(); carregar(); }));
      }
    } catch (e) {
      lista.innerHTML = '';
      lista.append(el('div', { class: 'alerta-erro' }, 'Erro: ' + e.message));
    }
  }

  btnAdd.addEventListener('click', async () => {
    erroAdd.style.display = 'none';
    const numero = inputNumero.value.replace(/\D/g, '');
    const nomeD = inputNomeDest.value.trim() || null;
    if (numero.length < 10) {
      erroAdd.textContent = 'Telefone inválido (precisa do DDD, ex: 5511999999999).';
      erroAdd.style.display = 'block';
      return;
    }
    btnAdd.disabled = true;
    btnAdd.textContent = 'Adicionando...';
    try {
      await agendamentoEdge('destinatario_add', {
        relatorio_id: ag.id, canal: 'whatsapp', valor: numero, nome: nomeD,
      });
      inputNumero.value = '';
      inputNomeDest.value = '';
      notificarMudanca();
      carregar();
    } catch (e) {
      erroAdd.textContent = 'Falha: ' + e.message;
      erroAdd.style.display = 'block';
    } finally {
      btnAdd.disabled = false;
      btnAdd.textContent = 'Adicionar';
    }
  });

  // Botão fechar
  const acoesModal = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end;margin-top:14px' });
  const btnFechar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => { overlay.remove(); });
  acoesModal.append(btnFechar);
  box.append(acoesModal);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) { overlay.remove(); } });
  document.body.append(overlay);

  carregar();
}

// v0.12.0: refresh inteligente — atualiza UM card sem rerender tela inteira
async function refreshCardAgendamento(agId) {
  try {
    const resp = await agendamentoEdge('carregar', { id: agId });
    const novoAg = resp.agendamento;
    if (!novoAg) return;
    const cardAntigo = document.querySelector(`[data-ag-id="${agId}"]`);
    if (!cardAntigo) return;
    const cardNovo = renderCardAgendamento(novoAg);
    cardAntigo.replaceWith(cardNovo);
    // Atualiza tambem cards stats no topo se existirem
    atualizarCardsStats();
  } catch (_) {}
}

async function atualizarCardsStats() {
  try {
    const resp = await agendamentoEdge('listar');
    const lista = resp.agendamentos || [];
    const ativos = lista.filter(a => a.ativo).length;
    const pausados = lista.length - ativos;
    const elAtivos = document.getElementById('stat-ativos');
    const elPausados = document.getElementById('stat-pausados');
    const elTotal = document.getElementById('stat-total');
    if (elAtivos) elAtivos.textContent = String(ativos);
    if (elPausados) elPausados.textContent = String(pausados);
    if (elTotal) elTotal.textContent = String(lista.length);
  } catch (_) {}
}

function renderItemDestinatario(d, onMudou) {
  const card = el('div', {
    class: 'px-card px-card--sm',
    style: 'padding:10px 12px;display:flex;flex-direction:column;gap:6px' + (d.ativo ? '' : ';opacity:0.55'),
  });

  const linha = el('div', { class: 'px-row', style: 'justify-content:space-between;gap:8px' });

  const corpo = el('div', { style: 'flex:1;min-width:0' });
  const inputValor = el('input', {
    type: 'text', class: 'px-input', value: d.valor,
    style: 'padding:4px 8px;height:28px;font-size:12px;background:transparent;border-color:transparent',
  });
  const inputNomeD = el('input', {
    type: 'text', class: 'px-input', value: d.nome || '', placeholder: '(sem nome)',
    style: 'padding:4px 8px;height:28px;font-size:11px;background:transparent;border-color:transparent;color:var(--cor-texto-2);margin-top:2px',
  });
  corpo.append(
    el('div', { class: 'px-row', style: 'gap:4px' }, [
      el('span', { style: 'font-size:11px;color:var(--cor-texto-3)' }, '📱'),
      inputValor,
    ]),
    inputNomeD,
  );

  // Salvar edição quando perder foco (com debounce)
  let timer = null;
  const salvarEdicao = async () => {
    const novoValor = inputValor.value.replace(/\D/g, '');
    const novoNome = inputNomeD.value.trim() || null;
    if (!novoValor) return;
    if (novoValor === d.valor && novoNome === (d.nome || null)) return;
    try {
      await agendamentoEdge('destinatario_atualizar', {
        destinatario_id: d.id, valor: novoValor, nome: novoNome,
      });
      d.valor = novoValor;
      d.nome = novoNome;
    } catch (e) {
      mostrarAlerta({ titulo: 'Falha', mensagem: e.message, tipo: 'erro' });
    }
  };
  const agendarSalvar = () => { if (timer) clearTimeout(timer); timer = setTimeout(salvarEdicao, 600); };
  inputValor.addEventListener('input', agendarSalvar);
  inputNomeD.addEventListener('input', agendarSalvar);
  inputValor.addEventListener('blur', salvarEdicao);
  inputNomeD.addEventListener('blur', salvarEdicao);

  // Botões: toggle ativo/inativo + remover
  const botoes = el('div', { class: 'px-row', style: 'gap:4px;flex-shrink:0' });
  const btnToggle = el('button', {
    class: 'px-icon-btn px-icon-btn--sm',
    title: d.ativo ? 'Desativar (mantém cadastro)' : 'Ativar',
  }, [d.ativo ? '⏸' : '▶']);
  btnToggle.addEventListener('click', async () => {
    btnToggle.disabled = true;
    try {
      await agendamentoEdge('destinatario_toggle', { destinatario_id: d.id });
      onMudou();
    } catch (e) {
      mostrarAlerta({ titulo: 'Falha', mensagem: e.message, tipo: 'erro' });
      btnToggle.disabled = false;
    }
  });

  const btnRemover = el('button', {
    class: 'px-icon-btn px-icon-btn--sm',
    title: 'Remover destinatário',
  }, '🗑');
  btnRemover.addEventListener('click', async () => {
    const ok = await mostrarConfirmacao({
      titulo: 'Remover destinatário?',
      mensagem: `Remover ${d.valor} dos destinatários?`,
      textoConfirmar: 'Remover',
      destrutivo: true,
    });
    if (!ok) return;
    try {
      await agendamentoEdge('destinatario_remove', { destinatario_id: d.id });
      onMudou();
    } catch (e) {
      mostrarAlerta({ titulo: 'Falha', mensagem: e.message, tipo: 'erro' });
    }
  });

  botoes.append(btnToggle, btnRemover);

  linha.append(corpo, botoes);
  card.append(linha);
  return card;
}

function renderCerebros() {
  renderPlaceholderCategoria({
    titulo: 'Cérebros',
    iconeSvg: ICONES.cerebros,
    mensagem: 'Inventário de produtos da Pinguim com conhecimento curado: ProAlt, Elo, Sirius, Lyra, Mentoria Express, Lo-Fi, Desafio 7 Dias e mais.',
    dica: 'Em breve: buscar/explorar conteúdo dos Cérebros direto daqui.',
  });
}

function renderSkills() {
  renderPlaceholderCategoria({
    titulo: 'Skills',
    iconeSvg: ICONES.skills,
    mensagem: 'Habilidades reutilizáveis que os agentes invocam: consultar pessoa, verificar acesso, top engajados, etc.',
    dica: 'Em breve: catálogo navegável + métricas de uso por skill.',
  });
}

// =====================================================================
// v0.19.0 — ARSENAL (paginas clonadas, futuros transcripts, etc)
// =====================================================================
let _arsenalCache = []; // cache local pra busca rápida sem refetch
let _arsenalFiltroAtivo = 'todos';
let _arsenalBusca = '';

async function renderArsenal() {
  conteudo.innerHTML = '';
  setStatus('');
  const wrap = el('div', { class: 'px-home' });

  const cabecalho = el('div', { class: 'px-row', style: 'justify-content:space-between;margin-bottom:8px' }, [
    el('div', { class: 'px-rotulo' }, 'Arsenal'),
    el('button', {
      class: 'px-icon-btn px-icon-btn--sm',
      title: modoExpandido ? 'Recolher' : 'Expandir',
      'aria-label': modoExpandido ? 'Recolher' : 'Expandir',
    }, [modoExpandido ? '⊟' : '⊞']),
  ]);
  cabecalho.querySelector('button').addEventListener('click', toggleExpandir);
  wrap.append(cabecalho);

  wrap.append(el('div', { class: 'px-meta', style: 'margin-bottom:14px' },
    'Itens capturados pela extensão. Páginas clonadas viram template reutilizável. Outras categorias chegam em breve (transcripts, reels, docs).'));

  // v0.19.4: campo de busca
  const buscaWrap = el('div', { style: 'position:relative;margin-bottom:10px' });
  const inputBusca = el('input', {
    type: 'search',
    class: 'px-input',
    placeholder: '🔎 Buscar por título, domínio ou headline…',
    style: 'width:100%;padding:8px 12px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto-1);font-size:13px',
    value: _arsenalBusca,
  });
  buscaWrap.append(inputBusca);
  wrap.append(buscaWrap);

  const filtros = el('div', { class: 'px-row', style: 'gap:6px;margin-bottom:12px;flex-wrap:wrap' });
  const filtrosTabs = [
    { slug: 'todos', label: 'Todos' },
    { slug: 'pagina-venda', label: '📄 Páginas de venda' },
    { slug: 'reel-tiktok', label: '🎵 TikTok' },
    { slug: 'reel-instagram', label: '📸 Instagram' },
    { slug: 'transcript-youtube', label: '📺 YouTube' },
  ];
  const lista = el('div');
  function renderTabs() {
    filtros.innerHTML = '';
    for (const f of filtrosTabs) {
      const ativo = _arsenalFiltroAtivo === f.slug;
      const b = el('button', {
        style: [
          'cursor:pointer',
          'padding:6px 12px',
          'border-radius:var(--raio-2)',
          'font-size:12px',
          'font-weight:500',
          // Ativo: fundo branco com texto preto (--cor-acento é branco no DS X). Inativo: fundo escuro com borda forte
          ativo
            ? 'background:var(--cor-acento);color:var(--cor-acento-texto);border:1px solid var(--cor-acento)'
            : 'background:var(--cor-fundo-2);color:var(--cor-texto);border:1px solid var(--cor-borda-forte)',
        ].join(';'),
      }, f.label);
      b.addEventListener('click', () => { _arsenalFiltroAtivo = f.slug; renderTabs(); aplicarFiltrosERender(); });
      filtros.append(b);
    }
  }
  renderTabs();
  wrap.append(filtros, lista);
  conteudo.append(wrap);

  function aplicarFiltrosERender() {
    lista.innerHTML = '';
    let itens = _arsenalCache;
    if (_arsenalFiltroAtivo !== 'todos') itens = itens.filter(i => i.tipo === _arsenalFiltroAtivo);
    const q = _arsenalBusca.trim().toLowerCase();
    if (q) {
      itens = itens.filter(i =>
        (i.titulo || '').toLowerCase().includes(q) ||
        (i.dominio || '').toLowerCase().includes(q) ||
        (i.url_origem || '').toLowerCase().includes(q) ||
        (i.briefing?.headline || '').toLowerCase().includes(q) ||
        (i.briefing?.oferta?.promessa || '').toLowerCase().includes(q)
      );
    }
    if (itens.length === 0) {
      lista.append(el('div', { class: 'px-vazio', style: 'padding:32px 16px;text-align:center' }, [
        el('div', { style: 'font-size:32px;margin-bottom:8px' }, q ? '🔍' : '📦'),
        el('div', { style: 'font-weight:500;margin-bottom:4px' }, q ? 'Sem resultados' : 'Arsenal vazio'),
        el('div', { class: 'px-meta' }, q
          ? `Nenhum item bate com "${q}". Tenta outro termo.`
          : 'Abra uma página de venda em outra aba e clique 👁 Analisar tela. O Clonador captura tudo aqui.'),
      ]));
      return;
    }
    // Grade responsiva: 1 col modo recolhido, 2-3 cols modo expandido
    const grid = el('div', {
      style: modoExpandido
        ? 'display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px'
        : 'display:flex;flex-direction:column;gap:10px',
    });
    for (const it of itens) grid.append(renderItemArsenalCard(it, recarregarArsenal));
    lista.append(grid);
  }

  // Debounce na busca
  let tBusca;
  inputBusca.addEventListener('input', (e) => {
    clearTimeout(tBusca);
    tBusca = setTimeout(() => {
      _arsenalBusca = e.target.value;
      aplicarFiltrosERender();
    }, 150);
  });

  async function carregar() {
    lista.innerHTML = '';
    lista.append(el('div', { class: 'px-meta' }, 'Carregando…'));
    try {
      let url = `${SUPABASE_URL}/rest/v1/itens_arsenal?select=*&cliente_id=eq.${session.user.id}&order=criado_em.desc&limit=200`;
      const r = await fetchProxy(url, {
        method: 'GET',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Accept-Profile': 'pinguim',
        },
      });
      if (!r.ok) throw new Error(r.body?.message || `HTTP ${r.status}`);
      _arsenalCache = Array.isArray(r.body) ? r.body : [];
      aplicarFiltrosERender();
    } catch (e) {
      lista.innerHTML = '';
      lista.append(el('div', { class: 'alerta-erro' }, 'Erro: ' + e.message));
    }
  }
  async function recarregarArsenal() { await carregar(); }
  carregar();
}

function renderItemArsenalCard(item, onMudar) {
  const card = el('div', { class: 'px-card', style: 'cursor:pointer;display:flex;flex-direction:column;height:100%' });
  const linha = el('div', { class: 'px-row', style: 'gap:10px;align-items:flex-start;flex:1' });

  const iconePorTipo = { 'pagina-venda':'📄', 'reel-tiktok':'🎵', 'reel-instagram':'📸', 'transcript-youtube':'📺' };
  const icone = el('div', { style: 'font-size:22px;flex-shrink:0' }, iconePorTipo[item.tipo] || '📦');
  // v0.21+v0.22: highlight diferente por tipo
  const ehReel = item.tipo === 'reel-tiktok' || item.tipo === 'reel-instagram';
  const ehYt = item.tipo === 'transcript-youtube';
  const highlight = ehReel
    ? (item.briefing?.autor ? `@${item.briefing.autor}${item.briefing.plays ? ' · ▶ ' + formatarNumero(item.briefing.plays) : ''}${item.duracao_segundos ? ' · ⏱ ' + item.duracao_segundos + 's' : ''}` : null)
    : ehYt
      ? (item.briefing?.canal ? `📺 ${item.briefing.canal}${item.briefing.views ? ' · ▶ ' + formatarNumero(item.briefing.views) : ''}${item.duracao_segundos ? ' · ⏱ ' + formatarDuracao(item.duracao_segundos) : ''}` : null)
      : (item.briefing?.headline ? `🎯 ${item.briefing.headline}` : null);

  const corpo = el('div', { style: 'flex:1;min-width:0' }, [
    el('div', { style: 'font-weight:500;margin-bottom:4px;word-break:break-word;color:var(--cor-texto)' }, item.titulo || item.url_origem || 'Sem título'),
    el('div', { style: 'font-size:11px;color:var(--cor-texto-2)' }, `${item.dominio || '—'} · ${new Date(item.criado_em).toLocaleString('pt-BR')}`),
    highlight ? el('div', { style: 'margin-top:6px;font-size:12px;color:var(--cor-texto-2);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden' }, highlight) : null,
    item.status === 'erro' ? el('div', { style: 'color:var(--cor-erro);margin-top:4px;font-size:11px' }, '⚠ ' + (item.erro || 'falhou')) : null,
  ].filter(Boolean));

  linha.append(icone, corpo);
  card.append(linha);

  // Botão excluir (canto inferior direito do card) — v0.19.5: ícone SVG visível
  const rodape = el('div', { class: 'px-row', style: 'justify-content:flex-end;margin-top:10px;gap:4px' });
  const btnDel = el('button', {
    style: 'background:transparent;border:1px solid var(--cor-borda-forte);color:var(--cor-texto-2);cursor:pointer;font-size:12px;padding:4px 8px;border-radius:var(--raio-2);display:flex;align-items:center;gap:4px',
    title: 'Excluir do Arsenal',
    html: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg> Excluir',
  });
  btnDel.addEventListener('mouseenter', () => { btnDel.style.color = 'var(--cor-erro,#ef4444)'; btnDel.style.borderColor = 'var(--cor-erro,#ef4444)'; });
  btnDel.addEventListener('mouseleave', () => { btnDel.style.color = 'var(--cor-texto-2)'; btnDel.style.borderColor = 'var(--cor-borda-forte)'; });
  btnDel.addEventListener('click', async (ev) => {
    ev.stopPropagation();
    // v0.19.5: usa modal do Pinguim em vez de confirm() do browser
    const ok = await confirmar(`Excluir "${item.titulo || 'esse item'}" do Arsenal? Não dá pra desfazer.`);
    if (!ok) return;
    try {
      // Apaga arquivo no Storage (best-effort)
      if (item.html_storage_path) {
        await fetchProxy(`${SUPABASE_URL}/storage/v1/object/arsenal-pinguim/${item.html_storage_path}`, {
          method: 'DELETE',
          headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}` },
        });
      }
      if (item.screenshot_storage_path) {
        await fetchProxy(`${SUPABASE_URL}/storage/v1/object/arsenal-pinguim/${item.screenshot_storage_path}`, {
          method: 'DELETE',
          headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}` },
        });
      }
      // v0.21.1: reel está no Drive — apaga via Edge (que tem OAuth Google)
      if (item.drive_file_id) {
        await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-excluir-arsenal`, {
          method: 'POST',
          headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ item_id: item.id, drive_file_id: item.drive_file_id }),
        });
      }
      // Apaga registro
      await fetchProxy(`${SUPABASE_URL}/rest/v1/itens_arsenal?id=eq.${item.id}`, {
        method: 'DELETE',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Accept-Profile': 'pinguim',
          'Content-Profile': 'pinguim',
        },
      });
      if (typeof onMudar === 'function') onMudar();
    } catch (e) {
      mostrarAlerta({ titulo: 'Erro ao excluir', mensagem: e.message, tipo: 'erro' });
    }
  });
  rodape.append(btnDel);
  card.append(rodape);

  card.addEventListener('click', () => abrirItemArsenal(item));
  return card;
}

async function abrirItemArsenal(item) {
  // Re-busca pra ter dados frescos + signed URL do HTML
  let htmlUrl = null;
  if (item.html_storage_path) {
    try {
      const r = await fetchProxy(`${SUPABASE_URL}/storage/v1/object/sign/arsenal-pinguim/${item.html_storage_path}?expiresIn=3600`, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ expiresIn: 3600 }),
      });
      // v0.19.5: signedURL vem como /object/sign/... → precisa de prefixo /storage/v1
      if (r.ok && r.body?.signedURL) htmlUrl = SUPABASE_URL + '/storage/v1' + r.body.signedURL;
    } catch (_) {}
  }
  mostrarModalArsenalItem({ item, htmlUrl });
}

// Detector heurístico de página de venda — usado pelo porteiro Analisar Tela
function detectarPaginaVenda(dadosTela) {
  if (!dadosTela) return false;
  const url = String(dadosTela.url || '').toLowerCase();
  const host = String(dadosTela.dominio || '').toLowerCase();
  const titulo = String(dadosTela.titulo || '').toLowerCase();
  const texto = String(dadosTela.texto_visivel || '').toLowerCase();

  // Match forte por host
  const hostsVenda = ['hotmart.com', 'kiwify.com', 'eduzz.com', 'monetizze.com', 'pay.kiwify', 'pay.hotmart', 'sun.eduzz', 'go.hotmart'];
  if (hostsVenda.some(h => host.includes(h) || url.includes(h))) return true;
  // Path checkout
  if (url.includes('/checkout') || url.includes('/oferta') || url.includes('/venda')) return true;

  // Heurística textual — precisa de pelo menos 2 sinais (afrouxada v0.19.1)
  const sinais = [
    /garantia\s+(de\s+)?\d+\s+dias?/i.test(texto),
    /\b\d+x\s+(de\s+)?r\$/i.test(texto) || /\bà\s+vista\b/i.test(texto) || /\br\$\s*\d/i.test(texto),
    /(quero\s+(entrar|comprar|garantir|participar)|sim,?\s+quero|garantir\s+(minha\s+)?vaga|fazer\s+(minha\s+)?inscri[çc][aã]o|clique\s+aqui\s+para)/i.test(texto),
    /(depoimentos?|veja\s+o\s+que|alunos?\s+(que|dizem)|resultados?\s+(dos|de)\s+alunos)/i.test(texto),
    /(oferta\s+(especial|limitada)|vagas?\s+limitadas?|últim[ao]s?\s+vagas?|inscri[çc][õo]es\s+(abertas|encerram))/i.test(texto),
    /(headline|sub-?headline|hero)/i.test(texto),
    /b[ôo]nus\s+(exclusivo|especial|\d)/i.test(texto),
    // Sinais adicionais comuns em paginas de venda BR
    /(transforme|destrave|domine|aprenda)\b.{0,80}(em\s+\d+\s+(dias|semanas)|do\s+zero)/i.test(texto),
    /(módulos?|aulas?|videos?)\s+(práticos|exclusivos|gravados)/i.test(texto),
    /(clique\s+aqui|inscreva-se|quero\s+me\s+inscrever|quero\s+(entrar|garantir))/i.test(texto),
  ];
  const score = sinais.filter(Boolean).length;
  return score >= 2;
}

function mostrarResultadoClonarPagina({ resultado, dadosPaginaVenda }) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:880px;max-height:92vh;overflow-y:auto' });

  box.append(el('h3', { class: 'modal-pinguim-titulo' }, '📄 Página clonada'));

  const cabecalho = el('div', { class: 'px-meta', style: 'margin-bottom:12px' });
  cabecalho.append(el('span', {}, `📍 ${resultado.dominio || dadosPaginaVenda.dominio} · ${(resultado.titulo || '').slice(0, 80)}`));
  cabecalho.append(el('span', { class: 'px-badge', style: 'margin-left:8px' }, 'Clonador'));
  box.append(cabecalho);

  const briefing = resultado.briefing || {};
  const grid = el('div', { style: 'display:grid;grid-template-columns:1fr;gap:12px' });

  // Bloco 1: HERO
  if (briefing.headline || briefing.sub_headline) {
    const cardHero = el('div', { class: 'px-card' });
    cardHero.append(el('div', { class: 'px-rotulo' }, '🎯 Hero'));
    if (briefing.headline) cardHero.append(el('div', { style: 'font-size:16px;font-weight:600;margin-top:4px' }, briefing.headline));
    if (briefing.sub_headline) cardHero.append(el('div', { class: 'px-meta', style: 'margin-top:4px' }, briefing.sub_headline));
    grid.append(cardHero);
  }

  // Bloco 2: OFERTA + CTA + PREÇO + URGÊNCIA
  if (briefing.oferta || briefing.cta_principal || briefing.urgencia_scarcity) {
    const cardOferta = el('div', { class: 'px-card' });
    cardOferta.append(el('div', { class: 'px-rotulo' }, '💰 Oferta + CTA'));
    if (briefing.oferta?.promessa) cardOferta.append(el('div', { style: 'margin-top:4px' }, briefing.oferta.promessa));
    if (briefing.oferta?.publico) cardOferta.append(el('div', { class: 'px-meta', style: 'margin-top:4px' }, '👥 ' + briefing.oferta.publico));
    if (briefing.oferta?.data_evento) cardOferta.append(el('div', { class: 'px-meta', style: 'margin-top:4px' }, '📅 ' + briefing.oferta.data_evento));
    if (briefing.cta_principal?.texto_botao) {
      const ctaLinha = el('div', { class: 'px-row', style: 'gap:8px;margin-top:8px;flex-wrap:wrap' });
      ctaLinha.append(el('span', { class: 'px-badge', style: 'background:var(--cor-acento);color:white' }, briefing.cta_principal.texto_botao));
      if (briefing.cta_principal.preco) ctaLinha.append(el('span', { class: 'px-badge' }, '💵 ' + briefing.cta_principal.preco));
      cardOferta.append(ctaLinha);
    }
    if (briefing.urgencia_scarcity) cardOferta.append(el('div', { class: 'px-meta', style: 'margin-top:6px;color:var(--cor-aviso)' }, '⏰ ' + briefing.urgencia_scarcity));
    if (briefing.garantia) cardOferta.append(el('div', { class: 'px-meta', style: 'margin-top:6px' }, '🛡 ' + briefing.garantia));
    grid.append(cardOferta);
  }

  // Bloco 2.5: DORES / OBJEÇÕES (v0.20.0)
  if (Array.isArray(briefing.dores_objecoes) && briefing.dores_objecoes.length) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '😩 Dores / objeções do público'));
    const ul = el('ul', { style: 'margin:6px 0 0 18px;padding:0' });
    briefing.dores_objecoes.forEach(d => ul.append(el('li', { style: 'margin-bottom:3px;color:var(--cor-texto-2)' }, d)));
    card.append(ul);
    grid.append(card);
  }

  // Bloco 3: BENEFÍCIOS
  if (Array.isArray(briefing.beneficios) && briefing.beneficios.length) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '✓ Benefícios'));
    const ul = el('ul', { style: 'margin:6px 0 0 18px;padding:0' });
    briefing.beneficios.forEach(b => ul.append(el('li', { style: 'margin-bottom:3px' }, b)));
    card.append(ul);
    grid.append(card);
  }

  // Bloco 3.5: COMO FUNCIONA (v0.20.0)
  if (Array.isArray(briefing.como_funciona) && briefing.como_funciona.length) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '⚙ Como funciona / Método'));
    const ol = el('ol', { style: 'margin:6px 0 0 22px;padding:0' });
    briefing.como_funciona.forEach(p => ol.append(el('li', { style: 'margin-bottom:3px' }, p)));
    card.append(ol);
    grid.append(card);
  }

  // Bloco 4: PROVA SOCIAL
  const ps = briefing.prova_social;
  if (ps && (ps.depoimentos?.length || ps.numeros?.length || ps.midia?.length || ps.perfis_atendidos?.length)) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '⭐ Prova social'));
    if (ps.numeros?.length) {
      const linha = el('div', { class: 'px-row', style: 'gap:6px;margin-top:6px;flex-wrap:wrap' });
      ps.numeros.forEach(n => linha.append(el('span', { class: 'px-badge' }, n)));
      card.append(linha);
    }
    if (ps.perfis_atendidos?.length) {
      card.append(el('div', { style: 'margin-top:6px;font-size:12px;color:var(--cor-texto-2)' }, '👥 Perfis atendidos: ' + ps.perfis_atendidos.join(' · ')));
    }
    if (ps.depoimentos?.length) {
      const ul = el('ul', { style: 'margin:6px 0 0 18px;padding:0' });
      ps.depoimentos.slice(0, 8).forEach(d => ul.append(el('li', { style: 'margin-bottom:3px;color:var(--cor-texto-2);font-size:12px' }, '"' + d + '"')));
      card.append(ul);
    }
    if (ps.midia?.length) {
      card.append(el('div', { style: 'margin-top:6px;font-size:12px;color:var(--cor-texto-2)' }, '📰 Mídia: ' + ps.midia.join(' · ')));
    }
    grid.append(card);
  }

  // Bloco 5: ESPECIFICAÇÕES + BÔNUS
  if (briefing.especificacoes || (Array.isArray(briefing.bonus_ofertas) && briefing.bonus_ofertas.length)) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '📋 Especificações + bônus'));
    if (briefing.especificacoes?.formato) card.append(el('div', { class: 'px-meta', style: 'margin-top:4px' }, 'Formato: ' + briefing.especificacoes.formato));
    if (briefing.especificacoes?.duracao) card.append(el('div', { class: 'px-meta' }, 'Duração: ' + briefing.especificacoes.duracao));
    if (Array.isArray(briefing.bonus_ofertas) && briefing.bonus_ofertas.length) {
      const ul = el('ul', { style: 'margin:6px 0 0 18px;padding:0' });
      briefing.bonus_ofertas.forEach(b => ul.append(el('li', { class: 'px-meta', style: 'margin-bottom:2px' }, '🎁 ' + b)));
      card.append(ul);
    }
    grid.append(card);
  }

  // Bloco 6: FAQ
  if (Array.isArray(briefing.faqs) && briefing.faqs.length) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '❓ FAQ'));
    briefing.faqs.slice(0, 6).forEach(f => {
      card.append(el('div', { style: 'margin-top:6px' }, [
        el('div', { style: 'font-weight:500;font-size:13px' }, f.pergunta),
        el('div', { class: 'px-meta', style: 'margin-top:2px' }, f.resposta),
      ]));
    });
    grid.append(card);
  }

  // Bloco 6.5: FRASES DE DESTAQUE (v0.20.0)
  if (Array.isArray(briefing.frases_destaque) && briefing.frases_destaque.length) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '✨ Frases de destaque'));
    const ul = el('ul', { style: 'margin:6px 0 0 18px;padding:0' });
    briefing.frases_destaque.forEach(f => ul.append(el('li', { style: 'margin-bottom:3px;font-style:italic;color:var(--cor-texto-2);font-size:12px' }, '"' + f + '"')));
    card.append(ul);
    grid.append(card);
  }

  // Bloco 7: SOBRE O AUTOR
  if (briefing.sobre_autor) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '👤 Sobre o autor'));
    card.append(el('div', { class: 'px-meta', style: 'margin-top:4px' }, briefing.sobre_autor));
    grid.append(card);
  }

  // Bloco 8: SUGESTÕES DE OTIMIZAÇÃO
  if (Array.isArray(briefing.sugestoes_otimizacao) && briefing.sugestoes_otimizacao.length) {
    const card = el('div', { class: 'px-card', style: 'background:rgba(64,134,237,0.08);border-color:var(--cor-acento)' });
    card.append(el('div', { class: 'px-rotulo' }, '💡 Sugestões pra subir conversão'));
    const ul = el('ul', { style: 'margin:6px 0 0 18px;padding:0' });
    briefing.sugestoes_otimizacao.forEach(s => ul.append(el('li', { style: 'margin-bottom:4px' }, s)));
    card.append(ul);
    grid.append(card);
  }

  box.append(grid);

  // Botoes finais
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end;gap:8px;margin-top:14px;flex-wrap:wrap' });

  // v0.19.4: Copiar briefing como markdown
  const metaParaMd = {
    titulo: resultado.titulo,
    dominio: resultado.dominio || dadosPaginaVenda?.dominio,
    url_origem: resultado.url_origem || dadosPaginaVenda?.url,
  };
  const btnCopiar = el('button', { class: 'modal-pinguim-btn' }, '📋 Copiar briefing');
  btnCopiar.addEventListener('click', async () => {
    const md = briefingParaMarkdown(briefing, metaParaMd);
    try {
      await navigator.clipboard.writeText(md);
      btnCopiar.textContent = '✓ Copiado';
      setTimeout(() => btnCopiar.textContent = '📋 Copiar briefing', 2000);
    } catch (e) {
      mostrarAlerta({ titulo: 'Copiar falhou', mensagem: 'Não consegui acessar a área de transferência. Use o botão "📄 Baixar .md" como alternativa.', tipo: 'aviso' });
    }
  });
  acoes.append(btnCopiar);

  // v0.19.4: Baixar como .md
  const btnMd = el('button', { class: 'modal-pinguim-btn' }, '📄 Baixar .md');
  btnMd.addEventListener('click', () => {
    const md = briefingParaMarkdown(briefing, metaParaMd);
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const safeName = (resultado.titulo || 'briefing').replace(/[^a-zA-Z0-9-_À-ſ]+/g, '-').slice(0, 60);
    a.download = `briefing-${safeName}.md`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  acoes.append(btnMd);

  if (resultado.html_storage_path) {
    const btnHtml = el('button', { class: 'modal-pinguim-btn' }, '📥 Baixar HTML');
    btnHtml.addEventListener('click', async () => {
      btnHtml.disabled = true; btnHtml.textContent = 'Gerando link…';
      try {
        const r = await fetchProxy(`${SUPABASE_URL}/storage/v1/object/sign/arsenal-pinguim/${resultado.html_storage_path}?expiresIn=600`, {
          method: 'POST',
          headers: {
            apikey: SUPABASE_ANON_KEY,
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ expiresIn: 600 }),
        });
        if (r.ok && r.body?.signedURL) {
          // v0.19.5: signedURL precisa de prefixo /storage/v1
          window.open(SUPABASE_URL + '/storage/v1' + r.body.signedURL, '_blank');
        } else {
          mostrarAlerta({ titulo: 'Erro ao gerar link', mensagem: (r.body?.message || `HTTP ${r.status}`), tipo: 'erro' });
        }
      } finally {
        btnHtml.disabled = false; btnHtml.textContent = '📥 Baixar HTML';
      }
    });
    acoes.append(btnHtml);
  }
  const btnArsenal = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary' }, '📦 Ver no Arsenal');
  btnArsenal.addEventListener('click', () => { overlay.remove(); irPara('arsenal'); });
  acoes.append(btnArsenal);
  const btnFechar = el('button', { class: 'modal-pinguim-btn' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  acoes.append(btnFechar);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);
}

async function mostrarModalArsenalItem({ item, htmlUrl }) {
  // v0.22.0: roteia por tipo
  if (item.tipo === 'transcript-youtube') {
    const b = item.briefing || {};
    mostrarResultadoTranscreverYoutube({
      resultado: {
        item_id: item.id,
        video_id: item.metadados?.video_id || '',
        titulo: item.titulo,
        canal: b.canal,
        views: b.views,
        likes: b.likes,
        duracao_segundos: item.duracao_segundos || b.duracao_segundos,
        publicado_em: b.publicado_em,
        thumbnail: b.thumbnail,
        tags: b.tags,
        transcript: item.transcript_completo || '',
        transcript_segmentos: b.transcript_segmentos_total || 0,
        comentarios: b.comentarios || [],
        comentarios_total_brutos: b.comentarios_total_brutos || 0,
        comentarios_filtrados: (b.comentarios || []).length,
      },
    });
    return;
  }
  // v0.21.0: roteia por tipo
  if (item.tipo === 'reel-tiktok' || item.tipo === 'reel-instagram') {
    mostrarResultadoBaixarReel({
      resultado: {
        item_id: item.id,
        tipo: item.tipo,
        titulo: item.titulo,
        autor: item.briefing?.autor,
        autor_nome: item.briefing?.autor_nome,
        plays: item.briefing?.plays,
        likes: item.briefing?.likes,
        duracao: item.duracao_segundos || item.briefing?.duracao_segundos,
        caption: item.briefing?.caption,
        transcript: item.transcript_completo || item.briefing?.transcript,
        drive_file_id: item.drive_file_id,
        drive_url: item.drive_url,
        drive_folder_path: item.drive_folder_path,
        cover_url: item.briefing?.cover_url,
        hashtags: item.briefing?.hashtags,
        musica: item.briefing?.musica,
        url_origem: item.url_origem,
      },
    });
    return;
  }
  // Pagina de venda (default)
  mostrarResultadoClonarPagina({
    resultado: {
      titulo: item.titulo,
      dominio: item.dominio,
      briefing: item.briefing,
      html_storage_path: item.html_storage_path,
      url_origem: item.url_origem,
    },
    dadosPaginaVenda: { dominio: item.dominio, url: item.url_origem },
  });
}

// =====================================================================
// v0.21.0 — Modal de resultado do reel (TikTok / Instagram)
// =====================================================================
function mostrarResultadoBaixarReel({ resultado }) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:760px;max-height:92vh;overflow-y:auto' });

  const plataforma = resultado.tipo === 'reel-tiktok' ? 'TikTok' : 'Instagram';
  const icone = resultado.tipo === 'reel-tiktok' ? '🎵' : '📸';
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, `${icone} Reel ${plataforma} salvo`));

  // Cabeçalho
  const cab = el('div', { class: 'px-meta', style: 'margin-bottom:12px' });
  cab.append(el('span', {}, `@${resultado.autor || '?'} · ${resultado.autor_nome || ''}`));
  if (resultado.duracao) cab.append(el('span', { class: 'px-badge', style: 'margin-left:8px' }, `⏱ ${resultado.duracao}s`));
  box.append(cab);

  const grid = el('div', { style: 'display:grid;grid-template-columns:1fr;gap:12px' });

  // v0.21.1: Player de vídeo via Google Drive embed
  if (resultado.drive_file_id) {
    const cardVideo = el('div', { class: 'px-card' });
    cardVideo.append(el('div', { class: 'px-rotulo' }, '🎬 Vídeo (Google Drive)'));
    const iframe = el('iframe', {
      src: `https://drive.google.com/file/d/${resultado.drive_file_id}/preview`,
      allow: 'autoplay',
      style: 'width:100%;height:480px;border:none;margin-top:6px;border-radius:var(--raio-2);background:#000',
    });
    cardVideo.append(iframe);
    if (resultado.drive_folder_path) {
      cardVideo.append(el('div', { class: 'px-meta', style: 'margin-top:6px;font-size:11px' }, '📁 ' + resultado.drive_folder_path));
    }
    grid.append(cardVideo);
  }

  // Métricas
  if (resultado.plays || resultado.likes) {
    const cardMetricas = el('div', { class: 'px-card' });
    cardMetricas.append(el('div', { class: 'px-rotulo' }, '📊 Métricas'));
    const linha = el('div', { class: 'px-row', style: 'gap:8px;margin-top:6px;flex-wrap:wrap' });
    if (resultado.plays) linha.append(el('span', { class: 'px-badge' }, `▶ ${formatarNumero(resultado.plays)} plays`));
    if (resultado.likes) linha.append(el('span', { class: 'px-badge' }, `❤ ${formatarNumero(resultado.likes)} likes`));
    if (resultado.musica) linha.append(el('span', { class: 'px-badge' }, `🎵 ${resultado.musica.slice(0, 40)}`));
    cardMetricas.append(linha);
    grid.append(cardMetricas);
  }

  // Caption
  if (resultado.caption) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '💬 Caption'));
    card.append(el('div', { style: 'margin-top:6px;white-space:pre-wrap;font-size:13px;color:var(--cor-texto-2)' }, resultado.caption));
    grid.append(card);
  }

  // Hashtags
  if (Array.isArray(resultado.hashtags) && resultado.hashtags.length) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '#️⃣ Hashtags'));
    const linha = el('div', { class: 'px-row', style: 'gap:6px;margin-top:6px;flex-wrap:wrap' });
    resultado.hashtags.slice(0, 30).forEach(h => linha.append(el('span', { class: 'px-badge' }, '#' + h)));
    card.append(linha);
    grid.append(card);
  }

  // Transcript
  if (resultado.transcript) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '📝 Transcript (Whisper)'));
    card.append(el('div', { style: 'margin-top:6px;white-space:pre-wrap;font-size:13px;color:var(--cor-texto-2);max-height:240px;overflow-y:auto' }, resultado.transcript));
    grid.append(card);
  }

  box.append(grid);

  // Botões
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end;gap:8px;margin-top:14px;flex-wrap:wrap' });

  const btnCopiarTr = el('button', { class: 'modal-pinguim-btn' }, '📋 Copiar transcript');
  btnCopiarTr.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(resultado.transcript || resultado.caption || '');
      btnCopiarTr.textContent = '✓ Copiado';
      setTimeout(() => btnCopiarTr.textContent = '📋 Copiar transcript', 2000);
    } catch (_) {}
  });
  if (resultado.transcript || resultado.caption) acoes.append(btnCopiarTr);

  // v0.21.1: link Drive — abre player/download nativo do Google
  if (resultado.drive_url) {
    const btnDrive = el('button', { class: 'modal-pinguim-btn' }, '🔗 Abrir no Drive');
    btnDrive.addEventListener('click', () => window.open(resultado.drive_url, '_blank'));
    acoes.append(btnDrive);
  }
  if (resultado.drive_file_id) {
    const btnDl = el('button', { class: 'modal-pinguim-btn' }, '📥 Baixar MP4');
    btnDl.addEventListener('click', () => {
      window.open(`https://drive.google.com/uc?export=download&id=${resultado.drive_file_id}`, '_blank');
    });
    acoes.append(btnDl);
  }

  const btnArsenal = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary' }, '📦 Ver no Arsenal');
  btnArsenal.addEventListener('click', () => { overlay.remove(); irPara('arsenal'); });
  acoes.append(btnArsenal);

  const btnFechar = el('button', { class: 'modal-pinguim-btn' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  acoes.append(btnFechar);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);
}

function formatarNumero(n) {
  if (n >= 1e9) return (n/1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n/1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n/1e3).toFixed(1) + 'k';
  return String(n);
}

function formatarDuracao(s) {
  if (!s) return '';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h) return `${h}h${String(m).padStart(2,'0')}min`;
  if (m) return `${m}min${sec ? ' ' + sec + 's' : ''}`;
  return `${sec}s`;
}

// =====================================================================
// v0.22.0 — Modal de resultado da transcrição YouTube
// =====================================================================
// v0.23 — Modal de resultado da triagem WhatsApp
// v0.24.0 — Perfis prontos de palavras-chave por intenção/sentimento
const PERFIS_BUSCA_WHATSAPP = [
  {
    slug: 'reclamacao',
    nome: 'Reclamação / insatisfação',
    icone: '😡',
    palavras: ['não tô conseguindo', 'nao to conseguindo', 'não consigo', 'nao consigo', 'que merda', 'péssimo', 'pessimo', 'horrível', 'horrivel', 'decepcionad', 'absurdo', 'não funciona', 'nao funciona', 'tá ruim', 'ta ruim', 'vergonha', 'lixo', 'cancelar', 'quero meu dinheiro', 'enganaram', 'fraude', 'reclamação', 'reclamacao', 'insatisfeito', 'revoltado'],
  },
  {
    slug: 'urgencia',
    nome: 'Urgência / pedido de ajuda',
    icone: '🚨',
    palavras: ['urgente', 'agora', 'preciso', 'socorro', 'ajuda', 'por favor', 'tô desesperad', 'to desesperad', 'estou desesperad', 'não consigo', 'nao consigo', 'parou', 'quebrou', 'sumiu', 'travou', 'caiu', 'emergência', 'emergencia'],
  },
  {
    slug: 'dinheiro',
    nome: 'Dinheiro / pagamento',
    icone: '💰',
    palavras: ['pix', 'boleto', 'pagamento', 'pagar', 'paguei', 'reembolso', 'estorno', 'fatura', 'valor', 'preço', 'preco', 'cobrança', 'cobranca', 'cobrar', 'nf', 'nota fiscal', 'cartão', 'cartao', 'parcelad', 'desconto', 'comprar', 'comprei'],
  },
  {
    slug: 'cancelamento',
    nome: 'Cancelamento / churn',
    icone: '❌',
    palavras: ['cancelar', 'cancelamento', 'sair', 'desistir', 'devolver', 'trancar', 'pausar', 'descadastrar', 'remover minha', 'não quero mais', 'nao quero mais', 'me tira'],
  },
  {
    slug: 'elogio',
    nome: 'Elogio / satisfação',
    icone: '🎉',
    palavras: ['obrigad', 'incrível', 'incrivel', 'ajudou muito', 'valeu', 'show', 'top', 'muito bom', 'amei', 'mudou minha vida', 'gratidão', 'gratidao', 'grato', 'parabéns', 'parabens', 'sensacional', 'maravilhos', 'demais'],
  },
];

// Abre painel de busca WhatsApp: input livre + checkboxes de perfil + filtro de tempo
async function abrirBuscaWhatsApp() {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:520px;max-height:92vh;overflow-y:auto' });
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, '🔍 Buscar conversas no WhatsApp'));
  box.append(el('div', { class: 'px-meta', style: 'margin-bottom:12px;font-size:11px' },
    'Pinguim rola o painel inteiro do WhatsApp Web e devolve só as conversas que batem com sua busca. Sem IA, sem custo, determinístico.'));

  // Input livre
  box.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:4px' }, 'Palavra livre (opcional)'));
  const inputLivre = el('input', {
    type: 'text', class: 'px-input',
    placeholder: 'ex: elo, renovação, módulo 4, link do checkout',
    style: 'width:100%;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;margin-bottom:12px',
  });
  box.append(inputLivre);

  // Checkboxes de perfil
  box.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:6px' }, 'Ou marque perfis prontos (pode combinar)'));
  const perfisBox = el('div', { style: 'display:flex;flex-direction:column;gap:6px;margin-bottom:14px' });
  const checkboxesPerfil = [];
  for (const perfil of PERFIS_BUSCA_WHATSAPP) {
    const lab = el('label', {
      class: 'px-row',
      style: 'gap:8px;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer;align-items:flex-start',
    });
    const cb = el('input', { type: 'checkbox', style: 'margin:2px 0 0' });
    cb._perfil = perfil;
    lab.append(cb);
    lab.append(el('div', { style: 'flex:1' }, [
      el('div', { style: 'font-size:13px;font-weight:500' }, `${perfil.icone} ${perfil.nome}`),
      el('div', { class: 'px-meta', style: 'font-size:10px;color:var(--cor-texto-3);line-height:1.4' },
        perfil.palavras.slice(0, 6).join(' · ') + (perfil.palavras.length > 6 ? ' · …' : '')),
    ]));
    cb.addEventListener('change', () => {
      lab.style.borderColor = cb.checked ? 'var(--cor-acento)' : 'var(--cor-borda)';
    });
    perfisBox.append(lab);
    checkboxesPerfil.push(cb);
  }
  box.append(perfisBox);

  // Filtro de tempo
  box.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:4px' }, 'Período'));
  const selectPeriodo = el('select', {
    style: 'width:100%;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;margin-bottom:14px',
  });
  for (const opt of [
    { v: '6h', t: 'Últimas 6 horas' },
    { v: '24h', t: 'Últimas 24 horas (padrão)' },
    { v: '3d', t: 'Últimos 3 dias' },
    { v: '7d', t: 'Últimos 7 dias' },
    { v: 'tudo', t: 'Tudo visível' },
  ]) {
    const o = el('option', { value: opt.v }, opt.t);
    if (opt.v === '24h') o.selected = true;
    selectPeriodo.append(o);
  }
  box.append(selectPeriodo);

  const erroBox = el('div', { class: 'alerta-erro', style: 'display:none;margin-top:8px' });
  box.append(erroBox);

  // Botões
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end;gap:8px;margin-top:6px' });
  const btnCancelar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Cancelar');
  btnCancelar.addEventListener('click', () => overlay.remove());
  const btnVarrer = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, '🔍 Varrer agora');
  btnVarrer.addEventListener('click', async () => {
    const palavraLivre = inputLivre.value.trim().toLowerCase();
    const perfisAtivos = checkboxesPerfil.filter(c => c.checked).map(c => c._perfil);
    if (!palavraLivre && perfisAtivos.length === 0) {
      erroBox.textContent = 'Digite uma palavra livre OU marque pelo menos 1 perfil.';
      erroBox.style.display = 'block';
      return;
    }
    erroBox.style.display = 'none';
    overlay.remove();
    await executarBuscaWhatsApp({ palavraLivre, perfisAtivos, periodo: selectPeriodo.value });
  });
  acoes.append(btnCancelar, btnVarrer);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);
  setTimeout(() => inputLivre.focus(), 50);
}

// Dispara a varredura via service worker, filtra resultados localmente, mostra modal
async function executarBuscaWhatsApp({ palavraLivre, perfisAtivos, periodo }) {
  const progressoCtx = mostrarProgressoAnalise({ modo: 'whatsapp-busca', agente_slug: 'busca-whatsapp' });
  progressoCtx.setEstado('Rolando o painel do WhatsApp pra coletar conversas…');
  const tLento = setTimeout(() => progressoCtx.setEstado('Painel grande — pode levar até 30s, aguenta…'), 12000);

  let resp;
  try {
    resp = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ tipo: 'VARRER_WHATSAPP' }, resolve);
    });
  } catch (e) {
    clearTimeout(tLento);
    progressoCtx.erro('Falha de comunicação: ' + e.message, () => progressoCtx.fechar());
    return;
  }
  clearTimeout(tLento);

  if (!resp?.ok) {
    progressoCtx.erro('Falha na varredura: ' + (resp?.erro || 'sem detalhes'), () => progressoCtx.fechar());
    return;
  }

  const todas = resp.conversas || [];

  // Filtro de tempo
  const limiteMs = (() => {
    if (periodo === '6h') return 6 * 3600 * 1000;
    if (periodo === '24h') return 24 * 3600 * 1000;
    if (periodo === '3d') return 3 * 86400 * 1000;
    if (periodo === '7d') return 7 * 86400 * 1000;
    return Infinity;
  })();
  const agora = Date.now();
  const dentroDoTempo = todas.filter(c => {
    if (limiteMs === Infinity) return true;
    if (!c.timestamp_iso) return false; // sem hora parseada → fora
    const d = new Date(c.timestamp_iso).getTime();
    return (agora - d) <= limiteMs;
  });

  // Filtro por palavra/perfil
  function normalizar(s) {
    return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  }
  function bateAlguma(haystack, palavras) {
    const h = normalizar(haystack);
    for (const p of palavras) {
      if (h.includes(normalizar(p))) return true;
    }
    return false;
  }

  const matches = [];
  for (const c of dentroDoTempo) {
    const haystack = `${c.nome} ${c.ultima_msg || ''}`;
    const perfisQueBateram = [];
    let bateuLivre = false;
    if (palavraLivre) {
      if (bateAlguma(haystack, [palavraLivre])) bateuLivre = true;
    }
    for (const perfil of perfisAtivos) {
      if (bateAlguma(haystack, perfil.palavras)) perfisQueBateram.push(perfil);
    }
    if (bateuLivre || perfisQueBateram.length > 0) {
      matches.push({ ...c, _perfis: perfisQueBateram, _bateu_livre: bateuLivre });
    }
  }

  progressoCtx.fechar();
  mostrarResultadoBuscaWhatsApp({
    matches,
    total_varrido: todas.length,
    total_no_periodo: dentroDoTempo.length,
    palavraLivre,
    perfisAtivos,
    periodo,
    duracao_ms: resp.duracao_ms,
  });
}

// Modal de resultados — itens clicáveis com badge de perfis que bateram
function mostrarResultadoBuscaWhatsApp({ matches, total_varrido, total_no_periodo, palavraLivre, perfisAtivos, periodo, duracao_ms }) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:760px;max-height:92vh;overflow-y:auto' });
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, '🔍 Resultados da busca'));

  // Toast inline pra feedback de clique
  function toastNoModal(msg) {
    let tEl = box.querySelector('.wa-toast-inline');
    if (!tEl) {
      tEl = el('div', {
        class: 'wa-toast-inline',
        style: 'position:sticky;bottom:0;margin-top:12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4;background:rgba(231,76,60,0.12);border:1px solid rgba(231,76,60,0.4);color:#ffb4ab',
      });
      box.append(tEl);
    }
    tEl.textContent = msg;
    tEl.style.display = 'block';
    clearTimeout(tEl._hideTimer);
    tEl._hideTimer = setTimeout(() => { tEl.style.display = 'none'; }, 4500);
  }

  function abrirConversa(nome) {
    const respId = 'wa-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
    let timeoutId = null;
    function cleanup() {
      window.removeEventListener('message', onResp);
      if (timeoutId) clearTimeout(timeoutId);
    }
    function onResp(ev) {
      if (ev?.data?.pinguimTipo !== 'ABRIR_CONVERSA_WHATSAPP_RESP') return;
      if (ev.data.respId !== respId) return;
      cleanup();
      if (ev.data.ok) overlay.remove();
      else toastNoModal('⚠ ' + (ev.data.motivo || 'não consegui abrir'));
    }
    window.addEventListener('message', onResp);
    timeoutId = setTimeout(() => {
      cleanup();
      toastNoModal('⚠ Sem resposta da página — confirme que a aba ativa é o WhatsApp Web.');
    }, 3000);
    try {
      window.parent.postMessage({ pinguimTipo: 'ABRIR_CONVERSA_WHATSAPP', nome, respId }, '*');
    } catch (_) { cleanup(); toastNoModal('⚠ Erro de comunicação.'); }
  }

  // Resumo
  const labelPeriodo = { '6h': 'últimas 6h', '24h': 'últimas 24h', '3d': 'últimos 3 dias', '7d': 'últimos 7 dias', 'tudo': 'tudo visível' }[periodo] || periodo;
  const filtroTxt = [
    palavraLivre ? `"${palavraLivre}"` : null,
    ...perfisAtivos.map(p => `${p.icone} ${p.nome}`),
  ].filter(Boolean).join(' + ');

  const resumo = el('div', { class: 'px-meta', style: 'margin-bottom:8px;font-size:12px;line-height:1.5' });
  resumo.append(el('div', {}, `Filtro: ${filtroTxt}`));
  resumo.append(el('div', {}, `Período: ${labelPeriodo}`));
  resumo.append(el('div', {}, `Varri ${total_varrido} conversas em ${(duracao_ms / 1000).toFixed(1)}s · ${total_no_periodo} dentro do período · ${matches.length} bateram`));
  box.append(resumo);

  if (matches.length === 0) {
    box.append(el('div', { style: 'padding:14px;text-align:center;color:var(--cor-texto-2);font-size:13px;margin:14px 0' },
      '😶 Nenhuma conversa bateu com esse filtro no período escolhido.'));
    box.append(el('div', { class: 'px-meta', style: 'font-size:11px;text-align:center;margin-bottom:14px' },
      'Tente período maior, palavra menos específica ou marque outro perfil.'));
  } else {
    box.append(el('div', { class: 'px-meta', style: 'margin-bottom:10px;font-size:11px;color:var(--cor-acento)' },
      '👆 Clique em qualquer linha pra abrir a conversa direto no WhatsApp.'));

    const lista = el('div', { style: 'display:flex;flex-direction:column;gap:6px' });
    // Ordena: mais recente primeiro (timestamp_iso desc), nulls no fim
    const ordenadas = matches.slice().sort((a, b) => {
      if (!a.timestamp_iso) return 1;
      if (!b.timestamp_iso) return -1;
      return new Date(b.timestamp_iso) - new Date(a.timestamp_iso);
    });
    for (const m of ordenadas) {
      const item = el('div', {
        style: 'padding:10px 12px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer;transition:border-color 0.15s',
        title: 'Clique pra abrir essa conversa no WhatsApp',
      });
      item.addEventListener('mouseenter', () => item.style.borderColor = 'var(--cor-acento)');
      item.addEventListener('mouseleave', () => item.style.borderColor = 'var(--cor-borda)');
      item.addEventListener('click', () => abrirConversa(m.nome));

      const linha1 = el('div', { style: 'display:flex;justify-content:space-between;gap:6px;align-items:center' });
      linha1.append(el('div', { style: 'font-weight:600;font-size:13px;flex:1;word-break:break-word' },
        m.nome + (m.eh_grupo ? ' 👥' : '') + (m.eh_broadcast ? ' 📢' : '')));
      linha1.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);white-space:nowrap' },
        (m.hora || '') + (m.nao_lidas ? ' · 🟢 ' + m.nao_lidas : '')));
      item.append(linha1);

      if (m.ultima_msg) {
        item.append(el('div', {
          style: 'font-size:12px;color:var(--cor-texto-2);margin-top:4px;font-style:italic;word-break:break-word;line-height:1.4',
        }, '"' + m.ultima_msg.slice(0, 220) + '"'));
      }

      // Badges dos perfis que bateram
      const badges = el('div', { style: 'display:flex;gap:4px;flex-wrap:wrap;margin-top:6px' });
      if (m._bateu_livre) {
        badges.append(el('span', {
          class: 'px-badge',
          style: 'background:rgba(64,134,237,0.15);color:var(--cor-acento);font-size:10px',
        }, `🔎 "${palavraLivre}"`));
      }
      for (const p of (m._perfis || [])) {
        badges.append(el('span', { class: 'px-badge', style: 'font-size:10px' }, `${p.icone} ${p.nome}`));
      }
      if (badges.children.length > 0) item.append(badges);

      lista.append(item);
    }
    box.append(lista);
  }

  // Botões
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap' });
  const btnNova = el('button', { class: 'modal-pinguim-btn', type: 'button' }, '🔄 Nova busca');
  btnNova.addEventListener('click', () => { overlay.remove(); abrirBuscaWhatsApp(); });
  const btnFechar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  acoes.append(btnNova, btnFechar);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);
}

// Função legada removida em v0.24 — substituída por mostrarResultadoBuscaWhatsApp
function _mostrarResultadoTriagemWhatsApp_DEPRECATED({ resultado }) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:760px;max-height:92vh;overflow-y:auto' });
  const modoLabel = resultado.modo === 'dms' ? '💬 Triagem de conversas 1-a-1' : '👥 Triagem de grupos';
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, modoLabel));

  // Toast inline no rodapé do modal (some sozinho em 4s)
  function toastNoModal(msg, kind = 'aviso') {
    let tEl = box.querySelector('.wa-toast-inline');
    if (!tEl) {
      tEl = el('div', {
        class: 'wa-toast-inline',
        style: 'position:sticky;bottom:0;margin-top:12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4;background:rgba(231,76,60,0.12);border:1px solid rgba(231,76,60,0.4);color:#ffb4ab',
      });
      box.append(tEl);
    }
    tEl.textContent = msg;
    tEl.style.display = 'block';
    clearTimeout(tEl._hideTimer);
    tEl._hideTimer = setTimeout(() => { tEl.style.display = 'none'; }, 4500);
  }

  // Pede pro content script abrir a conversa no WhatsApp Web.
  // Modal só fecha SE o content script confirmar sucesso. Se falhar, toast com motivo.
  function abrirConversa(nome) {
    const respId = 'wa-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
    let timeoutId = null;
    function cleanup() {
      window.removeEventListener('message', onResp);
      if (timeoutId) clearTimeout(timeoutId);
    }
    function onResp(ev) {
      if (ev?.data?.pinguimTipo !== 'ABRIR_CONVERSA_WHATSAPP_RESP') return;
      if (ev.data.respId !== respId) return;
      cleanup();
      if (ev.data.ok) {
        overlay.remove();
      } else {
        toastNoModal('⚠ ' + (ev.data.motivo || 'não consegui abrir, tente de novo'));
      }
    }
    window.addEventListener('message', onResp);
    timeoutId = setTimeout(() => {
      cleanup();
      toastNoModal('⚠ Sem resposta da página — confirme que a aba ativa é o WhatsApp Web.');
    }, 3000);
    try {
      window.parent.postMessage({ pinguimTipo: 'ABRIR_CONVERSA_WHATSAPP', nome, respId }, '*');
    } catch (_) {
      cleanup();
      toastNoModal('⚠ Erro de comunicação com a página.');
    }
  }

  // Resumo
  const resumo = el('div', { class: 'px-meta', style: 'margin-bottom:14px' });
  resumo.append(el('span', {}, `${resultado.total_classificado} conversas classificadas em ${Object.keys(resultado.baldes).length} baldes`));
  if (resultado.latencia_ms) resumo.append(el('span', { class: 'px-meta', style: 'margin-left:8px' }, `· ${(resultado.latencia_ms/1000).toFixed(1)}s`));
  box.append(resumo);

  // Dica de uso
  box.append(el('div', { class: 'px-meta', style: 'margin-bottom:12px;font-size:11px;color:var(--cor-acento)' },
    '👆 Clique no nome de qualquer conversa pra abrir direto no WhatsApp.'));

  // TOP 5 AÇÃO (destaque) — itens clicáveis
  if (Array.isArray(resultado.top_5_acao) && resultado.top_5_acao.length) {
    const cardTop = el('div', { class: 'px-card', style: 'background:rgba(64,134,237,0.08);border-color:var(--cor-acento);margin-bottom:16px' });
    cardTop.append(el('div', { class: 'px-rotulo' }, '⚡ Top 5 — abre agora'));
    const lista = el('div', { style: 'margin-top:8px' });
    resultado.top_5_acao.forEach((c, i) => {
      const item = el('div', {
        style: 'padding:8px 10px;background:var(--cor-fundo);border-radius:var(--raio-2);margin-bottom:6px;cursor:pointer;transition:background 0.15s',
        title: 'Clique pra abrir essa conversa no WhatsApp',
      });
      item.addEventListener('mouseenter', () => item.style.background = 'var(--cor-fundo-2)');
      item.addEventListener('mouseleave', () => item.style.background = 'var(--cor-fundo)');
      item.addEventListener('click', () => abrirConversa(c.nome));

      item.append(el('div', { style: 'display:flex;justify-content:space-between;gap:8px' }, [
        el('div', { style: 'font-weight:600;font-size:13px;flex:1' }, `${i+1}. ${c.nome}`),
        el('div', { style: 'font-size:11px;color:var(--cor-texto-2);white-space:nowrap' }, `${c.hora || ''}${c.nao_lidas ? ' · 🟢 '+c.nao_lidas : ''}`),
      ]));
      if (c.ultima_msg) item.append(el('div', { style: 'font-size:12px;color:var(--cor-texto-2);margin-top:4px;font-style:italic;word-break:break-word' }, '"' + c.ultima_msg.slice(0, 180) + '"'));
      item.append(el('div', { class: 'px-meta', style: 'margin-top:4px;font-size:11px' }, `→ ${c.balde} · ${c.motivo}`));
      lista.append(item);
    });
    cardTop.append(lista);
    box.append(cardTop);
  }

  // Baldes (cada um expandível) — itens clicáveis com preview maior
  const baldesMeta = resultado.baldes_meta || [];
  for (const meta of baldesMeta) {
    const itens = resultado.baldes[meta.slug] || [];
    if (itens.length === 0) continue;
    const card = el('div', { class: 'px-card', style: 'margin-bottom:10px' });
    const cabecalho = el('button', {
      type: 'button',
      style: 'background:transparent;border:none;color:var(--cor-texto);font-size:13px;font-weight:500;cursor:pointer;width:100%;text-align:left;padding:0;display:flex;justify-content:space-between',
    }, [
      el('span', {}, `${meta.icone} ${meta.nome} (${itens.length})`),
      el('span', { style: 'color:var(--cor-texto-2);font-size:11px' }, '▼ ver'),
    ]);
    card.append(cabecalho);
    const lista = el('div', { style: 'display:none;margin-top:10px' });
    itens.forEach(c => {
      const item = el('div', {
        style: 'padding:8px 10px;border-left:2px solid var(--cor-borda-forte);margin-bottom:6px;cursor:pointer;border-radius:0 var(--raio-2) var(--raio-2) 0;transition:background 0.15s',
        title: 'Clique pra abrir essa conversa no WhatsApp',
      });
      item.addEventListener('mouseenter', () => {
        item.style.background = 'var(--cor-fundo-2)';
        item.style.borderLeftColor = 'var(--cor-acento)';
      });
      item.addEventListener('mouseleave', () => {
        item.style.background = '';
        item.style.borderLeftColor = 'var(--cor-borda-forte)';
      });
      item.addEventListener('click', () => abrirConversa(c.nome));

      item.append(el('div', { style: 'display:flex;justify-content:space-between;font-size:12px;gap:6px' }, [
        el('span', { style: 'font-weight:600;flex:1' }, c.nome + (c.match_time ? ' 👤' : '') + (c.eh_grupo ? ' 👥' : '')),
        el('span', { class: 'px-meta', style: 'font-size:10px;white-space:nowrap' }, (c.hora || '') + (c.nao_lidas ? ' · 🟢 ' + c.nao_lidas : '')),
      ]));
      if (c.ultima_msg) item.append(el('div', {
        style: 'font-size:11px;color:var(--cor-texto-2);font-style:italic;margin-top:4px;word-break:break-word;line-height:1.4',
      }, '"' + c.ultima_msg.slice(0,180) + '"'));
      if (c.motivo) item.append(el('div', { class: 'px-meta', style: 'font-size:10px;margin-top:3px;opacity:0.85' }, '→ ' + c.motivo));
      lista.append(item);
    });
    card.append(lista);
    cabecalho.addEventListener('click', () => {
      const visivel = lista.style.display !== 'none';
      lista.style.display = visivel ? 'none' : 'block';
      cabecalho.querySelector('span:last-child').textContent = visivel ? '▼ ver' : '▲ ocultar';
    });
    box.append(card);
  }

  // Botoes
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end;gap:8px;margin-top:14px;flex-wrap:wrap' });
  const btnFechar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  acoes.append(btnFechar);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);
}

function mostrarResultadoTranscreverYoutube({ resultado }) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:820px;max-height:92vh;overflow-y:auto' });
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, '📺 YouTube transcrito'));

  // Cabeçalho com thumbnail + canal + métricas
  const cab = el('div', { class: 'px-row', style: 'gap:12px;margin-bottom:14px;align-items:flex-start' });
  if (resultado.thumbnail) {
    cab.append(el('img', { src: resultado.thumbnail, style: 'width:180px;height:auto;border-radius:var(--raio-2);flex-shrink:0' }));
  }
  const cabInfo = el('div', { style: 'flex:1;min-width:0' }, [
    el('div', { style: 'font-weight:600;font-size:14px;margin-bottom:4px;word-break:break-word' }, resultado.titulo || ''),
    el('div', { style: 'color:var(--cor-texto-2);font-size:12px;margin-bottom:6px' }, '📺 ' + (resultado.canal || '—') + ' · ⏱ ' + formatarDuracao(resultado.duracao_segundos)),
  ]);
  const metricas = el('div', { class: 'px-row', style: 'gap:6px;flex-wrap:wrap' });
  if (resultado.views) metricas.append(el('span', { class: 'px-badge' }, `▶ ${formatarNumero(resultado.views)} views`));
  if (resultado.likes) metricas.append(el('span', { class: 'px-badge' }, `❤ ${formatarNumero(resultado.likes)} likes`));
  metricas.append(el('span', { class: 'px-badge' }, `💬 ${resultado.comentarios_filtrados || 0} comentários filtrados`));
  cabInfo.append(metricas);
  cab.append(cabInfo);
  box.append(cab);

  const grid = el('div', { style: 'display:grid;grid-template-columns:1fr;gap:12px' });

  // Card: Transcript
  const cardTrans = el('div', { class: 'px-card' });
  cardTrans.append(el('div', { class: 'px-rotulo' }, '📝 Transcript'));
  if (resultado.transcript) {
    cardTrans.append(el('div', { class: 'px-meta', style: 'font-size:11px;margin-top:4px' }, `${resultado.transcript.length.toLocaleString('pt-BR')} caracteres · ${resultado.transcript_segmentos} segmentos`));
    cardTrans.append(el('div', {
      style: 'margin-top:8px;max-height:320px;overflow-y:auto;background:var(--cor-fundo-2);padding:10px;border-radius:var(--raio-2);font-size:12px;line-height:1.5;color:var(--cor-texto-2);white-space:pre-wrap'
    }, resultado.transcript));
  } else {
    cardTrans.append(el('div', { class: 'px-meta', style: 'margin-top:6px;color:var(--cor-aviso)' }, '⚠ Vídeo sem transcript disponível (sem auto-caption ou legendas oficiais). ' + (resultado.transcript_erro || '')));
  }
  grid.append(cardTrans);

  // Card: Comentários
  if (Array.isArray(resultado.comentarios) && resultado.comentarios.length) {
    const cardCom = el('div', { class: 'px-card' });
    cardCom.append(el('div', { class: 'px-rotulo' }, `💬 Top ${resultado.comentarios.length} comentários (ordenados por relevância)`));
    cardCom.append(el('div', { class: 'px-meta', style: 'font-size:11px;margin-top:4px' }, `Filtramos ${resultado.comentarios_total_brutos - resultado.comentarios_filtrados} saudações/agradecimentos do total bruto.`));
    const lista = el('div', { style: 'margin-top:10px;max-height:480px;overflow-y:auto' });
    resultado.comentarios.forEach((c, i) => {
      const item = el('div', { style: 'padding:8px 10px;background:var(--cor-fundo-2);border-radius:var(--raio-2);margin-bottom:6px' });
      item.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:4px' }, `@${c.autor.replace(/^@/, '')} · ❤ ${formatarNumero(c.likes)}${c.respostas ? ' · 💬 ' + c.respostas : ''}`));
      item.append(el('div', { style: 'font-size:12px;color:var(--cor-texto);white-space:pre-wrap;word-break:break-word' }, c.texto));
      lista.append(item);
    });
    cardCom.append(lista);
    grid.append(cardCom);
  } else if (resultado.comentarios_erro) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '💬 Comentários'));
    card.append(el('div', { class: 'px-meta', style: 'margin-top:6px;color:var(--cor-aviso)' }, '⚠ ' + resultado.comentarios_erro));
    grid.append(card);
  }

  // Card: Tags
  if (Array.isArray(resultado.tags) && resultado.tags.length) {
    const card = el('div', { class: 'px-card' });
    card.append(el('div', { class: 'px-rotulo' }, '🏷 Tags do vídeo'));
    const linha = el('div', { class: 'px-row', style: 'gap:6px;margin-top:6px;flex-wrap:wrap' });
    resultado.tags.slice(0, 30).forEach(t => linha.append(el('span', { class: 'px-badge' }, t)));
    card.append(linha);
    grid.append(card);
  }

  box.append(grid);

  // Botões
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end;gap:8px;margin-top:14px;flex-wrap:wrap' });

  if (resultado.transcript) {
    const btnCopTr = el('button', { class: 'modal-pinguim-btn' }, '📋 Copiar transcript');
    btnCopTr.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(resultado.transcript);
        btnCopTr.textContent = '✓ Copiado';
        setTimeout(() => btnCopTr.textContent = '📋 Copiar transcript', 2000);
      } catch (_) {}
    });
    acoes.append(btnCopTr);

    const btnMd = el('button', { class: 'modal-pinguim-btn' }, '📄 Baixar .md');
    btnMd.addEventListener('click', () => {
      const lines = [
        `# ${resultado.titulo}`,
        ``,
        `**Canal:** ${resultado.canal}`,
        `**Duração:** ${formatarDuracao(resultado.duracao_segundos)}`,
        `**Views:** ${resultado.views?.toLocaleString('pt-BR')}`,
        `**Likes:** ${resultado.likes?.toLocaleString('pt-BR')}`,
        `**Publicado em:** ${resultado.publicado_em?.slice(0,10)}`,
        `**URL:** https://www.youtube.com/watch?v=${resultado.video_id}`,
        ``,
        `## Transcript`,
        ``,
        resultado.transcript,
        ``,
      ];
      if (resultado.comentarios?.length) {
        lines.push(`## Top ${resultado.comentarios.length} comentários`);
        lines.push('');
        resultado.comentarios.forEach((c, i) => {
          lines.push(`### ${i+1}. @${c.autor.replace(/^@/, '')} — ❤ ${c.likes}`);
          lines.push(c.texto);
          lines.push('');
        });
      }
      const blob = new Blob([lines.join('\n')], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const safeName = (resultado.titulo || 'youtube').replace(/[^a-zA-Z0-9-_À-ſ]+/g, '-').slice(0, 60);
      a.download = `youtube-${safeName}.md`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
    acoes.append(btnMd);
  }

  if (resultado.comentarios?.length) {
    const btnCom = el('button', { class: 'modal-pinguim-btn' }, '📋 Copiar comentários');
    btnCom.addEventListener('click', async () => {
      const txt = resultado.comentarios.map(c => `@${c.autor.replace(/^@/, '')} (❤${c.likes}): ${c.texto}`).join('\n\n');
      try {
        await navigator.clipboard.writeText(txt);
        btnCom.textContent = '✓ Copiado';
        setTimeout(() => btnCom.textContent = '📋 Copiar comentários', 2000);
      } catch (_) {}
    });
    acoes.append(btnCom);
  }

  const btnArs = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary' }, '📦 Ver no Arsenal');
  btnArs.addEventListener('click', () => { overlay.remove(); irPara('arsenal'); });
  acoes.append(btnArs);

  const btnFechar = el('button', { class: 'modal-pinguim-btn' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  acoes.append(btnFechar);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);
}

// --------- EXPANSAO 80vw ---------
function toggleExpandir() {
  modoExpandido = !modoExpandido;
  window.parent.postMessage({ pinguimTipo: modoExpandido ? 'EXPANDIR_SIDEBAR' : 'RECOLHER_SIDEBAR' }, '*');
  // Re-renderiza pra atualizar icones do botao
  irPara(categoriaAtiva);
}

// Esc fecha modo expandido
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && modoExpandido) toggleExpandir();
});

// --------- TELA LOGIN ---------
function renderLogin() {
  conteudo.innerHTML = '';
  setUsuario('');
  setStatus('Faça login para continuar');

  const erroBox = el('div', { id: 'login-erro', style: 'display:none' });

  const inputEmail = el('input', { type: 'email', class: 'input-campo', placeholder: 'voce@agenciapinguim.com', autocomplete: 'username' });
  const inputSenha = el('input', { type: 'password', class: 'input-campo', placeholder: 'sua senha', autocomplete: 'current-password' });

  const botaoLogin = el('button', { class: 'botao-primario', type: 'button' }, 'Entrar');
  botaoLogin.addEventListener('click', async () => {
    erroBox.style.display = 'none';
    botaoLogin.disabled = true;
    botaoLogin.textContent = 'Entrando...';
    try {
      session = await loginSupabase(inputEmail.value.trim(), inputSenha.value);
      await storageSet({ session });
      renderNavCategorias();
      irPara('home');
    } catch (e) {
      erroBox.style.display = 'block';
      erroBox.className = 'alerta-erro';
      erroBox.textContent = e.message || 'Falha no login';
    } finally {
      botaoLogin.disabled = false;
      botaoLogin.textContent = 'Entrar';
    }
  });

  // Enter envia
  [inputEmail, inputSenha].forEach(i => i.addEventListener('keydown', e => {
    if (e.key === 'Enter') botaoLogin.click();
  }));

  conteudo.append(
    el('div', { class: 'login-box' }, [
      el('div', { class: 'login-titulo' }, 'Pinguim Agentes'),
      el('div', { class: 'login-subtitulo' }, 'Acesso restrito ao time'),
      erroBox,
      el('div', { class: 'input-grupo' }, [
        el('label', { class: 'input-label' }, 'Email'),
        inputEmail,
      ]),
      el('div', { class: 'input-grupo' }, [
        el('label', { class: 'input-label' }, 'Senha'),
        inputSenha,
      ]),
      botaoLogin,
    ])
  );
}

// --------- TELA LISTA AGENTES ---------
let buscaTexto = '';
let squadFiltro = 'todas';
let buscaResultadoHibrido = null; // resultados ordenados da Edge Function quando busca ativa

// v0.9.1: modo='chat' (so hero + auto-route), 'agentes' (so catalogo), 'ambos' (default legado)
// v0.12.3: cabecalho flutuante com botao expandir (Chat e Agentes)
function montarCabecalhoExpandir() {
  const cab = el('div', {
    class: 'cab-categoria',
  });
  const btn = el('button', {
    class: 'px-icon-btn px-icon-btn--sm',
    title: modoExpandido ? 'Recolher' : 'Expandir',
    'aria-label': modoExpandido ? 'Recolher' : 'Expandir',
  }, [modoExpandido ? '⊟' : '⊞']);
  btn.addEventListener('click', toggleExpandir);
  cab.append(btn);
  return cab;
}

async function renderAgentes(modo = 'ambos') {
  conteudo.innerHTML = '';
  setUsuario(session?.user?.email || '');
  setStatus('Carregando agentes...');
  // v0.12.3: cabecalho com botao expandir
  conteudo.append(montarCabecalhoExpandir());

  let agentes, squads;
  try {
    ({ agentes, squads } = await carregarAgentesESquads());
  } catch (e) {
    const msg = (e.message || '').toLowerCase();
    if (msg.includes('extension context invalidated') || msg.includes('receiving end does not exist')) {
      // Extensao foi atualizada, contexto da aba ficou orfao
      conteudo.innerHTML = '';
      const box = el('div', { class: 'login-box' }, [
        el('div', { class: 'login-titulo' }, '⚠ Extensão atualizada'),
        el('div', { class: 'login-subtitulo', style: 'margin-bottom:16px' },
          'A versão da extensão foi atualizada. Esta aba ainda está rodando a versão antiga.'),
        (() => {
          const btn = el('button', { class: 'botao-primario', type: 'button' }, '🔄 Recarregar a página');
          btn.addEventListener('click', () => {
            // Fala pro content script recarregar a pagina toda
            window.parent.postMessage({ pinguimTipo: 'RECARREGAR_PAGINA' }, '*');
          });
          return btn;
        })(),
        el('div', { class: 'login-subtitulo', style: 'margin-top:12px;font-size:11px' },
          'Ou aperte F5 manualmente.'),
      ]);
      conteudo.append(box);
      setStatus('Pagina precisa recarregar');
      return;
    }
    conteudo.append(el('div', { class: 'alerta-erro' }, 'Erro ao carregar agentes: ' + e.message));
    setStatus('Erro');
    return;
  }
  setStatus(`${agentes.length} agentes em produção`);

  const squadMap = new Map(squads.map(s => [s.id, s]));

  // Squad chips (filtro)
  const squadsComAgente = [...new Set(agentes.map(a => a.squad_id).filter(Boolean))]
    .map(id => squadMap.get(id))
    .filter(Boolean)
    .sort((a, b) => a.slug.localeCompare(b.slug));

  const chipsBox = el('div', { class: 'squad-selector' });
  const adicionaChip = (slug, nome, emoji) => {
    const chip = el('div', {
      class: 'squad-chip' + (squadFiltro === slug ? ' ativo' : ''),
    }, `${emoji || ''} ${nome}`.trim());
    chip.addEventListener('click', () => {
      squadFiltro = slug;
      buscaTexto = ''; // limpa busca ao trocar squad (evita conflito de filtros)
      renderCategoriaAtual();  // v0.9.1: preserva chat vs agentes
    });
    chipsBox.appendChild(chip);
  };
  adicionaChip('todas', 'Todas');
  // v0.25.3 — agentes operacionais agora tem squad real "Acessos" no banco,
  // então saem na lista normal de squadsComAgente. Não precisa mais de pseudo-squad.
  squadsComAgente.forEach(s => adicionaChip(s.slug, s.nome, s.emoji));

  // Busca
  const buscaInput = el('input', {
    type: 'text', class: 'busca-input',
    placeholder: 'Buscar: copy, email, hook, vsl, lançamento...',
    value: buscaTexto,
  });
  // Debounce pra busca híbrida (evita chamar API a cada tecla)
  let buscaTimer = null;
  buscaInput.addEventListener('input', (ev) => {
    buscaTexto = ev.target.value;
    if (buscaTimer) clearTimeout(buscaTimer);
    if (!buscaTexto.trim()) {
      // Limpou busca → re-render imediato (modo grupos)
      buscaResultadoHibrido = null;
      rerenderLista();
      return;
    }
    // Aguarda 350ms sem digitar antes de chamar API
    buscaTimer = setTimeout(async () => {
      try {
        await buscarHibrido(buscaTexto);
        rerenderLista();
      } catch (e) {
        console.warn('[busca] erro:', e.message);
        rerenderLista(); // cai no fallback textual
      }
    }, 350);
  });

  // ============== HOME — Campo de pergunta com auto-route ==============
  // Padrao tipo ChatGPT/Claude: textarea grande, botao enviar dentro como icone,
  // placeholder curto. Sem resize, sem visual de formulario burocratico.
  const perguntaInput = el('textarea', {
    class: 'home-pergunta-input',
    placeholder: 'O que você quer fazer?',
    rows: 1,
  });
  const perguntaBtn = el('button', {
    class: 'home-pergunta-btn',
    type: 'button',
    title: 'Enviar (Enter)',
    'aria-label': 'Enviar',
  }, '↑');
  const perguntaCaixa = el('div', { class: 'home-pergunta-caixa' }, [
    perguntaInput,
    perguntaBtn,
  ]);

  const perguntaResultadoBox = el('div', { class: 'home-pergunta-resultado' });
  const perguntaErroBox = el('div', { class: 'home-pergunta-erro', style: 'display:none' });

  const heroBox = el('div', { class: 'home-hero' }, [
    el('div', { class: 'home-hero-saudacao' }, 'Olá 👋 · v0.7.7'),
    el('div', { class: 'home-hero-titulo' }, 'O que você precisa?'),
    perguntaCaixa,
    el('div', { class: 'home-hero-exemplos' }, [
      el('span', { class: 'home-hero-exemplos-label' }, 'Exemplos:'),
      el('span', { class: 'home-hero-chip', 'data-exemplo': 'me traz uma prova social do Elo' }, 'prova social do Elo'),
      el('span', { class: 'home-hero-chip', 'data-exemplo': 'consulta o telefone (41) 99275-5338' }, 'consultar cliente'),
      el('span', { class: 'home-hero-chip', 'data-exemplo': 'esse aluno tem acesso?' }, 'verificar acesso'),
    ]),
    perguntaErroBox,
    perguntaResultadoBox,
  ]);
  // Click nos chips de exemplo: preenche e dispara
  heroBox.querySelectorAll('.home-hero-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const exemplo = chip.getAttribute('data-exemplo');
      perguntaInput.value = exemplo;
      autoRoute(exemplo);
    });
  });
  // v0.9.1: heroBox so aparece em modo 'chat' ou 'ambos'
  if (modo !== 'agentes') conteudo.append(heroBox);

  // Auto-resize do textarea (cresce conforme digita ate max-height do CSS)
  perguntaInput.addEventListener('input', () => {
    perguntaInput.style.height = 'auto';
    perguntaInput.style.height = Math.min(perguntaInput.scrollHeight, 200) + 'px';
  });

  // Triagem como fallback secundario (link compacto, nao mais card grande)
  const triagemAg = agentes.find(a => a.slug === 'pinguim-triagem');

  // Estado da home: modo 'pergunta' (default) ou 'catalogo' (explorar todos)
  // v0.9.1: em modo='agentes' ja comeca em catalogo aberto
  let modoHome = (modo === 'agentes') ? 'catalogo' : 'pergunta';

  // Botao toggle pra abrir catalogo (so em modo 'ambos' — legado)
  const btnToggleCatalogo = el('button', {
    class: 'home-toggle-catalogo',
    type: 'button',
  }, '🔍 Ver todos os agentes');
  if (modo === 'ambos') conteudo.append(btnToggleCatalogo);

  // Container do catalogo:
  //   - modo='chat':    nao aparece
  //   - modo='agentes': aparece aberto direto
  //   - modo='ambos':   escondido por padrao (legado)
  const catalogoVisivel = (modo === 'agentes');
  const catalogoBox = el('div', { class: 'home-catalogo', style: catalogoVisivel ? '' : 'display:none' });
  catalogoBox.append(
    el('div', { class: 'busca-agentes' }, buscaInput),
    chipsBox,
  );
  // v0.22.4: link "Em desenvolvimento" — visivel ANTES da lista de cards
  if (modo === 'agentes') {
    const linkBacklog = el('button', {
      style: 'background:transparent;border:1px dashed var(--cor-borda-forte);color:var(--cor-texto-2);padding:6px 10px;border-radius:var(--raio-2);cursor:pointer;font-size:11px;display:inline-flex;align-items:center;gap:6px;margin-bottom:12px',
      title: 'Mostra agentes que ainda nao passaram na auditoria de qualidade',
    }, '🔧 Ver agentes em desenvolvimento');
    linkBacklog.addEventListener('mouseenter', () => { linkBacklog.style.color = 'var(--cor-texto)'; linkBacklog.style.borderColor = 'var(--cor-acento)'; });
    linkBacklog.addEventListener('mouseleave', () => { linkBacklog.style.color = 'var(--cor-texto-2)'; linkBacklog.style.borderColor = 'var(--cor-borda-forte)'; });
    linkBacklog.addEventListener('click', () => abrirModalBacklogAgentes());
    catalogoBox.append(linkBacklog);
  }

  const listaBox = el('div', { id: 'lista-agentes' });
  catalogoBox.append(listaBox);

  if (modo !== 'chat') conteudo.append(catalogoBox);

  btnToggleCatalogo.addEventListener('click', () => {
    modoHome = modoHome === 'pergunta' ? 'catalogo' : 'pergunta';
    if (modoHome === 'catalogo') {
      catalogoBox.style.display = 'block';
      btnToggleCatalogo.textContent = '↑ Esconder catálogo';
      buscaInput.focus();
    } else {
      catalogoBox.style.display = 'none';
      btnToggleCatalogo.textContent = '🔍 Ver todos os agentes';
    }
  });

  // ============== AUTO-ROUTE v3 (Motor de busca escalavel ate 10k+ agentes) ==============
  // Thresholds usam CONFIANCA (saida do rerank gpt-4o-mini), nao score bruto:
  //   >=0.7 = abre direto (alta confianca)
  //   0.4-0.7 = mostra top 3 pra usuario escolher
  //   <0.4 = sugere Pinguim Triagem
  const CONF_ALTA = 0.7;
  const CONF_MEDIA = 0.4;

  // Registra feedback no banco (loop fechado de aprendizado)
  async function registrarFeedbackBusca({ query, sugerido_slug, escolhido_slug, posicao, modo, confianca, latencia_ms }) {
    if (!session?.access_token) return;
    try {
      const url = `${SUPABASE_URL}/functions/v1/registrar-feedback-busca`;
      await fetchProxy(url, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query,
          agente_sugerido_slug: sugerido_slug || null,
          agente_escolhido_slug: escolhido_slug,
          posicao_escolhido: posicao || null,
          modo: modo || 'auto_route',
          confianca_top1: confianca || null,
          latencia_ms: latencia_ms || null,
        }),
      });
    } catch (e) {
      console.warn('[feedback] falhou silenciosamente:', e?.message);
    }
  }

  async function autoRoute(pergunta) {
    if (!pergunta || pergunta.trim().length < 3) {
      perguntaErroBox.textContent = 'Escreve um pouco mais — pelo menos 3 letras.';
      perguntaErroBox.style.display = 'block';
      return;
    }
    perguntaErroBox.style.display = 'none';
    perguntaResultadoBox.innerHTML = '<div class="home-pergunta-loading">🔎 Achando o melhor agente...</div>';
    perguntaBtn.disabled = true;

    let resp = null;
    let resultados = [];
    let confianca = 0;
    let latencia = 0;
    try {
      const url = `${SUPABASE_URL}/functions/v1/tool-buscar-agente-v3`;
      const r = await fetchProxy(url, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: pergunta, top_k: 5 }),
      });
      if (r.ok && r.body) {
        resp = r.body;
        resultados = r.body.agentes || [];
        confianca = r.body.confianca_top1 || 0;
        latencia = r.body.latencia_ms || 0;
      }
    } catch (e) {
      console.warn('[autoRoute] erro:', e.message);
    } finally {
      perguntaBtn.disabled = false;
    }

    const topo = resultados[0];
    const top3Slugs = resultados.slice(0, 3).map(r => r.slug);

    // CASO 1 — Confianca ALTA: abre direto + registra feedback "aceitou sugestao"
    if (topo && confianca >= CONF_ALTA) {
      const agente = agentes.find(a => a.slug === topo.slug);
      if (agente) {
        const sq = squadMap.get(agente.squad_id);
        agente._squad_slug = sq?.slug;
        perguntaResultadoBox.innerHTML = '';
        // Registra que sistema sugeriu E usuario aceitou (mesmo agente)
        registrarFeedbackBusca({
          query: pergunta, sugerido_slug: topo.slug, escolhido_slug: topo.slug,
          posicao: 1, modo: 'auto_route', confianca, latencia_ms: latencia,
        });
        renderChat(agente, pergunta);
        return;
      }
    }

    // CASO 2 — Confianca MEDIA: mostra top 3 pra escolher (registra qual escolheu)
    if (topo && confianca >= CONF_MEDIA) {
      perguntaResultadoBox.innerHTML = '';
      const topNbox = el('div', { class: 'home-top-candidatos' });
      topNbox.append(el('div', { class: 'home-top-titulo' },
        'Tenho candidatos pra "' + pergunta.slice(0, 50) + '". Clica em quem deve responder:'));

      const topN = resultados.slice(0, 3);
      topN.forEach((r, idx) => {
        const ag = agentes.find(a => a.slug === r.slug);
        if (!ag) return;
        const sq = squadMap.get(ag.squad_id);
        const card = el('div', { class: 'home-top-card' }, [
          el('img', {
            class: 'home-top-avatar',
            src: gerarAvatarDataUri(ag.slug, sq?.slug),
            alt: ag.nome,
          }),
          el('div', { class: 'home-top-info' }, [
            el('div', { class: 'home-top-nome' }, ag.nome),
            el('div', { class: 'home-top-missao' }, (ag.missao || ag.proposito || '').slice(0, 110)),
          ]),
          el('span', { class: 'home-top-seta' }, '→'),
        ]);
        card.addEventListener('click', () => {
          ag._squad_slug = sq?.slug;
          perguntaResultadoBox.innerHTML = '';
          // Registra: sistema sugeriu top1, usuario escolheu posicao (idx+1)
          registrarFeedbackBusca({
            query: pergunta,
            sugerido_slug: topo.slug,
            escolhido_slug: r.slug,
            posicao: idx + 1,
            modo: 'top3_pick',
            confianca,
            latencia_ms: latencia,
          });
          renderChat(ag, pergunta);
        });
        topNbox.append(card);
      });
      perguntaResultadoBox.append(topNbox);
      return;
    }

    // CASO 3 — Confianca BAIXA: sugere Triagem
    perguntaResultadoBox.innerHTML = '';
    const semMatch = el('div', { class: 'home-sem-match' }, [
      el('div', { class: 'home-sem-match-titulo' }, '🤔 Não achei nenhum agente especialista nisso.'),
      el('div', { class: 'home-sem-match-sub' },
        triagemAg
          ? 'Quer falar com o Pinguim Triagem? Ele é generalista e te ajuda a achar o caminho.'
          : 'Tenta reformular a pergunta ou explora todos agentes abaixo.'),
    ]);
    if (triagemAg) {
      const btnTriagem = el('button', { class: 'home-pergunta-btn', type: 'button', style: 'margin-top:10px;width:auto;padding:0 16px' },
        '→ Falar com Pinguim Triagem');
      btnTriagem.addEventListener('click', () => {
        triagemAg._squad_slug = 'agencia-pinguim';
        perguntaResultadoBox.innerHTML = '';
        registrarFeedbackBusca({
          query: pergunta,
          sugerido_slug: topo?.slug || null,
          escolhido_slug: 'pinguim-triagem',
          modo: 'triagem',
          confianca,
          latencia_ms: latencia,
        });
        renderChat(triagemAg, pergunta);
      });
      semMatch.append(btnTriagem);
    }
    perguntaResultadoBox.append(semMatch);
  }

  perguntaBtn.addEventListener('click', () => autoRoute(perguntaInput.value));
  perguntaInput.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter' && !ev.shiftKey) {
      ev.preventDefault();
      autoRoute(perguntaInput.value);
    }
  });
  setTimeout(() => perguntaInput.focus(), 100);

  function avatarUrl(slug, squadSlug) {
    // Gerador local SVG paramétrico (Pinguim Squad)
    return gerarAvatarDataUri(slug, squadSlug);
  }

  function renderAgenteItem(a, squadMap) {
    const sq = squadMap.get(a.squad_id);
    const squadSlug = sq?.slug;
    const avatarImg = el('img', {
      class: 'agente-item-avatar agente-item-avatar-img',
      src: avatarUrl(a.slug, squadSlug),
      alt: a.nome,
    });
    const item = el('div', { class: 'agente-item' }, [
      el('div', { class: 'agente-item-head' }, [
        avatarImg,
        el('div', { class: 'agente-item-nome' }, a.nome),
        (a._execs > 0)
          ? el('span', { class: 'agente-item-execs', title: `${a._execs} usos recentes` }, `${a._execs}×`)
          : null,
      ].filter(Boolean)),
      el('div', { class: 'agente-item-missao' }, a.missao || a.proposito || ''),
    ]);
    item.addEventListener('click', () => {
      // Anexa squad_slug no obj antes de passar pro chat (pra avatar no header)
      a._squad_slug = squadSlug;
      renderChat(a);
    });
    return item;
  }

  async function buscarHibrido(query) {
    if (!session?.access_token) return;
    try {
      const url = `${SUPABASE_URL}/functions/v1/tool-buscar-agente-hibrido`;
      const body = { query, top_k: 20 };
      if (squadFiltro !== 'todas') body.squad_slug = squadFiltro;
      const r = await fetchProxy(url, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        console.warn('[buscarHibrido] erro:', r.body?.erro || r.status);
        buscaResultadoHibrido = null;
        return;
      }
      // Cruza com lista local pra ter dados completos (_execs etc) — busca devolve slug
      const slugsRanked = (r.body.agentes || []).map(a => a.slug);
      const mapLocal = new Map(agentes.map(a => [a.slug, a]));
      buscaResultadoHibrido = slugsRanked
        .map(slug => mapLocal.get(slug))
        .filter(Boolean);
    } catch (e) {
      console.warn('[buscarHibrido] excecao:', e.message);
      buscaResultadoHibrido = null;
    }
  }

  function rerenderLista() {
    const q = buscaTexto.trim().toLowerCase();
    listaBox.innerHTML = '';

    // MODO BUSCA — usa resultado da Edge híbrida (ranqueado)
    if (q) {
      const filtrados = buscaResultadoHibrido
        || agentes.filter(a => {
          // Fallback textual local enquanto a Edge nao volta
          const hay = [a.nome, a.slug, a.missao, a.proposito].filter(Boolean).join(' ').toLowerCase();
          return hay.includes(q);
        });

      // Aplica filtro de squad se ativo (Edge ja filtra, mas no fallback nao)
      const visivel = filtrados.filter(a => {
        if (squadFiltro === 'todas') return true;
        const sq = squadMap.get(a.squad_id);
        return sq?.slug === squadFiltro;
      });

      if (visivel.length === 0) {
        listaBox.append(el('div', { class: 'alerta-erro', style: 'background:transparent;border:1px dashed var(--border);color:var(--fg-muted);text-align:center' },
          'Nenhum agente encontrado pra "' + q + '". Tenta outras palavras.'));
        return;
      }

      listaBox.append(el('div', { class: 'agente-grupo-titulo' }, `🔍 ${visivel.length} resultado${visivel.length === 1 ? '' : 's'}`));
      // v0.12.2: grid responsivo (1/2/3 colunas conforme viewport)
      const gridR = el('div', { class: 'agente-grid' });
      visivel.forEach(a => gridR.appendChild(renderAgenteItem(a, squadMap)));
      listaBox.append(gridR);
      return;
    }

    // MODO LISTA — agrupa por squad (sem busca ativa)
    const filtrados = agentes.filter(a => {
      if (squadFiltro !== 'todas') {
        const sq = squadMap.get(a.squad_id);
        if (!sq || sq.slug !== squadFiltro) return false;
      }
      return true;
    });

    if (filtrados.length === 0) {
      listaBox.append(el('div', { class: 'alerta-erro', style: 'background:transparent;border:1px dashed var(--border);color:var(--fg-muted);text-align:center' }, 'Nenhum agente nessa squad.'));
      return;
    }

    // SECAO "MAIS USADOS" (so quando nao tem filtro de squad)
    if (squadFiltro === 'todas') {
      const topUsados = [...filtrados]
        .filter(a => (a._execs || 0) > 0)
        .sort((a, b) => (b._execs || 0) - (a._execs || 0))
        .slice(0, 5);
      if (topUsados.length > 0) {
        listaBox.append(el('div', { class: 'agente-grupo-titulo' }, '⭐ Mais usados'));
        const gridTop = el('div', { class: 'agente-grid' });
        topUsados.forEach(a => gridTop.appendChild(renderAgenteItem(a, squadMap)));
        listaBox.append(gridTop);
      }
    }

    // Agrupa por squad
    const porSquad = new Map();
    for (const a of filtrados) {
      const sq = squadMap.get(a.squad_id);
      const key = sq ? sq.slug : '__sem_squad__';
      if (!porSquad.has(key)) porSquad.set(key, { squad: sq, agentes: [] });
      porSquad.get(key).agentes.push(a);
    }

    const ordem = [...porSquad.entries()].sort((x, y) => {
      if (x[0] === '__sem_squad__') return 1;
      if (y[0] === '__sem_squad__') return -1;
      return x[0].localeCompare(y[0]);
    });

    for (const [key, info] of ordem) {
      const titulo = info.squad ? `${info.squad.emoji || ''} ${info.squad.nome}` : '(Sem squad)';
      listaBox.append(el('div', { class: 'agente-grupo-titulo' }, titulo));
      const gridS = el('div', { class: 'agente-grid' });
      info.agentes.forEach(a => gridS.appendChild(renderAgenteItem(a, squadMap)));
      listaBox.append(gridS);
    }
  }

  rerenderLista();

  // Se ha texto pendente do context menu, abre seletor pra escolher agente
  if (textoPendente) {
    const aviso = el('div', { class: 'texto-selecionado' }, [
      el('div', { class: 'texto-selecionado-label' }, '📋 Texto selecionado pra revisar'),
      el('div', { class: 'texto-selecionado-corpo' }, textoPendente),
    ]);
    listaBox.insertBefore(aviso, listaBox.firstChild);
    listaBox.insertBefore(el('div', { class: 'agente-grupo-titulo' }, 'Escolha o agente que vai trabalhar nesse texto:'), aviso.nextSibling);
  }
}

// --------- TELA CHAT ---------
function renderChat(agente, perguntaInicial = null) {
  // v0.25.0 — agentes operacionais abrem modal estruturado em vez de chat LLM.
  // Capability `tipo: 'operacional'` + `modal_slug: '<slug>'` no banco.
  const cap = agente.capabilities || {};
  console.log('[pinguim] renderChat:', agente.slug, '| capabilities:', JSON.stringify(cap));
  if (cap.tipo === 'operacional' && cap.modal_slug) {
    console.log('[pinguim] → operacional, abrindo modal:', cap.modal_slug);
    abrirModalOperacional(agente);
    return;
  }
  try {
    conteudo.innerHTML = '';
    setStatus(`Conversando com ${agente.nome}`);

    const continuarConversa = conversaAtual?.agente?.slug === agente.slug;
    conversaAtual = continuarConversa
      ? conversaAtual
      : { agente, mensagens: [] };

    const headerVoltar = el('button', { class: 'chat-voltar', type: 'button' }, '←');
    headerVoltar.addEventListener('click', () => {
      conversaAtual = null;
      renderCategoriaAtual();  // v0.9.1: volta pra categoria origem (chat ou agentes)
    });

    const btnNovaConversa = el('button', {
      class: 'chat-nova-conversa',
      type: 'button',
      title: 'Começar conversa nova (esquece o histórico anterior)',
    }, 'Nova conversa');
    btnNovaConversa.addEventListener('click', async () => {
      const confirmado = await mostrarConfirmacao({
        titulo: 'Começar conversa nova',
        mensagem: `${agente.nome} vai esquecer tudo que falamos até agora. Quer continuar?`,
        textoConfirmar: 'Limpar histórico',
        textoCancelar: 'Cancelar',
        destrutivo: true,
      });
      if (!confirmado) return;
      btnNovaConversa.disabled = true; btnNovaConversa.textContent = 'Limpando...';
      const r = await limparHistoricoConversa(agente.slug);
      if (r.ok) {
        conversaAtual = { agente, mensagens: [], _conversaLimpa: true };
        renderChat(agente);
      } else {
        btnNovaConversa.disabled = false; btnNovaConversa.textContent = 'Nova conversa';
        await mostrarAlerta({
          titulo: 'Não consegui limpar',
          mensagem: 'Erro: ' + (r.erro || 'falha desconhecida'),
          tipo: 'erro',
        });
      }
    });

    // Pega squad slug do agente pra avatar (anexado em renderAgenteItem)
    const squadSlugDoChat = agente._squad_slug || null;
    let avatarSrc = '';
    try {
      avatarSrc = gerarAvatarDataUri(agente.slug, squadSlugDoChat);
    } catch (e) {
      console.error('[renderChat] erro avatar:', e);
    }
    conteudo.append(
      el('div', { class: 'chat-header' }, [
        headerVoltar,
        avatarSrc ? el('img', {
          class: 'chat-header-avatar',
          src: avatarSrc,
          alt: agente.nome,
        }) : null,
        el('div', { class: 'chat-titulo' }, [
          agente.nome,
          el('div', { class: 'chat-titulo-sub' }, agente.modelo || ''),
        ]),
        btnNovaConversa,
      ].filter(Boolean)),
    );

    // v0.22.7 — OPÇÃO C: chat abre LIMPO. Histórico vai pra `_historicoAntigo` (não no DOM principal).
    // Header expansível mostra "💬 N conversas anteriores · ver" — sócio clica e expande inline.
    // Agente continua usando histórico INTERNO (a memória conversacional do agente-executar
    // já lê de pinguim.conversas no backend — independente do que a UI mostra).
    if (!continuarConversa && !conversaAtual?._conversaLimpa) {
      carregarHistoricoDoBanco(agente).then(historico => {
        if (historico && historico.length > 0 && conversaAtual?.agente?.slug === agente.slug) {
          conversaAtual._historicoAntigo = historico;
          conversaAtual._historicoVisivel = false; // colapsado por padrão
          renderBolhas();
        }
      }).catch(e => console.warn('[carregarHistorico] falhou:', e?.message));
    }
    if (conversaAtual?._conversaLimpa) delete conversaAtual._conversaLimpa;

  const msgsBox = el('div', { class: 'chat-mensagens', id: 'chat-msgs' });
  conteudo.append(msgsBox);

  // Event delegation: clique em link-agente -> abre chat com agente especialista
  msgsBox.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('.link-agente');
    if (!btn) return;
    const slug = btn.getAttribute('data-agente-slug');
    if (!slug) return;
    // Busca o agente na lista cacheada
    const ag = (agentesCache || []).find(a => a.slug === slug);
    if (!ag) {
      alert('Agente "' + slug + '" não encontrado na lista.');
      return;
    }
    // Anexa squad_slug pro avatar do header
    const sq = (squadsCache || []).find(s => s.id === ag.squad_id);
    ag._squad_slug = sq?.slug || null;
    conversaAtual = null;
    renderChat(ag);
  });

  function renderBolhas() {
    msgsBox.innerHTML = '';

    // v0.22.7 — header expansível de histórico antigo (Opção C)
    const histAntigo = conversaAtual._historicoAntigo;
    if (Array.isArray(histAntigo) && histAntigo.length > 0) {
      const expandido = conversaAtual._historicoVisivel === true;
      const cabecalho = el('button', {
        class: 'chat-historico-toggle',
        type: 'button',
        title: expandido ? 'Recolher conversas anteriores' : 'Ver conversas anteriores',
      }, expandido
        ? `▼ ${histAntigo.length} mensagens anteriores — clique pra recolher`
        : `💬 ${histAntigo.length} conversas anteriores · clique pra ver`);
      cabecalho.addEventListener('click', () => {
        conversaAtual._historicoVisivel = !expandido;
        renderBolhas();
      });
      msgsBox.append(cabecalho);

      if (expandido) {
        // Renderiza mensagens antigas com opacity reduzida
        histAntigo.forEach(m => {
          const corpo = m.papel === 'agente' ? markdownPraHtml(m.texto) : escapar(m.texto);
          const bolha = el('div', {
            class: 'bolha bolha-historico ' + (m.papel === 'usuario' ? 'bolha-usuario' : 'bolha-agente'),
            html: corpo,
          });
          if (m.em) {
            const d = new Date(m.em);
            const label = d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
            bolha.append(el('div', { class: 'bolha-timestamp' }, label));
          }
          msgsBox.append(bolha);
        });
        msgsBox.append(el('div', { class: 'chat-historico-separador' }, '── conversa atual ──'));
      }
    }

    if (conversaAtual.mensagens.length === 0) {
      msgsBox.append(el('div', {
        class: 'bolha bolha-agente',
        html: `<p><strong>${escapar(agente.nome)}</strong> pronto.</p><p style="color:var(--fg-muted)">${escapar(agente.missao || agente.proposito || 'Manda o briefing.')}</p>`,
      }));
    }
    conversaAtual.mensagens.forEach(m => {
      const corpo = m.papel === 'agente' ? markdownPraHtml(m.texto) : escapar(m.texto);
      const bolha = el('div', {
        class: 'bolha ' + (m.papel === 'usuario' ? 'bolha-usuario' : 'bolha-agente'),
        html: corpo,
      });
      // v0.22.6: timestamp da mensagem — ajuda distinguir histórico antigo vs nova msg
      if (m.em) {
        const d = new Date(m.em);
        const hoje = new Date();
        const ehHoje = d.toDateString() === hoje.toDateString();
        const ontem = new Date(hoje.getTime() - 86400000);
        const ehOntem = d.toDateString() === ontem.toDateString();
        let label;
        if (ehHoje) label = `Hoje ${d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
        else if (ehOntem) label = `Ontem ${d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
        else label = d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
        bolha.append(el('div', { class: 'bolha-timestamp' }, label));
      }
      // Liga botoes de copiar texto dentro de cards
      bolha.querySelectorAll('.card-prova-btn[data-acao="copiar-texto"]').forEach(btn => {
        btn.addEventListener('click', () => {
          const alvoId = btn.getAttribute('data-alvo');
          const alvo = bolha.querySelector('#' + alvoId);
          if (!alvo) return;
          const textoLimpo = (alvo.innerText || alvo.textContent || '').trim();
          navigator.clipboard.writeText(textoLimpo).then(() => {
            const txtOriginal = btn.textContent;
            btn.textContent = '✓ Copiado';
            btn.classList.add('copiado');
            setTimeout(() => { btn.textContent = txtOriginal; btn.classList.remove('copiado'); }, 1500);
          });
        });
      });
      if (m.meta) {
        bolha.append(el('div', { class: 'bolha-meta' }, m.meta));
      }
      if (m.papel === 'agente') {
        // Pega a pergunta anterior (último 'usuario' antes desta bolha) pra audit
        const idx = conversaAtual.mensagens.indexOf(m);
        const perguntaAnterior = (() => {
          for (let i = idx - 1; i >= 0; i--) {
            if (conversaAtual.mensagens[i].papel === 'usuario') return conversaAtual.mensagens[i].texto;
          }
          return '';
        })();

        const btnCopiar = el('button', { class: 'bolha-acao', type: 'button' }, 'Copiar');
        btnCopiar.addEventListener('click', () => {
          navigator.clipboard.writeText(m.texto).then(() => {
            btnCopiar.textContent = 'Copiado!';
            setTimeout(() => btnCopiar.textContent = 'Copiar', 1500);
          });
        });

        const btnUp = el('button', { class: 'bolha-acao bolha-acao-feedback', type: 'button', title: 'Resposta boa — registra reforço positivo' }, '👍');
        const btnDown = el('button', { class: 'bolha-acao bolha-acao-feedback', type: 'button', title: 'Resposta ruim — abre correção' }, '👎');

        if (m.feedback === 'positivo') { btnUp.classList.add('feedback-ativo'); btnUp.textContent = '👍 enviado'; btnDown.disabled = true; btnUp.disabled = true; }
        if (m.feedback === 'negativo') { btnDown.classList.add('feedback-ativo'); btnDown.textContent = '👎 enviado'; btnUp.disabled = true; btnDown.disabled = true; }

        btnUp.addEventListener('click', async () => {
          btnUp.disabled = true; btnDown.disabled = true; btnUp.textContent = '...';
          const r = await enviarFeedback({ agente_slug: agente.slug, tipo: 'positivo', pergunta_usuario: perguntaAnterior, resposta_agente: m.texto });
          if (r.ok) { m.feedback = 'positivo'; btnUp.textContent = '👍 enviado'; btnUp.classList.add('feedback-ativo'); }
          else {
            btnUp.textContent = '👍'; btnUp.disabled = false; btnDown.disabled = false;
            await mostrarAlerta({ titulo: 'Não consegui registrar', mensagem: r.erro || 'falha desconhecida', tipo: 'erro' });
          }
        });

        btnDown.addEventListener('click', () => {
          abrirModalCorrecao({
            agente,
            pergunta: perguntaAnterior,
            resposta: m.texto,
            onEnviado: () => { m.feedback = 'negativo'; renderBolhas(); },
          });
        });

        const acoesArr = [btnCopiar, btnUp, btnDown];

        // Botao "Tentar de novo" quando bolha eh erro transitorio
        if (m._erroTransitorio && m._mensagemOriginal) {
          const btnRetry = el('button', { class: 'bolha-acao bolha-acao-retry', type: 'button', title: 'Tentar de novo' }, '🔄 Tentar de novo');
          btnRetry.addEventListener('click', async () => {
            btnRetry.disabled = true; btnRetry.textContent = 'Tentando...';
            // Remove a bolha de erro e re-dispara
            const idx = conversaAtual.mensagens.indexOf(m);
            if (idx > -1) conversaAtual.mensagens.splice(idx, 1);
            renderBolhas();
            // Re-envia
            textarea.value = m._mensagemOriginal;
            if (m._anexoOriginal) anexoPendente = m._anexoOriginal;
            enviar();
          });
          acoesArr.push(btnRetry);
        }

        const acoes = el('div', { class: 'bolha-acoes' }, acoesArr);
        bolha.append(acoes);
      }
      msgsBox.append(bolha);
    });
    msgsBox.scrollIntoView({ block: 'end' });
  }

  renderBolhas();

  // Input
  const textarea = el('textarea', {
    class: 'chat-input-textarea',
    placeholder: textoPendente ? 'Diga o que quer fazer com esse texto... (ex: revisar, encurtar, mudar tom)' : 'Sua mensagem... (Ctrl+V cola imagem)',
  });
  const botaoEnviar = el('button', { class: 'chat-enviar', type: 'button' }, 'Enviar');
  const info = el('div', { class: 'chat-input-info' }, '');

  // Anexos pendentes (imagem ou texto colado)
  let anexoPendente = null; // { tipo: 'imagem'|'texto', data, nome? }
  const anexoPreview = el('div', { class: 'anexo-preview', style: 'display:none' });

  function atualizarAnexoPreview() {
    anexoPreview.innerHTML = '';
    if (!anexoPendente) {
      anexoPreview.style.display = 'none';
      return;
    }
    anexoPreview.style.display = 'flex';
    if (anexoPendente.tipo === 'imagem') {
      anexoPreview.append(
        el('img', { src: anexoPendente.data, class: 'anexo-thumb' }),
        el('span', {}, '📎 imagem anexada'),
      );
    } else if (anexoPendente.tipo === 'texto') {
      anexoPreview.append(
        el('span', {}, `📄 ${anexoPendente.nome || 'texto.txt'} (${(anexoPendente.data || '').length} chars)`),
      );
    }
    const btnRemover = el('button', { class: 'anexo-remover', type: 'button' }, '×');
    btnRemover.addEventListener('click', () => { anexoPendente = null; atualizarAnexoPreview(); });
    anexoPreview.append(btnRemover);
  }

  // Botão microfone (Whisper) com feedback visual em tempo real
  let gravando = false;
  let mediaRecorder = null;
  let audioChunks = [];
  let analyserRaf = null;
  let audioContext = null;
  let gravacaoInicio = 0;
  let timerInterval = null;

  const botaoMic = el('button', { class: 'chat-acao-icone', type: 'button', title: 'Gravar áudio (Whisper)' }, '🎤');

  // Painel de gravação ao vivo (aparece só durante gravação)
  const painelGravacao = el('div', { class: 'painel-gravacao', style: 'display:none' });
  const tempoEl = el('span', { class: 'painel-gravacao-tempo' }, '0:00');
  const barrasContainer = el('div', { class: 'painel-gravacao-barras' });
  // 8 LEDs verticais que sobem/descem com o volume
  const barras = [];
  for (let i = 0; i < 12; i++) {
    const b = el('div', { class: 'painel-gravacao-led' });
    barras.push(b);
    barrasContainer.appendChild(b);
  }
  const btnPararGravacao = el('button', { class: 'painel-gravacao-parar', type: 'button', title: 'Parar e transcrever' }, '⏹ Parar');
  painelGravacao.append(
    el('span', { class: 'painel-gravacao-rec' }, '● REC'),
    tempoEl,
    barrasContainer,
    btnPararGravacao,
  );

  function formatarTempo(seg) {
    const m = Math.floor(seg / 60);
    const s = seg % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  function ativarVisualizadorAudio(stream) {
    try {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 64; // pouco detalhe, alta performance
      source.connect(analyser);
      const buffer = new Uint8Array(analyser.frequencyBinCount);

      function tick() {
        analyser.getByteFrequencyData(buffer);
        // Pega energia média em 12 bandas
        const bandasPorBarra = Math.floor(buffer.length / 12);
        for (let i = 0; i < 12; i++) {
          let soma = 0;
          for (let j = 0; j < bandasPorBarra; j++) {
            soma += buffer[i * bandasPorBarra + j];
          }
          const media = soma / bandasPorBarra; // 0-255
          const altura = Math.max(8, Math.min(28, Math.round((media / 255) * 28)));
          barras[i].style.height = altura + 'px';
          // Cor varia: baixo=verde, médio=laranja, alto=vermelho
          if (media > 180) barras[i].style.background = '#EF4444';
          else if (media > 100) barras[i].style.background = '#FFB800';
          else barras[i].style.background = '#22C55E';
        }
        analyserRaf = requestAnimationFrame(tick);
      }
      tick();
    } catch (e) {
      console.warn('[mic] visualizador falhou:', e.message);
    }
  }

  function pararVisualizador() {
    if (analyserRaf) {
      cancelAnimationFrame(analyserRaf);
      analyserRaf = null;
    }
    if (audioContext) {
      try { audioContext.close(); } catch (_) {}
      audioContext = null;
    }
    // Zera as barras
    barras.forEach(b => {
      b.style.height = '8px';
      b.style.background = '#444';
    });
  }

  async function iniciarGravacao() {
    if (gravando) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      audioChunks = [];
      mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunks.push(e.data); };
      mediaRecorder.onstop = async () => {
        gravando = false;
        pararVisualizador();
        clearInterval(timerInterval);
        painelGravacao.style.display = 'none';
        botaoMic.textContent = '🎤';
        botaoMic.classList.remove('gravando');
        stream.getTracks().forEach(t => t.stop());
        if (audioChunks.length === 0) return;
        botaoMic.textContent = '⏳';
        botaoMic.disabled = true;
        try {
          const blob = new Blob(audioChunks, { type: 'audio/webm' });
          const texto = await transcreverAudio(blob);
          if (texto) {
            textarea.value = (textarea.value ? textarea.value + ' ' : '') + texto;
            textarea.focus();
          }
        } catch (e) {
          alert('Falha ao transcrever: ' + e.message);
        } finally {
          botaoMic.textContent = '🎤';
          botaoMic.disabled = false;
        }
      };

      mediaRecorder.start();
      gravando = true;
      gravacaoInicio = Date.now();
      painelGravacao.style.display = 'flex';
      botaoMic.textContent = '⏹';
      botaoMic.classList.add('gravando');
      ativarVisualizadorAudio(stream);
      timerInterval = setInterval(() => {
        const seg = Math.floor((Date.now() - gravacaoInicio) / 1000);
        tempoEl.textContent = formatarTempo(seg);
      }, 250);
    } catch (e) {
      const msg = (e.message || '').toLowerCase();
      if (msg.includes('denied') || msg.includes('not allowed')) {
        alert(
          'Microfone bloqueado pelo Chrome.\n\n' +
          'Pra liberar:\n' +
          '1. Clica no ícone de cadeado na barra de URL (à esquerda do endereço)\n' +
          '2. Em "Permissões do site" → procura "Microfone"\n' +
          '3. Muda pra "Permitir"\n' +
          '4. Recarrega a página e tenta de novo'
        );
      } else if (msg.includes('found')) {
        alert('Nenhum microfone detectado no seu computador.');
      } else {
        alert('Erro ao acessar microfone: ' + e.message);
      }
    }
  }

  function pararGravacao() {
    if (gravando && mediaRecorder?.state !== 'inactive') {
      mediaRecorder.stop();
    }
  }

  botaoMic.addEventListener('click', () => {
    if (gravando) pararGravacao();
    else iniciarGravacao();
  });
  btnPararGravacao.addEventListener('click', pararGravacao);

  // Botão upload txt
  const inputFile = el('input', { type: 'file', accept: '.txt,.md', style: 'display:none' });
  const botaoTxt = el('button', { class: 'chat-acao-icone', type: 'button', title: 'Anexar arquivo de texto' }, '📎');
  botaoTxt.addEventListener('click', () => inputFile.click());
  inputFile.addEventListener('change', async (ev) => {
    const f = ev.target.files?.[0];
    if (!f) return;
    if (f.size > 200 * 1024) { alert('Arquivo > 200KB. Resume o conteúdo e cola direto.'); return; }
    const texto = await f.text();
    anexoPendente = { tipo: 'texto', data: texto, nome: f.name };
    atualizarAnexoPreview();
    inputFile.value = '';
  });

  // Comprime imagem em base64 reduzindo dimensoes pra max 1600px no maior lado
  // (Vision aceita ate 2048x2048 com qualidade alta — 1600 fica leve sem perder qualidade)
  async function comprimirImagemDataURI(dataURI, maxLado = 1600) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const ratio = Math.max(img.width, img.height) / maxLado;
        const w = ratio > 1 ? Math.round(img.width / ratio) : img.width;
        const h = ratio > 1 ? Math.round(img.height / ratio) : img.height;
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        // JPEG 0.85 = boa qualidade, ~4-10x menor que PNG
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = reject;
      img.src = dataURI;
    });
  }

  // Paste image (Ctrl+V) -> anexo
  textarea.addEventListener('paste', (ev) => {
    const items = ev.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        ev.preventDefault();
        const blob = item.getAsFile();
        if (!blob) return;
        const reader = new FileReader();
        reader.onload = async () => {
          try {
            const comprimido = await comprimirImagemDataURI(reader.result);
            anexoPendente = { tipo: 'imagem', data: comprimido };
            atualizarAnexoPreview();
          } catch (e) {
            alert('Falha ao processar imagem: ' + e.message);
          }
        };
        reader.readAsDataURL(blob);
        return;
      }
    }
  });

  // Drag-and-drop de arquivo de imagem
  const dropZone = document.body;
  let dragCount = 0;
  function highlightDrop(on) {
    if (on) document.body.classList.add('arrastando-arquivo');
    else document.body.classList.remove('arrastando-arquivo');
  }
  dropZone.addEventListener('dragenter', (ev) => {
    ev.preventDefault();
    dragCount++;
    highlightDrop(true);
  });
  dropZone.addEventListener('dragleave', (ev) => {
    ev.preventDefault();
    dragCount--;
    if (dragCount <= 0) { dragCount = 0; highlightDrop(false); }
  });
  dropZone.addEventListener('dragover', (ev) => {
    ev.preventDefault();
    ev.dataTransfer.dropEffect = 'copy';
  });
  dropZone.addEventListener('drop', (ev) => {
    ev.preventDefault();
    dragCount = 0;
    highlightDrop(false);
    const file = ev.dataTransfer?.files?.[0];
    if (!file) return;
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const comprimido = await comprimirImagemDataURI(reader.result);
          anexoPendente = { tipo: 'imagem', data: comprimido };
          atualizarAnexoPreview();
        } catch (e) {
          alert('Falha ao processar imagem: ' + e.message);
        }
      };
      reader.readAsDataURL(file);
    } else if (file.type.startsWith('text/') || /\.(txt|md)$/i.test(file.name)) {
      if (file.size > 200 * 1024) {
        alert('Arquivo > 200KB. Resume o conteudo e cola direto.');
        return;
      }
      file.text().then(txt => {
        anexoPendente = { tipo: 'texto', data: txt, nome: file.name };
        atualizarAnexoPreview();
      });
    } else {
      alert('So aceito imagem ou texto. Arquivo: ' + file.type);
    }
  });

  // Se tem texto do context menu, pre-preenche
  if (textoPendente) {
    textarea.value = `Trabalhe esse texto:\n\n"""\n${textoPendente}\n"""\n\nO que fazer: `;
    setTimeout(() => textarea.focus(), 50);
    textoPendente = null; // consome
    storageRemove(['textoPendente', 'textoPendenteOrigem', 'textoPendenteEm']);
  }

  async function enviar() {
    let msg = textarea.value.trim();
    if (!msg && !anexoPendente) return;

    // Compõe mensagem com anexos
    if (anexoPendente?.tipo === 'texto') {
      msg = `${msg}\n\n---\nArquivo anexado (${anexoPendente.nome}):\n"""\n${anexoPendente.data}\n"""`;
    } else if (anexoPendente?.tipo === 'imagem') {
      // Briefing claro: usuario anexou imagem. Agente deve invocar tool com so a instrucao;
      // sistema injeta a imagem automaticamente do contexto_extra.imagem_data_uri.
      if (!msg) msg = 'Analisa essa imagem.';
      msg = `${msg}\n\n(Imagem anexada — chame a ferramenta analisar_imagem passando so a instrucao, o sistema injeta a imagem.)`;
    }
    if (!msg) return;
    botaoEnviar.disabled = true;
    botaoEnviar.textContent = 'Enviando...';
    info.textContent = '';

    conversaAtual.mensagens.push({ papel: 'usuario', texto: msg, em: Date.now() });
    textarea.value = '';
    renderBolhas();

    // Loading bubble
    const loading = el('div', { class: 'bolha bolha-agente' }, [
      el('div', { class: 'carregando' }, [
        el('span', { class: 'carregando-dot' }),
        el('span', { class: 'carregando-dot' }),
        el('span', { class: 'carregando-dot' }),
        ' Pensando...',
      ]),
    ]);
    msgsBox.append(loading);
    loading.scrollIntoView({ block: 'end' });

    // Salva e limpa anexo
    const anexoPraEnviar = anexoPendente;
    anexoPendente = null;
    atualizarAnexoPreview();

    try {
      const resp = await conversarComAgente(agente.slug, msg, anexoPraEnviar);
      loading.remove();
      const texto = resp.conteudo_md
        || (resp.conteudo_estruturado ? JSON.stringify(resp.conteudo_estruturado, null, 2) : '')
        || resp.titulo
        || '(resposta vazia)';
      const meta = resp.uso
        ? `${resp.uso.modelo || ''} · ${resp.uso.latencia_ms || 0}ms · $${(resp.uso.custo_usd || 0).toFixed(4)}`
        : '';
      conversaAtual.mensagens.push({ papel: 'agente', texto, meta, em: Date.now() });
      renderBolhas();
    } catch (e) {
      loading.remove();
      // Detecta erro transitorio (5xx, 429, timeout) pra mostrar UX amigavel + botao tentar de novo
      const erroTxt = String(e.message || 'falha desconhecida');
      const ehTransitorio = /5\d\d|429|timeout|server_error|temporario|muita demanda|overloaded/i.test(erroTxt);
      conversaAtual.mensagens.push({
        papel: 'agente',
        texto: ehTransitorio
          ? `⚠️ A OpenAI deu erro temporário agora. Geralmente passa em poucos segundos.`
          : `⚠️ Algo deu errado: ${erroTxt}`,
        em: Date.now(),
        _erroTransitorio: ehTransitorio,
        _mensagemOriginal: msg, // pra botao tentar de novo
        _anexoOriginal: anexoPraEnviar,
      });
      renderBolhas();
    } finally {
      botaoEnviar.disabled = false;
      botaoEnviar.textContent = 'Enviar';
    }
  }

  botaoEnviar.addEventListener('click', enviar);
  textarea.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      enviar();
    }
  });

  conteudo.append(
    el('div', { class: 'chat-input-box' }, [
      painelGravacao,
      anexoPreview,
      textarea,
      el('div', { class: 'chat-input-acoes' }, [
        botaoMic,
        botaoTxt,
        inputFile,
        // v0.22.4: botao Voltar no rodape (evita rolar pra cima pra usar o ← do header)
        (() => {
          const btn = el('button', {
            type: 'button',
            class: 'chat-input-info',
            style: 'background:transparent;border:1px solid var(--cor-borda-forte);color:var(--cor-texto-2);padding:4px 10px;border-radius:var(--raio-2);cursor:pointer;font-size:11px;margin-left:auto',
            title: 'Voltar pro catálogo de agentes',
          }, '← Voltar');
          btn.addEventListener('click', () => {
            conversaAtual = null;
            renderCategoriaAtual();
          });
          return btn;
        })(),
        el('span', { class: 'chat-input-info', style: 'margin-right:8px' }, 'Ctrl+Enter envia'),
        botaoEnviar,
      ]),
    ])
  );

  // Auto-envio se veio com perguntaInicial (auto-route da home)
  if (perguntaInicial && perguntaInicial.trim() && !continuarConversa) {
    setTimeout(() => {
      textarea.value = perguntaInicial.trim();
      enviar();
    }, 100);
  }
  } catch (erro) {
    console.error('[renderChat] erro fatal:', erro);
    conteudo.innerHTML = '';
    conteudo.append(el('div', { class: 'alerta-erro', style: 'margin:20px' },
      'Erro ao abrir chat: ' + (erro?.message || 'desconhecido') + '. Clica em ↻ pra recarregar.'));
  }
}

// ============== UTILS ==============
function escapar(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// Markdown leve (paragrafos, negrito, italico, codigo, listas, headers, IMAGEM, LINK, CARD)
function markdownPraHtml(md) {
  if (!md) return '';

  // 1. Primeiro, extrai BLOCOS DE CARD (formato: <CARD>...</CARD>) e substitui por placeholders
  // antes do escapar(), pra preservar HTML estruturado dos cards.
  const cards = [];
  let semCards = String(md).replace(/<CARD[^>]*>[\s\S]*?<\/CARD>/g, (bloco) => {
    cards.push(bloco);
    return `__CARD_PLACEHOLDER_${cards.length - 1}__`;
  });

  let h = escapar(semCards);

  // 2. Markdown image: ![alt](url) -> <img>
  h = h.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g,
    (_, alt, url) => `<img class="md-img" alt="${alt}" src="${url}" loading="lazy">`);
  // Code blocks
  h = h.replace(/```([\s\S]*?)```/g, (m, code) => `<pre>${code.trim()}</pre>`);
  // Inline code
  h = h.replace(/`([^`]+)`/g, '<code>$1</code>');
  // Headers
  h = h.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  h = h.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  h = h.replace(/^# (.+)$/gm, '<h1>$1</h1>');
  // Bold + italic
  h = h.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
  h = h.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
  // Link especial pra abrir agente: [texto](agente:slug) → botao clicavel
  h = h.replace(/\[([^\]]+)\]\(agente:([a-z0-9-]+)\)/g,
    (_, texto, slug) => `<button class="link-agente" data-agente-slug="${slug}">${texto} →</button>`);
  // Link normal: [texto](url) -> <a target="_blank">
  h = h.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
    (_, texto, url) => `<a href="${url}" target="_blank" rel="noopener">${texto}</a>`);
  // Listas
  h = h.replace(/^(?:[-*] .+(?:\n|$))+/gm, (m) => {
    const items = m.trim().split('\n').map(l => `<li>${l.replace(/^[-*] /, '')}</li>`).join('');
    return `<ul>${items}</ul>`;
  });
  // Numeradas
  h = h.replace(/^(?:\d+\. .+(?:\n|$))+/gm, (m) => {
    const items = m.trim().split('\n').map(l => `<li>${l.replace(/^\d+\. /, '')}</li>`).join('');
    return `<ol>${items}</ol>`;
  });
  // Paragrafos — pula tags de bloco (incluindo placeholders de card)
  const blocos = h.split(/\n{2,}/).map(b => {
    if (/^<(ul|ol|pre|h\d|blockquote|img|div|__CARD)/.test(b.trim())) return b;
    if (/^__CARD_PLACEHOLDER_\d+__$/.test(b.trim())) return b;
    if (!b.trim()) return '';
    return '<p>' + b.replace(/\n/g, '<br>') + '</p>';
  }).join('\n');

  // 3. Substitui placeholders pelos cards REAIS (HTML cru) e processa atributos
  let final = blocos.replace(/__CARD_PLACEHOLDER_(\d+)__/g, (_, idx) => {
    return renderizarCard(cards[parseInt(idx, 10)]);
  });

  return final;
}

// Renderiza 1 <CARD> em HTML estruturado.
// Formato esperado:
//   <CARD>
//     <THUMB src="..." alt="..."/>     (opcional — thumbnail no topo)
//     <TITULO>...</TITULO>             (linha de titulo)
//     <SUB>...</SUB>                   (subtitulo / categoria)
//     <TEXTO>...</TEXTO>               (texto principal, com botao copiar)
//     <META>...</META>                 (rodape: data, link, etc)
//   </CARD>
function renderizarCard(blocoCard) {
  function pegar(tag) {
    const m = blocoCard.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i'));
    return m ? m[1].trim() : '';
  }
  function pegarAttr(tag, attr) {
    const m = blocoCard.match(new RegExp(`<${tag}[^>]*${attr}\\s*=\\s*"([^"]*)"`, 'i'));
    return m ? m[1] : '';
  }

  // Extrai partes
  const thumbSrc = pegarAttr('THUMB', 'src');
  const thumbAlt = pegarAttr('THUMB', 'alt') || 'Imagem';
  const titulo = pegar('TITULO');
  const sub = pegar('SUB');
  const texto = pegar('TEXTO');
  const meta = pegar('META');

  // ID unico pra botoes saberem qual texto/img copiar
  const cardId = 'card_' + Math.random().toString(36).slice(2, 9);

  // Sanitiza texto interno (escapa, mantem quebras como <br>)
  const tituloHtml = escapar(titulo).replace(/\n/g, '<br>');
  const subHtml = escapar(sub);
  const textoHtml = escapar(texto).replace(/\n/g, '<br>');
  const metaHtml = escapar(meta).replace(/\n/g, '<br>');

  let html = `<div class="card-prova" data-card-id="${cardId}">`;

  if (thumbSrc) {
    html += `<a class="card-prova-thumb-wrap" href="${thumbSrc}" target="_blank" rel="noopener" title="Abrir imagem em tamanho real">
      <img class="card-prova-thumb" src="${thumbSrc}" alt="${escapar(thumbAlt)}" loading="lazy" data-img-url="${thumbSrc}">
    </a>`;
  }

  if (titulo || sub) {
    html += `<div class="card-prova-cabecalho">`;
    if (titulo) html += `<div class="card-prova-titulo">${tituloHtml}</div>`;
    if (sub) html += `<div class="card-prova-sub">${subHtml}</div>`;
    html += `</div>`;
  }

  // Bloco do TEXTO (so quando o card eh detalhado — modo "abrir uma especifica")
  if (texto) {
    html += `<div class="card-prova-texto" id="${cardId}_txt">${textoHtml}</div>`;
  }

  // Acoes — SEMPRE aparecem (em LISTA e em DETALHE):
  //   - "Copiar tudo" copia: titulo + sub + (texto se houver) + meta
  //   - "Baixar imagem" so se tem thumb
  // Hidden id com conteudo "copiavel" do card pra clipboard
  const conteudoCopiavel = [titulo, sub, texto, meta].filter(Boolean).join('\n');
  html += `<div class="card-prova-conteudo-copia" id="${cardId}_full" style="display:none">${escapar(conteudoCopiavel)}</div>`;
  html += `<div class="card-prova-acoes">
    <button class="card-prova-btn" type="button" data-acao="copiar-texto" data-alvo="${cardId}_full" title="Copiar nome + descricao + link">📋 Copiar</button>`;
  if (thumbSrc) {
    html += `<a class="card-prova-btn" href="${thumbSrc}" download target="_blank" rel="noopener" title="Baixar print">🖼 Baixar imagem</a>`;
  }
  html += `</div>`;

  if (meta) {
    let metaFinal = metaHtml.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
      (_, t, u) => `<a href="${u}" target="_blank" rel="noopener">${t}</a>`);
    html += `<div class="card-prova-meta">${metaFinal}</div>`;
  }

  html += `</div>`;
  return html;
}

// ============== EVENTOS TOPO ==============
btnFechar.addEventListener('click', () => {
  window.parent.postMessage({ pinguimTipo: 'FECHAR_SIDEBAR' }, '*');
});

// v0.13.1: abrirAnalisarTela eh chamado direto pelo irPara('tela') a partir do nav lateral

async function lerTelaAtiva() {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ tipo: 'LER_TELA_ATIVA' }, (resp) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (!resp) return reject(new Error('Service worker nao respondeu'));
      if (!resp.ok) return reject(new Error(resp.erro || 'erro desconhecido'));
      // v0.14.0: retorna { dados, screenshot? }
      resolve({ dados: resp.dados, screenshot: resp.screenshot || null });
    });
  });
}

async function abrirAnalisarTela() {
  if (!session?.access_token) {
    mostrarAlerta({ titulo: 'Sem sessão', mensagem: 'Faz login primeiro pra analisar a tela.', tipo: 'aviso' });
    return;
  }

  // Modal com pergunta + preview do que foi lido
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:560px;max-height:90vh;overflow-y:auto' });
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, '👁 Analisar tela ativa'));

  const infoBox = el('div', { class: 'px-meta', style: 'margin-bottom:12px' }, 'Lendo o que está visível na aba ativa...');
  box.append(infoBox);

  // Preview compacto (carregado depois)
  const previewBox = el('div', { class: 'px-card px-card--sm', style: 'margin-bottom:12px;display:none' });
  box.append(previewBox);

  // v0.18.0: Radio Analisar / Editar — só aparece se é planilha (editor só faz sentido em Sheets)
  const modoSelector = el('div', { id: 'modo-selector', style: 'display:flex;gap:8px;margin-bottom:10px' });
  const radioAnalisar = el('label', {
    class: 'px-row',
    style: 'flex:1;gap:8px;padding:10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer',
  });
  const rAnalisar = el('input', { type: 'radio', name: 'modo-acao', value: 'analisar', checked: true, style: 'margin:0' });
  radioAnalisar.append(rAnalisar);
  radioAnalisar.append(el('div', {}, [
    el('div', { style: 'font-size:13px;font-weight:500' }, '🔍 Analisar'),
    el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Lê os dados, responde perguntas'),
  ]));

  const radioEditar = el('label', {
    class: 'px-row',
    style: 'flex:1;gap:8px;padding:10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer',
  });
  const rEditar = el('input', { type: 'radio', name: 'modo-acao', value: 'editar', style: 'margin:0' });
  radioEditar.append(rEditar);
  radioEditar.append(el('div', {}, [
    el('div', { style: 'font-size:13px;font-weight:500' }, '✏ Editar'),
    el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Modifica a planilha (escrever/adicionar/deletar)'),
  ]));

  // v0.19.1: terceira opção — Clonar página (substitui Editar quando NÃO é planilha)
  const radioClonar = el('label', {
    class: 'px-row',
    style: 'flex:1;gap:8px;padding:10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer;display:none',
  });
  const rClonar = el('input', { type: 'radio', name: 'modo-acao', value: 'clonar', style: 'margin:0' });
  radioClonar.append(rClonar);
  radioClonar.append(el('div', {}, [
    el('div', { style: 'font-size:13px;font-weight:500' }, '📄 Clonar página'),
    el('div', { class: 'px-meta', style: 'font-size:11px' }, 'HTML + briefing 12 blocos + sugestões'),
  ]));

  // v0.21.0: quarta opção — Baixar reel (só aparece se URL eh TikTok/Instagram)
  const radioReel = el('label', {
    class: 'px-row',
    style: 'flex:1;gap:8px;padding:10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer;display:none',
  });
  const rReel = el('input', { type: 'radio', name: 'modo-acao', value: 'reel', style: 'margin:0' });
  radioReel.append(rReel);
  radioReel.append(el('div', {}, [
    el('div', { style: 'font-size:13px;font-weight:500' }, '🎬 Baixar reel'),
    el('div', { class: 'px-meta', style: 'font-size:11px' }, 'MP4 + transcript + métricas + autor'),
  ]));

  // v0.22.0: quinta opção — Transcrever YouTube (só aparece se URL eh youtube.com / youtu.be)
  const radioYt = el('label', {
    class: 'px-row',
    style: 'flex:1;gap:8px;padding:10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer;display:none',
  });
  const rYt = el('input', { type: 'radio', name: 'modo-acao', value: 'youtube', style: 'margin:0' });
  radioYt.append(rYt);
  radioYt.append(el('div', {}, [
    el('div', { style: 'font-size:13px;font-weight:500' }, '📺 Transcrever YouTube'),
    el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Transcript + top 200 comentários + métricas'),
  ]));

  // v0.24 — opção WhatsApp Web: Buscar conversas (palavra livre + perfis prontos + filtro tempo)
  const radioWhatsappBuscar = el('label', {
    class: 'px-row',
    style: 'flex:1;gap:8px;padding:10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer;display:none',
  });
  const rWhatsappBuscar = el('input', { type: 'radio', name: 'modo-acao', value: 'whatsapp-buscar', style: 'margin:0' });
  radioWhatsappBuscar.append(rWhatsappBuscar);
  radioWhatsappBuscar.append(el('div', {}, [
    el('div', { style: 'font-size:13px;font-weight:500' }, '🔍 Buscar conversas no WhatsApp'),
    el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Varre o painel inteiro por palavra (pagamento, urgente, reclamação...) + filtro de tempo'),
  ]));

  modoSelector.append(radioAnalisar, radioEditar, radioClonar, radioReel, radioYt, radioWhatsappBuscar);
  modoSelector.style.flexWrap = 'wrap';
  // Anexa logo ANTES do textarea
  box.append(modoSelector);

  const labelPergunta = el('div', { class: 'px-rotulo', style: 'margin-bottom:6px' }, 'O que você quer saber sobre esta tela?');
  box.append(labelPergunta);
  const inputPergunta = el('textarea', {
    class: 'px-textarea',
    placeholder: 'Ex: resume essa thread · que produtos aparecem nessa tabela · quais campos faltam preencher',
    rows: 3,
  });
  inputPergunta.disabled = true;
  box.append(inputPergunta);

  // v0.17.0: toggle modo CEO (resposta estruturada com KPIs + secoes)
  const toggleModo = el('label', {
    class: 'px-row',
    style: 'gap:8px;margin-top:10px;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer',
  });
  const checkModo = el('input', { type: 'checkbox', style: 'margin:0;cursor:pointer' });
  toggleModo.append(checkModo);
  toggleModo.append(el('div', { style: 'flex:1' }, [
    el('div', { style: 'font-size:13px;font-weight:500' }, '🎩 Modo CEO (resposta estruturada)'),
    el('div', { class: 'px-meta' }, 'KPIs em cards visuais + seções (Achados · Provocação · Ações). Use pra perguntas abertas tipo "tira insight" / "analisa".'),
  ]));
  box.append(toggleModo);

  // Atualiza placeholder + visibilidade do CEO toggle conforme modo
  function atualizarUiPorModo() {
    const ehEdicao = rEditar.checked;
    const ehClonar = rClonar.checked;
    const ehReel = rReel.checked;
    const ehYt = rYt.checked;
    const ehWaBuscar = rWhatsappBuscar.checked;

    // Modo CEO faz sentido só em planilha
    const podeMostrarCEO = (modoAnalise === 'planilha');

    if (ehClonar) {
      inputPergunta.placeholder = 'Clonando: HTML + briefing 12 blocos + sugestões. Sem pergunta necessária.';
      inputPergunta.value = '';
      inputPergunta.disabled = true;
      toggleModo.style.display = 'none';
      btnAnalisar.textContent = '📥 Clonar página';
    } else if (ehReel) {
      inputPergunta.placeholder = 'Baixando reel: MP4 + transcript + métricas. Sem pergunta necessária.';
      inputPergunta.value = '';
      inputPergunta.disabled = true;
      toggleModo.style.display = 'none';
      btnAnalisar.textContent = '🎬 Baixar reel';
    } else if (ehYt) {
      inputPergunta.placeholder = 'Transcrevendo: legendas + top 200 comentários + métricas. Sem pergunta necessária.';
      inputPergunta.value = '';
      inputPergunta.disabled = true;
      toggleModo.style.display = 'none';
      btnAnalisar.textContent = '📺 Transcrever';
    } else if (ehWaBuscar) {
      // No modo WhatsApp Busca, o input livre + perfis ficam no PRÓXIMO modal.
      // Esconde rótulo e textarea pra não confundir.
      inputPergunta.value = '';
      inputPergunta.style.display = 'none';
      labelPergunta.style.display = 'none';
      toggleModo.style.display = 'none';
      btnAnalisar.textContent = '🔍 Abrir busca';
    } else {
      inputPergunta.disabled = false;
      inputPergunta.style.display = '';
      labelPergunta.style.display = '';
      inputPergunta.placeholder = ehEdicao
        ? 'Ex: preenche os sem Instagram com "nada consta" · adiciona coluna Status no fim · deleta as linhas sem email'
        : 'Ex: resume essa thread · que produtos aparecem nessa tabela · quais campos faltam preencher';
      toggleModo.style.display = (ehEdicao || !podeMostrarCEO) ? 'none' : '';
      btnAnalisar.textContent = ehEdicao ? 'Executar' : 'Analisar';
    }

    radioAnalisar.style.borderColor = (!ehEdicao && !ehClonar && !ehReel && !ehYt && !ehWaBuscar) ? 'var(--cor-acento)' : 'var(--cor-borda)';
    radioEditar.style.borderColor = ehEdicao ? 'var(--cor-acento)' : 'var(--cor-borda)';
    radioClonar.style.borderColor = ehClonar ? 'var(--cor-acento)' : 'var(--cor-borda)';
    radioReel.style.borderColor = ehReel ? 'var(--cor-acento)' : 'var(--cor-borda)';
    radioWhatsappBuscar.style.borderColor = ehWaBuscar ? 'var(--cor-acento)' : 'var(--cor-borda)';
    radioYt.style.borderColor = ehYt ? 'var(--cor-acento)' : 'var(--cor-borda)';
  }
  rAnalisar.addEventListener('change', atualizarUiPorModo);
  rEditar.addEventListener('change', atualizarUiPorModo);
  rClonar.addEventListener('change', atualizarUiPorModo);
  rReel.addEventListener('change', atualizarUiPorModo);
  rYt.addEventListener('change', atualizarUiPorModo);
  rWhatsappBuscar.addEventListener('change', atualizarUiPorModo);
  setTimeout(atualizarUiPorModo, 0);

  const erroBox = el('div', { class: 'alerta-erro', style: 'display:none;margin-top:8px' });
  box.append(erroBox);

  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:flex-end;gap:8px;margin-top:14px' });
  const btnCancelar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Cancelar');
  btnCancelar.addEventListener('click', () => overlay.remove());
  const btnAnalisar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, 'Analisar');
  btnAnalisar.disabled = true;
  acoes.append(btnCancelar, btnAnalisar);
  // v0.18.1: label dinamico do botao conforme modo Analisar vs Editar
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);

  // =====================================================================
  // v0.15.0: PORTEIRO — detecta especialista antes de carregar
  // =====================================================================
  // Estado:
  //   modoAnalise = 'planilha' | 'generico'
  //   dadosTela: DOM + tipo (generico)
  //   screenshotDataUri: imagem (generico — vision)
  //   dadosPlanilha: dados estruturados via Sheets API (planilha)

  let modoAnalise = 'generico';
  let dadosTela = null;
  let screenshotDataUri = null;
  let dadosPlanilha = null;
  let dadosPaginaVenda = null;

  try {
    const res = await lerTelaAtiva();
    dadosTela = res.dados;
    screenshotDataUri = res.screenshot;

    // v0.15.0: PORTEIRO — se URL eh Google Sheets, vai direto pro analista de planilha
    const sheetsMatch = String(dadosTela.url || '').match(/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (sheetsMatch) {
      modoAnalise = 'planilha';
      const spreadsheetId = sheetsMatch[1];
      infoBox.innerHTML = '';
      infoBox.append(el('span', {}, '📊 Planilha Google detectada — lendo dados via Sheets API... '));

      try {
        const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-ler-planilha-google`, {
          method: 'POST',
          headers: {
            apikey: SUPABASE_ANON_KEY,
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ spreadsheet_id: spreadsheetId, max_rows: 500 }),
        });
        if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || 'Sheets API falhou');
        dadosPlanilha = r.body;
        infoBox.innerHTML = '';
        infoBox.append(el('span', {}, `📊 ${dadosPlanilha.total_linhas} linhas × ${dadosPlanilha.total_colunas} colunas `));
        infoBox.append(el('span', { class: 'px-badge', style: 'margin-left:6px' }, 'Analista de Planilha'));
        // v0.22.1 FIX: re-roda atualizarUiPorModo agora que modoAnalise mudou pra 'planilha'
        // (a primeira chamada do setTimeout 0 rodou com modoAnalise='generico' e escondeu o Modo CEO)
        atualizarUiPorModo();
      } catch (eP) {
        // Fallback pra modo generico se Sheets API falhar (planilha privada, sem permissao, etc)
        modoAnalise = 'generico';
        infoBox.innerHTML = '';
        infoBox.append(el('span', { class: 'px-meta', style: 'color:var(--cor-aviso)' },
          `⚠ Sheets API falhou (${eP.message}). Voltando pro modo genérico (visão).`));
        atualizarUiPorModo();
      }
    }

    // Modo generico: usa DOM + screenshot. v0.19.1: NAO detecta página de venda
    // automaticamente — sócio escolhe via radio "Clonar página". Quem clicou já sabe.
    if (modoAnalise === 'generico') {
      if (!infoBox.textContent.includes('⚠')) infoBox.innerHTML = '';
      infoBox.append(el('span', {}, `✓ Li ${Math.round(dadosTela.tamanho_chars/1024)} KB da tela `));
      if (dadosTela.meta?.tipo) infoBox.append(el('span', { class: 'px-badge', style: 'margin-left:6px' }, dadosTela.meta.tipo));
      if (screenshotDataUri) infoBox.append(el('span', { class: 'px-badge', style: 'margin-left:6px' }, '👁 visão'));
      // Habilita opção Clonar página, esconde Editar (faz sentido só pra planilha)
      radioEditar.style.display = 'none';
      radioClonar.style.display = '';
      // v0.21.0: se URL for TikTok ou Instagram, mostra também opção Baixar reel
      const hostUrl = String(dadosTela.url || '').toLowerCase();
      const ehReelUrl = hostUrl.includes('tiktok.com/') || hostUrl.includes('instagram.com/');
      const ehYtUrl = hostUrl.includes('youtube.com/watch') || hostUrl.includes('youtu.be/') || hostUrl.includes('youtube.com/shorts/');
      const ehWhatsappUrl = hostUrl.includes('web.whatsapp.com');
      if (ehReelUrl) {
        radioReel.style.display = '';
        radioClonar.style.display = 'none'; // v0.21.1: clonar pagina nao faz sentido em reel
        rReel.checked = true;
        atualizarUiPorModo();
        infoBox.append(el('span', { class: 'px-badge', style: 'margin-left:6px' }, '🎬 reel detectado'));
      } else if (ehYtUrl) {
        // v0.22.0: URL eh YouTube — mostra radio Transcrever e esconde Clonar página
        radioYt.style.display = '';
        radioClonar.style.display = 'none';
        rYt.checked = true;
        atualizarUiPorModo();
        infoBox.append(el('span', { class: 'px-badge', style: 'margin-left:6px' }, '📺 YouTube detectado'));
      } else if (ehWhatsappUrl) {
        // v0.24 — WhatsApp Web: só Buscar conversas faz sentido. Esconde Analisar + Clonar.
        radioWhatsappBuscar.style.display = '';
        radioAnalisar.style.display = 'none';
        radioClonar.style.display = 'none';
        rWhatsappBuscar.checked = true;
        atualizarUiPorModo();
        infoBox.innerHTML = '';
        infoBox.append(el('span', {}, '💬 WhatsApp Web detectado · '));
        infoBox.append(el('span', { class: 'px-badge' }, '🔍 buscar conversas'));
      }
      // v0.19.1: Modo CEO só faz sentido em planilha — esconde fora dela
      toggleModo.style.display = 'none';
      // Prepara dadosPaginaVenda — só será usado se sócio escolher Clonar
      dadosPaginaVenda = {
        url: dadosTela.url,
        titulo: dadosTela.titulo,
        dominio: dadosTela.dominio,
        html: dadosTela.html_completo || null,
        screenshot: screenshotDataUri,
      };
    }

    // Preview
    previewBox.innerHTML = '';
    previewBox.style.display = 'block';
    previewBox.append(
      el('div', { style: 'font-size:12px;color:var(--cor-texto-2);margin-bottom:4px' },
        `📍 ${dadosTela.dominio} · ${dadosTela.titulo.slice(0, 80)}`),
    );

    if (modoAnalise === 'planilha' && dadosPlanilha) {
      // Preview da planilha: cabecalho + 2 linhas
      const cab = dadosPlanilha.valores?.[0] || [];
      const linhas = dadosPlanilha.valores?.slice(1, 3) || [];
      previewBox.append(el('div', { class: 'px-meta', style: 'margin-top:4px' },
        `Abas: ${(dadosPlanilha.abas || []).map(a => a.titulo).join(', ')}`));
      previewBox.append(el('div', { class: 'px-meta', style: 'margin-top:4px;word-break:break-word' },
        `Colunas: ${cab.slice(0, 8).join(' · ')}${cab.length > 8 ? ' · …' : ''}`));
      if (linhas.length > 0) {
        previewBox.append(el('div', { class: 'px-meta', style: 'margin-top:4px;color:var(--cor-texto-3)' },
          `Exemplo: ${JSON.stringify(linhas[0]).slice(0, 200)}…`));
      }
    } else {
      // Preview genérico: texto visível + thumbnail
      previewBox.append(el('div', { class: 'px-meta', style: 'word-break:break-word;line-height:1.4' },
        (dadosTela.texto_visivel || '').slice(0, 240) + (dadosTela.texto_visivel?.length > 240 ? '…' : '')));
      if (dadosTela.tabelas?.length > 0) {
        previewBox.append(el('div', { class: 'px-meta', style: 'margin-top:4px' },
          `📊 ${dadosTela.tabelas.length} tabela(s) detectada(s) (HTML)`));
      }
      if (screenshotDataUri) {
        const thumb = el('img', {
          src: screenshotDataUri,
          style: 'max-width:100%;max-height:120px;margin-top:8px;border:1px solid var(--cor-borda);border-radius:var(--raio-2);object-fit:cover',
        });
        previewBox.append(thumb);
      }
    }

    inputPergunta.disabled = false;
    btnAnalisar.disabled = false;
    setTimeout(() => inputPergunta.focus(), 50);
  } catch (e) {
    infoBox.innerHTML = '';
    erroBox.textContent = 'Não consegui ler a tela: ' + e.message;
    erroBox.style.display = 'block';
    return;
  }

  // Analisar
  btnAnalisar.addEventListener('click', async () => {
    const pergunta = inputPergunta.value.trim();
    if (!rClonar.checked && !rReel.checked && !rYt.checked && !rWhatsappBuscar.checked && !pergunta) {
      erroBox.textContent = 'Digita o que você quer saber sobre a tela.';
      erroBox.style.display = 'block';
      return;
    }
    erroBox.style.display = 'none';
    btnAnalisar.disabled = true;
    btnAnalisar.textContent = rWhatsappBuscar.checked ? 'Abrindo busca...' : rYt.checked ? 'Transcrevendo...' : rReel.checked ? 'Baixando reel...' : (rClonar.checked ? 'Clonando...' : (rEditar.checked ? 'Executando...' : 'Analisando...'));

    // v0.24 — CAMINHO WHATSAPP BUSCA
    if (rWhatsappBuscar.checked) {
      overlay.remove();
      abrirBuscaWhatsApp();
      return;
    }

    // v0.22.0: CAMINHO YOUTUBE — chama tool-transcrever-youtube
    if (rYt.checked && dadosTela?.url) {
      overlay.remove();
      const progressoCtx = mostrarProgressoAnalise({ modo: 'youtube', agente_slug: 'transcrever-youtube' });
      try {
        progressoCtx.setEstado('Pegando metadata oficial do YouTube…');
        const tTrans = setTimeout(() => progressoCtx.setEstado('Extraindo transcript (legendas / auto-caption)…'), 4000);
        const tCom = setTimeout(() => progressoCtx.setEstado('Coletando top 200 comentários relevantes…'), 10000);
        const tDemora = setTimeout(() => progressoCtx.setEstado('Demorando mais que o normal — vídeo longo?'), 25000);

        const url = `${SUPABASE_URL}/functions/v1/tool-transcrever-youtube`;
        const r = await fetchProxy(url, {
          method: 'POST',
          headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: dadosTela.url, cliente_id: session.user.id, max_comentarios: 200 }),
        });
        clearTimeout(tTrans); clearTimeout(tCom); clearTimeout(tDemora);
        if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);

        progressoCtx.fechar();
        mostrarResultadoTranscreverYoutube({ resultado: r.body });
      } catch (e) {
        progressoCtx.erro('Falha ao transcrever: ' + e.message, () => {
          progressoCtx.fechar();
          setTimeout(() => abrirAnalisarTela(), 100);
        });
      }
      return;
    }

    // v0.21.0: CAMINHO REEL — sócio escolheu via radio. Chama Edge tool-baixar-reel.
    if (rReel.checked && dadosTela?.url) {
      overlay.remove();
      const progressoCtx = mostrarProgressoAnalise({ modo: 'reel', agente_slug: 'baixar-reel' });
      try {
        progressoCtx.setEstado('Apify scraping o reel (Chromium real)…');
        const tBaixa = setTimeout(() => progressoCtx.setEstado('Baixando MP4 e enviando pro Storage…'), 12000);
        const tTrans = setTimeout(() => progressoCtx.setEstado('Transcrevendo áudio (Whisper)…'), 22000);
        const tDemora = setTimeout(() => progressoCtx.setEstado('Demorando mais que o normal…'), 50000);

        const url = `${SUPABASE_URL}/functions/v1/tool-baixar-reel`;
        const r = await fetchProxy(url, {
          method: 'POST',
          headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: dadosTela.url, cliente_id: session.user.id, transcrever: true }),
        });
        clearTimeout(tBaixa); clearTimeout(tTrans); clearTimeout(tDemora);
        if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);

        progressoCtx.fechar();
        mostrarResultadoBaixarReel({ resultado: r.body });
      } catch (e) {
        progressoCtx.erro('Falha ao baixar reel: ' + e.message, () => {
          progressoCtx.fechar();
          setTimeout(() => abrirAnalisarTela(), 100);
        });
      }
      return;
    }

    // v0.15.0: briefing + agente dependem do modoAnalise
    let briefing, agente_slug;
    const payload = {
      tenant_id: '00000000-0000-0000-0000-000000000000',
      cliente_id: session.user.id,
    };

    // v0.17.0: modo CEO (profundo) ou rapido (default)
    const modoEntrega = checkModo.checked ? 'profundo' : 'rapido';
    const instrucaoModo = modoEntrega === 'profundo'
      ? `\n**Modo: profundo (CEO)** — responda em blocos estruturados visuais. Use @KPI e @SECAO conforme system prompt. Detecte tipo da planilha (vendas/leads/funil/financeiro/NPS/SaaS) pelos cabecalhos e adapte foco. Sempre inclua TL;DR, 2-4 KPIs, secao "O que vi", secao "Provocacao" e secao "Acoes" quando aplicavel.`
      : `\n**Modo: rapido** — resposta enxuta, 3-6 bullets curtos. Sem @KPI, sem @SECAO, sem TL;DR.`;

    // v0.18.0: acao_radio Analisar vs Editar
    const acaoUsuario = rEditar.checked ? 'editar' : 'analisar';

    // v0.19.1: CAMINHO CLONADOR — sócio escolheu via radio. Chama Edge direto.
    if (rClonar.checked && dadosPaginaVenda) {
      overlay.remove();
      const progressoCtx = mostrarProgressoAnalise({ modo: 'pagina-venda', agente_slug: 'clonador-de-pagina-venda' });
      try {
        // v0.20.0: Apify renderiza no servidor (Chromium real). HTML/screenshot da extensão
        // ficam como FALLBACK caso Apify falhe. Sem necessidade de upload pesado.
        progressoCtx.setEstado('Apify renderizando página com Chromium real…');
        let screenshotComprimido = dadosPaginaVenda.screenshot;
        if (screenshotComprimido && screenshotComprimido.startsWith('data:image/png')) {
          try { screenshotComprimido = await comprimirImagem(screenshotComprimido, 1280, 0.75); }
          catch (eC) { console.warn('compress falhou:', eC); }
        }
        let htmlPayload = dadosPaginaVenda.html;
        if (htmlPayload && htmlPayload.length > 300000) htmlPayload = htmlPayload.slice(0, 300000);

        const tApify = setTimeout(() => progressoCtx.setEstado('Apify ainda processando (10-30s pra páginas SPA)…'), 8000);
        const tBriefing = setTimeout(() => progressoCtx.setEstado('Extraindo briefing (GPT-4o lendo página inteira)…'), 18000);
        const tQuase = setTimeout(() => progressoCtx.setEstado('Quase lá — estruturando 12+ blocos canônicos…'), 30000);
        const tDemora = setTimeout(() => progressoCtx.setEstado('Demorando mais que o normal…'), 50000);

        const url = `${SUPABASE_URL}/functions/v1/tool-clonar-pagina-venda`;
        const body = JSON.stringify({
          url: dadosPaginaVenda.url,
          html: htmlPayload,
          screenshot_data_uri: screenshotComprimido,
          cliente_id: session.user.id,
        });

        // v0.19.3: retry automatico em 504 (gateway timeout pode ser transitório)
        let r;
        for (let tent = 1; tent <= 2; tent++) {
          r = await fetchProxy(url, {
            method: 'POST',
            headers: {
              apikey: SUPABASE_ANON_KEY,
              Authorization: `Bearer ${session.access_token}`,
              'Content-Type': 'application/json',
            },
            body,
          });
          if (r.ok) break;
          if (r.status === 504 && tent === 1) {
            progressoCtx.setEstado('Timeout — tentando de novo automaticamente…');
            await new Promise(rs => setTimeout(rs, 1500));
            continue;
          }
          break;
        }
        clearTimeout(tApify); clearTimeout(tBriefing); clearTimeout(tQuase); clearTimeout(tDemora);
        if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);

        progressoCtx.fechar();
        mostrarResultadoClonarPagina({ resultado: r.body, dadosPaginaVenda });
      } catch (e) {
        progressoCtx.erro('Falha ao clonar: ' + e.message, () => {
          progressoCtx.fechar();
          setTimeout(() => abrirAnalisarTela(), 100);
        });
      }
      return;
    }

    if (modoAnalise === 'planilha' && dadosPlanilha && acaoUsuario === 'editar') {
      // CAMINHO EDITOR (v0.18.0)
      agente_slug = 'editor-de-planilha';
      briefing = `**COMANDO DO USUÁRIO:** ${pergunta}

**CONTEXTO DA PLANILHA (lida via Google Sheets API v4):**
- spreadsheet_id: \`${dadosPlanilha.spreadsheet_id}\`
- aba principal: \`${dadosPlanilha.abas?.[0]?.titulo || 'Sheet1'}\`
- total_linhas: ${dadosPlanilha.total_linhas} / total_colunas: ${dadosPlanilha.total_colunas}

\`\`\`json
${JSON.stringify({
  titulo: dadosPlanilha.titulo,
  abas: dadosPlanilha.abas,
  range_lido: dadosPlanilha.range_lido,
  valores: dadosPlanilha.valores,
}, null, 2)}
\`\`\`

Traduza o comando em ações estruturadas no formato @EDICAO:...@FIMEDICAO.`;
    } else if (modoAnalise === 'planilha' && dadosPlanilha) {
      agente_slug = 'analista-de-planilha';
      briefing = `**PERGUNTA DO USUÁRIO:** ${pergunta}
${instrucaoModo}

**DADOS DA PLANILHA (lidos via Google Sheets API v4 — dados estruturados, não OCR):**
\`\`\`json
${JSON.stringify({
  titulo: dadosPlanilha.titulo,
  abas: dadosPlanilha.abas,
  range_lido: dadosPlanilha.range_lido,
  total_linhas: dadosPlanilha.total_linhas,
  total_colunas: dadosPlanilha.total_colunas,
  valores: dadosPlanilha.valores,
}, null, 2)}
\`\`\`

Responda a pergunta com base nos dados estruturados acima.`;
    } else {
      // Modo genérico (DOM + vision)
      agente_slug = 'pinguim-analisador-tela';
      briefing = `**PERGUNTA DO USUÁRIO:**
${pergunta}
${instrucaoModo}

**CONTEÚDO DA TELA (lida agora):**
\`\`\`json
${JSON.stringify({
  url: dadosTela.url,
  titulo: dadosTela.titulo,
  dominio: dadosTela.dominio,
  meta: dadosTela.meta,
  texto_visivel: (dadosTela.texto_visivel || '').slice(0, 8000),
  tabelas: dadosTela.tabelas?.slice(0, 3) || [],
  formularios: dadosTela.formularios?.slice(0, 15) || [],
  links_importantes: dadosTela.links_importantes?.slice(0, 10) || [],
}, null, 2)}
\`\`\`

Responde a pergunta acima com base no que está na tela.`;
      if (screenshotDataUri) {
        payload.contexto_extra = { imagem_data_uri: screenshotDataUri };
      }
    }

    payload.agente_slug = agente_slug;
    payload.briefing = briefing;

    // v0.16.0: substitui modal por progresso verbose com pinguim animado
    overlay.remove();
    const progressoCtx = mostrarProgressoAnalise({ modo: modoAnalise, agente_slug });

    try {
      // Anima estados antes da chamada
      progressoCtx.setEstado(modoAnalise === 'planilha'
        ? 'Enviando dados estruturados pro Analista de Planilha…'
        : 'Enviando tela pro Analisador (DOM + visão)…');

      const url = `${SUPABASE_URL}/functions/v1/agente-executar`;
      const tPensando = setTimeout(() => progressoCtx.setEstado('Agente pensando…'), 1200);
      const tQuase = setTimeout(() => progressoCtx.setEstado('Quase lá, escrevendo análise…'), 6000);
      // v0.17.4: estados adicionais + timeout hard
      const tDemora = setTimeout(() => progressoCtx.setEstado('Demorando mais que o normal — aguardando OpenAI…'), 25000);
      const tMuito = setTimeout(() => progressoCtx.setEstado('Ainda esperando resposta… (>45s, pode estar travado)'), 45000);

      // Race: fetch vs timeout 60s
      const HARD_TIMEOUT_MS = 60000;
      const fetchPromise = fetchProxy(url, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      const timeoutPromise = new Promise((_, rej) =>
        setTimeout(() => rej(new Error('TIMEOUT_CLIENTE')), HARD_TIMEOUT_MS));

      const r = await Promise.race([fetchPromise, timeoutPromise]);
      clearTimeout(tPensando); clearTimeout(tQuase); clearTimeout(tDemora); clearTimeout(tMuito);

      if (!r.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);
      const conteudo = r.body?.conteudo_md || '';

      progressoCtx.fechar();
      mostrarResultadoAnaliseTela({
        pergunta, resposta: conteudo, dadosTela,
        agente_usado: agente_slug,
        modo: modoAnalise,
        modoEntrega,
        acaoUsuario,
        dadosPlanilha, // pra editor poder chamar Edge
      });
    } catch (e) {
      const msg = e.message === 'TIMEOUT_CLIENTE'
        ? 'A OpenAI não respondeu em 60s. Pode ser instabilidade. Tente novamente.'
        : 'Falha: ' + e.message;
      progressoCtx.erro(msg, () => {
        progressoCtx.fechar();
        // re-abre formulário pra tentar de novo
        setTimeout(() => abrirAnalisarTela(), 100);
      });
    }
  });

  // Enter no input dispara analise
  inputPergunta.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      btnAnalisar.click();
    }
  });
}

function mostrarResultadoAnaliseTela({ pergunta, resposta, dadosTela, agente_usado, modo, modoEntrega, acaoUsuario, dadosPlanilha }) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:680px;max-height:90vh;overflow-y:auto' });

  // v0.15.0: titulo reflete o agente especialista usado
  const tituloModal = modo === 'planilha'
    ? '📊 Análise da planilha'
    : '👁 Análise da tela';
  box.append(el('h3', { class: 'modal-pinguim-titulo' }, tituloModal));

  // Cabecalho com origem + agente usado
  const cabecalho = el('div', { class: 'px-meta', style: 'margin-bottom:10px' });
  cabecalho.append(el('span', {}, `📍 ${dadosTela.dominio} · ${(dadosTela.titulo || '').slice(0, 60)}`));
  if (agente_usado) {
    cabecalho.append(el('span', { class: 'px-badge', style: 'margin-left:8px' },
      modo === 'planilha' ? 'Analista de Planilha' : 'Analisador de Tela'));
  }
  box.append(cabecalho);

  // Pergunta
  box.append(el('div', { class: 'px-rotulo' }, 'Sua pergunta'));
  box.append(el('div', { class: 'px-card px-card--sm', style: 'margin-bottom:14px;font-size:13px' }, pergunta));

  // Resposta — v0.17.3: gate inteligente. Renderiza estruturado se detecta
  // markdown padrao (## ## ##) OU @KPI/@SECAO OU bullets com **Label:** valor
  box.append(el('div', { class: 'px-rotulo' }, 'Resposta'));
  const textoResp = resposta || '';

  // v0.18.0: detecta bloco @EDICAO: ... @FIMEDICAO (modo Editar)
  const edicaoMatch = textoResp.match(/@EDICAO:\s*([\s\S]+?)\s*@FIMEDICAO/);
  let edicaoPayload = null;
  let textoSemEdicao = textoResp;
  if (edicaoMatch) {
    try {
      edicaoPayload = JSON.parse(edicaoMatch[1].trim());
      textoSemEdicao = textoResp.replace(edicaoMatch[0], '').trim();
    } catch (e) {
      console.warn('JSON @EDICAO invalido:', e.message);
    }
  }

  // Renderiza texto explicativo (limpando markdown se houver)
  if (textoSemEdicao) {
    const temMarcadorEstruturado =
      /@KPI:|@SECAO:/.test(textoSemEdicao) ||
      /^\s*#{1,6}\s+\S/m.test(textoSemEdicao) ||
      /^\s*[-*•]\s*\*\*[^*]+\*\*\s*:?\s*\S/m.test(textoSemEdicao) ||
      /^\s*\*\*[^*]+:?\*\*\s*\S/m.test(textoSemEdicao);
    if (modoEntrega === 'profundo' && temMarcadorEstruturado) {
      box.append(renderRespostaEstruturada(textoSemEdicao));
    } else {
      const respostaBox = el('div', { class: 'px-card', style: 'line-height:1.55;font-size:13px;white-space:pre-wrap' });
      respostaBox.textContent = textoSemEdicao;
      box.append(respostaBox);
    }
  }

  // v0.18.0: card de EDICAO (plano ou execucao direta)
  if (edicaoPayload && acaoUsuario === 'editar' && dadosPlanilha) {
    box.append(renderCardEdicao(edicaoPayload, dadosPlanilha));
  }

  // v0.16.0: FEEDBACK 👍/👎 (mesmo padrão do chat)
  const feedbackRow = el('div', { class: 'px-row', style: 'gap:6px;margin-top:10px;align-items:center' });
  feedbackRow.append(el('span', { class: 'px-meta' }, 'Essa resposta foi boa?'));
  const btnUp = el('button', {
    class: 'px-btn px-btn--sm px-btn--ghost', type: 'button',
    title: 'Resposta boa — registra reforço positivo',
  }, '👍');
  const btnDown = el('button', {
    class: 'px-btn px-btn--sm px-btn--ghost', type: 'button',
    title: 'Resposta ruim — abre correção',
  }, '👎');
  const feedbackStatus = el('span', { class: 'px-meta', style: 'margin-left:8px' });

  btnUp.addEventListener('click', async () => {
    btnUp.disabled = true; btnDown.disabled = true;
    btnUp.textContent = '👍 enviando...';
    try {
      const r = await enviarFeedback({
        agente_slug: agente_usado, tipo: 'positivo',
        pergunta_usuario: pergunta, resposta_agente: resposta,
      });
      if (r.ok) {
        btnUp.textContent = '👍 obrigado!';
        feedbackStatus.textContent = 'feedback registrado';
      } else {
        btnUp.textContent = '👍';
        btnUp.disabled = false; btnDown.disabled = false;
        feedbackStatus.textContent = 'falha: ' + (r.erro || '?');
      }
    } catch (e) {
      btnUp.textContent = '👍';
      btnUp.disabled = false; btnDown.disabled = false;
      feedbackStatus.textContent = 'falha';
    }
  });

  btnDown.addEventListener('click', () => {
    abrirModalCorrecao({
      agente: { slug: agente_usado, nome: modo === 'planilha' ? 'Analista de Planilha' : 'Analisador de Tela' },
      pergunta, resposta,
      onEnviado: () => {
        btnUp.disabled = true; btnDown.disabled = true;
        btnDown.textContent = '👎 enviado';
        feedbackStatus.textContent = 'correção registrada — o agente vai aprender';
      },
    });
  });

  feedbackRow.append(btnUp, btnDown, feedbackStatus);
  box.append(feedbackRow);

  // v0.17.0: COMPARTILHAR — 📋 Copiar + 💬 Mandar pro Atendente Pinguim
  const compartilharRow = el('div', { class: 'px-row', style: 'gap:8px;margin-top:10px;padding-top:10px;border-top:1px solid var(--cor-borda)' });
  compartilharRow.append(el('span', { class: 'px-meta' }, 'Compartilhar:'));

  const btnCopiar = el('button', {
    class: 'px-btn px-btn--sm', type: 'button',
    title: 'Copia a resposta formatada para colar em WhatsApp/email',
  }, '📋 Copiar pra WhatsApp');
  btnCopiar.addEventListener('click', async () => {
    const textoFormatado = formatarParaCompartilhar({ pergunta, resposta, dadosTela, modo });
    try {
      await navigator.clipboard.writeText(textoFormatado);
      const labelOriginal = btnCopiar.textContent;
      btnCopiar.textContent = '✓ Copiado!';
      btnCopiar.disabled = true;
      setTimeout(() => { btnCopiar.textContent = labelOriginal; btnCopiar.disabled = false; }, 1800);
    } catch (e) {
      mostrarAlerta({ titulo: 'Falha ao copiar', mensagem: 'Não consegui acessar a área de transferência: ' + e.message, tipo: 'erro' });
    }
  });

  // v0.17.2: removido "Mandar pro Atendente" — bug de DOM + risco de disparo errado.
  // Quando voltar, vira sprint dedicado com confirmação explicita.

  compartilharRow.append(btnCopiar);
  box.append(compartilharRow);

  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:space-between;gap:8px;margin-top:14px' });
  const btnNova = el('button', { class: 'modal-pinguim-btn', type: 'button' }, '👁 Outra pergunta');
  btnNova.addEventListener('click', () => { overlay.remove(); abrirAnalisarTela(); });
  const btnOk = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, 'Fechar');
  btnOk.addEventListener('click', () => overlay.remove());
  acoes.append(btnNova, btnOk);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);
}

// =====================================================================
// v0.17.0: Renderiza resposta estruturada (@KPI / @SECAO)
// =====================================================================
// v0.17.1: Parser inteligente — aceita 3 formatos do LLM:
//   (a) Marcadores explicitos: @KPI: | @SECAO:
//   (b) Markdown padrao: ## H2, ### H3 (LLM usa por viés)
//   (c) Bullets numericos: "**Algo**: R$ 1.000 — contexto"  ou  "Ticket Médio: 617"
//
// Estrategia: 2 passes. Primeiro identifica secoes (markers ou markdown headers).
// Depois varre as linhas "soltas" (TL;DR ou dentro de secoes especificas) procurando
// padroes de KPI explícitos e promove pra cards visuais.
function renderRespostaEstruturada(texto) {
  const wrap = el('div', { class: 'px-stack' });
  if (!texto) {
    wrap.append(el('div', { class: 'px-card' }, '(sem resposta)'));
    return wrap;
  }

  // ==================================
  // PASS 1 — identificar blocos
  // ==================================
  const linhas = String(texto).split('\n');
  const blocos = [];   // [{ tipo: 'tldr'|'kpi'|'secao', ... }]
  let cursorSecao = null;
  let bufferTldr = [];

  function flushTldr() {
    const txt = bufferTldr.join('\n').trim();
    if (txt) blocos.push({ tipo: 'tldr', texto: txt });
    bufferTldr = [];
  }

  for (let i = 0; i < linhas.length; i++) {
    const raw = linhas[i];
    const l = raw.trimEnd();

    // Marker explicito @KPI:
    let m = l.match(/^\s*@KPI\s*:\s*(.+)$/i);
    if (m) {
      flushTldr(); cursorSecao = null;
      const partes = m[1].split('|').map(p => p.trim());
      blocos.push({ tipo: 'kpi', rotulo: partes[0] || '', valor: partes[1] || '', contexto: partes[2] || '' });
      continue;
    }
    // Marker explicito @SECAO:
    m = l.match(/^\s*@SECAO\s*:\s*(.+)$/i);
    if (m) {
      flushTldr();
      cursorSecao = { tipo: 'secao', titulo: m[1].trim(), linhas: [] };
      blocos.push(cursorSecao);
      continue;
    }
    // Markdown header (qualquer nivel — LLM usa #, ##, ###, #### conforme quer)
    m = l.match(/^\s*#{1,6}\s+(.+?)\s*$/);
    if (m) {
      flushTldr();
      const tit = m[1].replace(/\*+/g, '').trim();
      cursorSecao = { tipo: 'secao', titulo: tit, linhas: [] };
      blocos.push(cursorSecao);
      continue;
    }
    // **Resumo Executivo:** ou **TL;DR:** — vira card destacado
    m = l.match(/^\s*\*\*\s*(resumo\s*executivo|tl[;:]?\s*dr|sumario|sintese)\s*:?\s*\*\*\s*(.*)$/i);
    if (m) {
      flushTldr();
      const titulo = m[1].toLowerCase().includes('tl') ? 'TL;DR' : 'Resumo Executivo';
      cursorSecao = { tipo: 'tldr-card', titulo, linhas: [m[2]].filter(Boolean) };
      blocos.push(cursorSecao);
      continue;
    }

    // Conteúdo
    if (cursorSecao) {
      cursorSecao.linhas.push(l);
    } else {
      bufferTldr.push(l);
    }
  }
  flushTldr();

  // ==================================
  // PASS 2 — extrair KPIs automaticos do tldr e secoes
  // ==================================
  // Padroes que viram KPI automaticamente (em bullets ou linhas isoladas):
  //   "**Rotulo**: valor com numero — contexto"
  //   "**Rotulo:** valor"
  //   "Rotulo: R$ 123,45"
  //   "Rotulo: 18% de algo"
  //   "Total de X: 127"
  function tentarExtrairKpisDoTextoLivre(texto) {
    const out = { textoSemKpis: [], kpis: [] };
    const linhasInternas = String(texto || '').split('\n');
    for (const lin of linhasInternas) {
      const lt = lin.trim();
      // v0.17.2: regex mais permissivo — aceita 4 formatos:
      //   "- **Rotulo:** valor | contexto"     (asterisco com : dentro)
      //   "- **Rotulo**: valor — contexto"     (asterisco sem :, depois :)
      //   "- Rotulo: R$ 1.000 — contexto"      (sem asterisco)
      //   Separadores aceitos: |, —, –, -, ou (
      let m, rotulo, valor, ctx;

      // Forma 1: bullet com asterisco — captura GREEDY até último ":**" ou "**:"
      m = lt.match(/^[-*•]?\s*\*\*([^*]+)\*\*\s*:?\s*(.+)$/);
      if (m) {
        rotulo = m[1].trim().replace(/:$/, '').trim();  // tira : final do rotulo
        // m[2] pode ser "35 | Transações aprovadas" — separa por | ou — ou (
        const restoMatch = m[2].match(/^(.+?)\s*[|—–]\s*(.+)$/) || m[2].match(/^(.+?)\s*\((.+?)\)\s*$/);
        if (restoMatch) {
          valor = restoMatch[1].trim();
          ctx = restoMatch[2].trim();
        } else {
          valor = m[2].trim();
          ctx = '';
        }
      } else {
        // Forma 2: sem asterisco — "Rotulo: numero"
        m = lt.match(/^[-*•]?\s*([^:*\n]{3,50}?)\s*:\s*(R\$\s*[\d.,]+|[\d.,]+%?|\d[\d.,]*[a-zA-Z%]*)\s*(?:[|—–\-]\s*(.+))?$/);
        if (m) {
          rotulo = m[1].trim();
          valor = m[2].trim();
          ctx = (m[3] || '').trim();
        }
      }

      if (rotulo && valor) {
        rotulo = rotulo.replace(/\*+/g, '').trim();
        valor = valor.replace(/\*+/g, '').trim();
        ctx = (ctx || '').replace(/\*+/g, '').trim();
        // Filtros: precisa ter numero no valor OU no contexto, rotulo 3-50 chars, valor max 40 chars
        const temNumero = /\d/.test(valor) || /\d/.test(ctx);
        if (temNumero && rotulo.length >= 3 && rotulo.length <= 50 && valor.length <= 40) {
          out.kpis.push({ rotulo, valor, contexto: ctx });
          continue;
        }
      }
      // Linha normal
      out.textoSemKpis.push(lin);
    }
    return out;
  }

  // ==================================
  // RENDER
  // ==================================
  // Card TL;DR (texto livre antes do primeiro bloco)
  for (const b of blocos) {
    if (b.tipo === 'tldr') {
      const tldrCard = el('div', {
        class: 'px-card',
        style: 'background:var(--cor-fundo-3);border-color:var(--cor-borda-forte);line-height:1.55;font-size:13px;white-space:pre-wrap',
      });
      tldrCard.textContent = limparMarkdownInline(b.texto);
      wrap.append(tldrCard);
    }
    if (b.tipo === 'tldr-card') {
      const tldrCard = el('div', {
        class: 'px-card',
        style: 'background:var(--cor-fundo-3);border-color:var(--cor-borda-forte);line-height:1.55;font-size:13px',
      });
      tldrCard.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:4px' }, b.titulo));
      const corpo = el('div', { style: 'white-space:pre-wrap' });
      corpo.textContent = limparMarkdownInline(b.linhas.join('\n').trim());
      tldrCard.append(corpo);
      wrap.append(tldrCard);
    }
    if (b.tipo === 'kpi') {
      // KPIs explicitos viram um grid de 1 — vamos agrupa-los abaixo
    }
  }

  // Junta KPIs explícitos + extrai KPIs do conteúdo de seções específicas
  let todosKpis = blocos.filter(b => b.tipo === 'kpi').map(b => ({ rotulo: b.rotulo, valor: b.valor, contexto: b.contexto }));

  // Se nao tem KPI explicito, tenta extrair do texto livre tldr / secao "Numeros"
  if (todosKpis.length === 0) {
    for (const b of blocos) {
      if (b.tipo === 'tldr') {
        const r = tentarExtrairKpisDoTextoLivre(b.texto);
        todosKpis.push(...r.kpis);
      }
      if (b.tipo === 'secao' && /numero|metric|kpi|dados|estatistic|panorama|fato/i.test(b.titulo)) {
        const r = tentarExtrairKpisDoTextoLivre(b.linhas.join('\n'));
        if (r.kpis.length > 0) {
          todosKpis.push(...r.kpis);
          // Se MAIORIA virou KPI, marca pra nao re-renderizar a secao
          if (r.kpis.length >= r.textoSemKpis.length) b._renderizado = true;
        }
      }
    }
  }

  // Render KPIs em grid
  if (todosKpis.length > 0) {
    const grid = el('div', { class: 'analise-kpis' });
    todosKpis.forEach(kpi => {
      const card = el('div', { class: 'analise-kpi-card' });
      card.append(el('div', { class: 'analise-kpi-rotulo' }, kpi.rotulo));
      card.append(el('div', { class: 'analise-kpi-valor' }, kpi.valor));
      if (kpi.contexto) card.append(el('div', { class: 'analise-kpi-contexto' }, kpi.contexto));
      grid.append(card);
    });
    wrap.append(grid);
  }

  // Seções restantes
  for (const b of blocos) {
    if (b.tipo === 'secao' && !b._renderizado) {
      const card = el('div', { class: 'analise-secao' });
      card.append(el('div', { class: 'analise-secao-titulo' }, b.titulo));
      const corpo = el('div', { style: 'line-height:1.55;font-size:13px;white-space:pre-wrap' });
      corpo.textContent = limparMarkdownInline(b.linhas.join('\n').trim());
      card.append(corpo);
      wrap.append(card);
    }
  }

  // Se nao gerou NADA, fallback texto puro
  if (wrap.children.length === 0) {
    const fb = el('div', { class: 'px-card', style: 'line-height:1.55;font-size:13px;white-space:pre-wrap' });
    fb.textContent = texto;
    wrap.append(fb);
  }

  return wrap;
}

// Remove markdown inline (** e *) — DOM nao renderiza, vira lixo visual
function limparMarkdownInline(t) {
  return String(t || '')
    .replace(/\*\*([^*]+)\*\*/g, '$1')  // **bold** → bold
    .replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, '$1')  // *italic* → italic
    .trim();
}

// =====================================================================
// v0.18.0: Card de EDICAO em planilha — plano de ação OU execução direta
// =====================================================================
function renderCardEdicao(payload, dadosPlanilha) {
  const wrap = el('div', { class: 'edicao-card' });

  // Header colorido
  const modoExec = payload.modo === 'executar_direto';
  const header = el('div', { class: 'edicao-card__header' + (modoExec ? ' edicao-card__header--direto' : '') });
  header.append(el('div', { class: 'edicao-card__rotulo' },
    modoExec ? '✏ Edição pronta pra executar' : '📋 Plano de ação (aguardando sua confirmação)'));
  wrap.append(header);

  // Resumo
  if (payload.resumo) {
    wrap.append(el('div', { class: 'edicao-card__resumo' }, payload.resumo));
  }

  // Lista de ações
  if (Array.isArray(payload.acoes)) {
    const lista = el('ul', { class: 'edicao-card__acoes' });
    payload.acoes.forEach(a => {
      const li = el('li', {}, [
        el('span', { class: 'edicao-card__acao-tipo' }, descreverAcao(a)),
      ]);
      lista.append(li);
    });
    wrap.append(lista);
  }

  // v0.18.2: container do PREVIEW REAL (preenchido via dry_run, nao mais via LLM alucinando)
  const previewBox = el('div', { class: 'px-meta', style: 'margin-top:6px;font-size:11px;color:var(--cor-texto-3)' },
    '⏳ Calculando linhas afetadas (dry-run)…');
  // So tem sentido pra acoes que suportam dry_run
  const acoesComDryRun = (payload.acoes || []).filter(a =>
    ['preencher_coluna_cond', 'deletar_linhas'].includes(a.acao)
  );
  if (acoesComDryRun.length > 0) {
    wrap.append(previewBox);
    // Dispara dry_run em background pra cada acao + atualiza preview
    (async () => {
      const partes = [];
      let totalLinhas = 0;
      for (const a of acoesComDryRun) {
        try {
          const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-editar-planilha-google`, {
            method: 'POST',
            headers: {
              apikey: SUPABASE_ANON_KEY,
              Authorization: `Bearer ${session.access_token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              ...a,
              spreadsheet_id: dadosPlanilha.spreadsheet_id,
              cliente_id: session.user.id,
              dry_run: true,
            }),
          });
          if (r.ok && r.body?.ok) {
            const linhas = r.body.linhas_afetadas || [];
            totalLinhas += linhas.length;
            if (linhas.length === 0) {
              partes.push(`Nenhuma linha bate condição pra "${descreverAcao(a)}"`);
            } else {
              const preview = linhas.slice(0, 12).join(', ');
              const extra = linhas.length > 12 ? ` + ${linhas.length - 12} outras` : '';
              partes.push(`${linhas.length} linha(s) — ${preview}${extra}`);
            }
          } else {
            partes.push('Erro no dry-run: ' + (r.body?.erro || 'desconhecido'));
          }
        } catch (e) {
          partes.push('Erro: ' + e.message);
        }
      }
      previewBox.textContent = '👁 Linhas afetadas (calculado real, não alucinado): ' + partes.join(' · ');
    })();
  }

  // Botões
  const acoesRow = el('div', { class: 'edicao-card__botoes' });
  const btnStatus = el('div', { class: 'edicao-card__status' });

  if (modoExec) {
    // Modo executar_direto — botão pra executar (com confirmação leve)
    const btnExec = el('button', { class: 'px-btn px-btn--sm px-btn--primario', type: 'button' }, '✓ Executar agora');
    btnExec.addEventListener('click', async () => {
      btnExec.disabled = true;
      btnExec.textContent = 'Executando…';
      btnStatus.textContent = '';
      const resultado = await executarEdicoes(payload.acoes, dadosPlanilha, btnStatus);
      if (resultado.ok) {
        btnExec.textContent = '✓ Executado';
        btnExec.classList.remove('px-btn--primario');
        if (resultado.pode_desfazer) {
          const btnDesfazer = el('button', { class: 'px-btn px-btn--sm', type: 'button', style: 'margin-left:6px' }, '↶ Desfazer');
          btnDesfazer.addEventListener('click', () => desfazerEdicao(resultado.edicao_id, btnDesfazer, btnStatus));
          acoesRow.append(btnDesfazer);
        }
      } else {
        btnExec.textContent = '✗ Falhou — tentar de novo';
        btnExec.disabled = false;
      }
    });
    acoesRow.append(btnExec);
  } else {
    // Plano de ação — Confirmar / Cancelar
    const btnConfirmar = el('button', { class: 'px-btn px-btn--sm px-btn--primario', type: 'button' }, '✓ Confirmar e executar');
    const btnCancelar = el('button', { class: 'px-btn px-btn--sm', type: 'button' }, 'Cancelar');
    btnConfirmar.addEventListener('click', async () => {
      btnConfirmar.disabled = true;
      btnCancelar.disabled = true;
      btnConfirmar.textContent = 'Executando…';
      const resultado = await executarEdicoes(payload.acoes, dadosPlanilha, btnStatus);
      if (resultado.ok) {
        btnConfirmar.textContent = '✓ Executado';
        btnConfirmar.classList.remove('px-btn--primario');
        if (resultado.pode_desfazer) {
          const btnDesfazer = el('button', { class: 'px-btn px-btn--sm', type: 'button', style: 'margin-left:6px' }, '↶ Desfazer');
          btnDesfazer.addEventListener('click', () => desfazerEdicao(resultado.edicao_id, btnDesfazer, btnStatus));
          acoesRow.append(btnDesfazer);
        }
      } else {
        btnConfirmar.textContent = '✗ Falhou';
        btnConfirmar.disabled = false;
        btnCancelar.disabled = false;
      }
    });
    btnCancelar.addEventListener('click', () => {
      wrap.style.opacity = '0.5';
      btnConfirmar.disabled = true;
      btnCancelar.disabled = true;
      btnStatus.textContent = 'Cancelado';
    });
    acoesRow.append(btnConfirmar, btnCancelar);
  }

  acoesRow.append(btnStatus);
  wrap.append(acoesRow);
  return wrap;
}

function descreverAcao(a) {
  const aba = a.aba ? `[${a.aba}]` : '';
  switch (a.acao) {
    case 'escrever_celula':
      return `Escrever "${a.valor}" em ${aba} célula ${a.celula}`;
    case 'escrever_range':
      return `Escrever ${a.valores?.length || 0} linhas em ${aba} ${a.range}`;
    case 'preencher_coluna_cond': {
      const cond = a.condicao || {};
      const condStr = cond.op === 'vazio' ? 'vazias'
        : cond.op === 'nao_vazio' ? 'preenchidas'
        : `${cond.coluna_letra} ${cond.op} "${cond.valor}"`;
      return `Preencher coluna ${a.coluna_letra} com "${a.valor_novo}" onde ${condStr}`;
    }
    case 'adicionar_coluna':
      return `Adicionar coluna ${a.posicao_letra ? `em ${a.posicao_letra}` : '(no fim)'}${a.cabecalho ? ` — cabeçalho "${a.cabecalho}"` : ''}`;
    case 'adicionar_linha':
      return `Adicionar linha ${aba} com ${a.valores?.length || 0} valores`;
    case 'deletar_linhas':
      return `Deletar ${a.linhas?.length || 0} linhas ${aba}`;
    case 'deletar_coluna':
      return `Deletar coluna ${a.coluna_letra} ${aba}`;
    case 'deletar_aba':
      return `Deletar aba ${a.aba}`;
    default:
      return `Ação ${a.acao}`;
  }
}

async function executarEdicoes(acoes, dadosPlanilha, statusEl) {
  const url = `${SUPABASE_URL}/functions/v1/tool-editar-planilha-google`;
  let ultimaEdicaoId = null;
  let podeDesfazer = false;
  let totalImpacto = 0;
  for (let i = 0; i < acoes.length; i++) {
    const acao = acoes[i];
    statusEl.textContent = `Executando ${i + 1}/${acoes.length}: ${acao.acao}…`;
    try {
      const r = await fetchProxy(url, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...acao,
          spreadsheet_id: dadosPlanilha.spreadsheet_id,
          cliente_id: session.user.id,
        }),
      });
      if (!r.ok || !r.body?.ok) {
        const erroMsg = r.body?.erro || `HTTP ${r.status}`;
        statusEl.textContent = `✗ Falhou na ação ${i + 1}: ${erroMsg.slice(0, 80)}`;
        return { ok: false };
      }
      ultimaEdicaoId = r.body.edicao_id;
      podeDesfazer = r.body.pode_desfazer || false;
      totalImpacto += r.body.impacto || 0;
    } catch (e) {
      statusEl.textContent = `✗ Erro de rede: ${e.message}`;
      return { ok: false };
    }
  }
  statusEl.textContent = `✓ ${totalImpacto} célula(s) afetada(s)`;
  return { ok: true, edicao_id: ultimaEdicaoId, pode_desfazer: podeDesfazer };
}

async function desfazerEdicao(edicao_id, btnEl, statusEl) {
  if (!edicao_id) return;
  btnEl.disabled = true;
  btnEl.textContent = 'Desfazendo…';
  try {
    const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-desfazer-edicao-planilha`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ edicao_id }),
    });
    if (r.ok && r.body?.ok) {
      btnEl.textContent = '↶ Desfeito';
      statusEl.textContent = ' · edição revertida';
    } else {
      btnEl.textContent = '↶ Falha ao desfazer';
      btnEl.disabled = false;
    }
  } catch (e) {
    btnEl.textContent = '↶ Erro';
    btnEl.disabled = false;
  }
}

// =====================================================================
// v0.17.0: Formata resposta pra colar em WhatsApp / email (texto plano)
// =====================================================================
function formatarParaCompartilhar({ pergunta, resposta, dadosTela, modo }) {
  // Remove marcacoes @KPI/@SECAO e converte em texto plano amigavel
  let textoLimpo = String(resposta || '')
    .replace(/^\s*@KPI\s*:\s*(.+)$/gmi, (_, conteudo) => {
      const [rotulo, valor, ctx] = conteudo.split('|').map(p => p.trim());
      return `📊 *${rotulo}*: ${valor}${ctx ? ' — ' + ctx : ''}`;
    })
    .replace(/^\s*@SECAO\s*:\s*(.+)$/gmi, (_, titulo) => `\n*${titulo}*`)
    .trim();

  const cabecalho = modo === 'planilha' ? '📊 Análise de Planilha — Pinguim Agentes' : '👁 Análise de Tela — Pinguim Agentes';
  const fonte = `Fonte: ${dadosTela.dominio} · ${(dadosTela.titulo || '').slice(0, 80)}`;

  return [
    cabecalho,
    fonte,
    '',
    `*Pergunta:* ${pergunta}`,
    '',
    textoLimpo,
    '',
    '— gerado pelo Pinguim Agentes',
  ].join('\n');
}

// =====================================================================
// v0.17.0: Abre Atendente Pinguim com mensagem ja preenchida
// =====================================================================
async function abrirAtendenteComMensagem(mensagemInicial) {
  // Roteamento: usa o agente Pinguim Triagem (geral) com mensagem pre-preenchida
  // Caminho mais simples: roteia pra categoria Chat e injeta texto no input
  // Estrategia: irPara('chat'), aguarda render, encontra input, preenche, dispara
  try {
    irPara('chat');
    // Espera DOM renderizar
    await new Promise(r => setTimeout(r, 250));
    const input = document.querySelector('.home-pergunta-input');
    if (input) {
      input.value = mensagemInicial;
      input.dispatchEvent(new Event('input'));
      input.focus();
      // Rola pro topo
      input.scrollIntoView({ behavior: 'smooth', block: 'center' });
      // Avisa que esta preenchido — usuario clica enviar
      setTimeout(() => {
        mostrarAlerta({
          titulo: 'Análise preenchida no Chat',
          mensagem: 'Conferi e mandei pra você — ajuste o texto se quiser e aperte enviar.',
          tipo: 'info',
        });
      }, 100);
    } else {
      // Fallback: copia + avisa
      try {
        await navigator.clipboard.writeText(mensagemInicial);
        mostrarAlerta({
          titulo: 'Análise copiada',
          mensagem: 'Não consegui preencher o chat automaticamente. A análise foi copiada — cola no Chat manualmente.',
          tipo: 'aviso',
        });
      } catch (_) {
        mostrarAlerta({ titulo: 'Falha', mensagem: 'Não consegui abrir o chat. Tenta o botão de copiar.', tipo: 'erro' });
      }
    }
  } catch (e) {
    mostrarAlerta({ titulo: 'Falha', mensagem: 'Erro: ' + e.message, tipo: 'erro' });
  }
}

// =====================================================================
// v0.16.0: Modal de progresso da analise (pinguim animado + estados verbose)
// =====================================================================
function mostrarProgressoAnalise({ modo, agente_slug }) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:480px;text-align:center;padding:32px 24px' });

  // Titulo dinamico
  const titulos = {
    planilha: '📊 Analisando planilha…',
    'pagina-venda': '📄 Clonando página…',
    'whatsapp-busca': '🔍 Buscando no WhatsApp…',
  };
  const tituloTxt = titulos[modo] || '👁 Analisando tela…';
  const titulo = el('h3', { class: 'modal-pinguim-titulo' }, tituloTxt);
  box.append(titulo);

  // Pinguim animado (componente que ja existe no DS X — .px-pinguim-load)
  const pinguimWrap = el('div', { class: 'px-pinguim-load', style: 'padding:16px 0;margin:8px 0' });
  pinguimWrap.append(el('div', { html: PINGUIM_SVG }).firstElementChild);
  const estadoInicial = {
    planilha: 'Preparando dados estruturados…',
    'pagina-venda': 'Preparando captura de HTML + screenshot…',
    'whatsapp-busca': 'Rolando o painel do WhatsApp…',
  };
  const estadoEl = el('div', { class: 'px-pinguim-load__msg', style: 'margin-top:8px;font-size:13px' },
    estadoInicial[modo] || 'Preparando tela e screenshot…');
  pinguimWrap.append(estadoEl);

  // Sub-info do agente
  const subInfo = {
    planilha: 'Analista de Planilha (Sheets API + gpt-4o)',
    'pagina-venda': 'Clonador de Página (HTML + GPT-4o briefing)',
    'whatsapp-busca': 'Busca local (sem IA, custo zero)',
  };
  const meta = el('div', { class: 'px-meta', style: 'margin-top:4px' },
    subInfo[modo] || 'Analisador de Tela (DOM + visão)');
  pinguimWrap.append(meta);

  box.append(pinguimWrap);

  // Barra de progresso indeterminada (animacao puramente visual)
  const barra = el('div', { class: 'px-progresso' });
  const barraInterna = el('div', { class: 'px-progresso__fill' });
  barra.append(barraInterna);
  box.append(barra);

  // Botao cancelar (UI honesta — clica e fecha o modal; chamada continua em background mas resultado descartado)
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:center;margin-top:14px' });
  const btnCancelar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Fechar');
  let cancelado = false;
  btnCancelar.addEventListener('click', () => { cancelado = true; overlay.remove(); });
  acoes.append(btnCancelar);
  box.append(acoes);

  overlay.append(box);
  document.body.append(overlay);

  return {
    setEstado(texto) {
      if (cancelado) return;
      estadoEl.textContent = texto;
    },
    erro(msg, onRetry) {
      if (cancelado) return;
      pinguimWrap.style.display = 'none';
      barra.style.display = 'none';
      const erroEl = el('div', { class: 'alerta-erro', style: 'margin-top:6px' }, msg);
      box.insertBefore(erroEl, acoes);
      btnCancelar.textContent = 'Fechar';
      // v0.17.4: botao Tentar de novo
      if (typeof onRetry === 'function') {
        const btnRetry = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button', style: 'margin-left:8px' }, '🔄 Tentar de novo');
        btnRetry.addEventListener('click', () => onRetry());
        acoes.append(btnRetry);
      }
    },
    fechar() { overlay.remove(); },
  };
}

// Auto-refresh quando sidebar reabre (content script avisa)
window.addEventListener('message', (ev) => {
  if (ev.data?.pinguimTipo === 'SIDEBAR_REABRIU') {
    if (session?.access_token) {
      agentesCache = null;
      squadsCache = null;
      if (!conversaAtual) {
        renderCategoriaAtual();  // v0.9.1: preserva categoria
      }
    }
  }
});

btnAtualizar.addEventListener('click', async () => {
  if (!session?.access_token) return;
  btnAtualizar.style.opacity = '0.5';
  btnAtualizar.style.pointerEvents = 'none';
  setStatus('Atualizando agentes...');
  // Invalida caches
  agentesCache = null;
  squadsCache = null;
  // Re-renderiza
  if (conversaAtual) {
    // se está em chat, volta pra lista e atualiza
    conversaAtual = null;
  }
  try {
    await renderCategoriaAtual();  // v0.9.1: preserva categoria
  } catch (e) {
    setStatus('Erro ao atualizar: ' + e.message);
  } finally {
    btnAtualizar.style.opacity = '1';
    btnAtualizar.style.pointerEvents = 'auto';
  }
});

function atualizarTooltipFixar(ativo) {
  btnFixar.title = ativo
    ? '📌 Fixado — sidebar abre automaticamente em todas as abas. Clique pra desfixar.'
    : 'Fixar sidebar — abrir automaticamente em todas as abas';
  btnFixar.setAttribute('aria-label', ativo ? 'Desfixar sidebar' : 'Fixar sidebar');
}

btnFixar.addEventListener('click', async () => {
  const data = await storageGet(['sempreFixa']);
  const novo = !data.sempreFixa;
  await storageSet({ sempreFixa: novo });
  window.parent.postMessage({ pinguimTipo: 'SET_FIXA', valor: novo }, '*');
  btnFixar.classList.toggle('ativo', novo);
  atualizarTooltipFixar(novo);
  setStatus(novo ? '📌 Fixado — sidebar abre em todas as abas' : '');
});

// Sincroniza estado do botao fixar
storageGet(['sempreFixa']).then(d => {
  const ativo = !!d.sempreFixa;
  btnFixar.classList.toggle('ativo', ativo);
  atualizarTooltipFixar(ativo);
});

// ============== INICIO ==============
// Pinguim SVG inline — simples, branco/preto, anima via classes do components.css
const PINGUIM_SVG = `
<svg class="px-pinguim-load__svg" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <!-- corpo -->
  <ellipse class="body" cx="32" cy="38" rx="18" ry="22" fill="#fafafa"/>
  <!-- barriga -->
  <ellipse class="body" cx="32" cy="42" rx="12" ry="16" fill="#0a0a0a"/>
  <!-- cabeca -->
  <circle class="body" cx="32" cy="22" r="13" fill="#fafafa"/>
  <!-- olhos -->
  <circle cx="27" cy="22" r="2" fill="#0a0a0a"/>
  <circle cx="37" cy="22" r="2" fill="#0a0a0a"/>
  <!-- bico -->
  <path d="M30 27 L34 27 L32 30 Z" fill="#0a0a0a"/>
  <!-- pezinho -->
  <ellipse cx="26" cy="58" rx="4" ry="1.5" fill="#fafafa"/>
  <ellipse cx="38" cy="58" rx="4" ry="1.5" fill="#fafafa"/>
</svg>
`;

function renderPinguimLoad(mensagem = 'Carregando...', meta = '') {
  conteudo.innerHTML = '';
  const wrap = el('div', { class: 'px-pinguim-load' });
  const svgWrap = el('div', { html: PINGUIM_SVG });
  wrap.append(svgWrap.firstElementChild);
  wrap.append(el('div', { class: 'px-pinguim-load__msg' }, mensagem));
  if (meta) wrap.append(el('div', { class: 'px-pinguim-load__meta' }, meta));
  conteudo.append(wrap);
}

function renderCarregando() {
  setStatus('Verificando sessao...');
  renderPinguimLoad('Verificando sua sessão', '');
}

async function init() {
  renderCarregando();
  await carregarSessao();

  // Pega texto pendente do context menu
  const data = await storageGet(['textoPendente', 'textoPendenteEm']);
  if (data.textoPendente && data.textoPendenteEm && Date.now() - data.textoPendenteEm < 60000) {
    textoPendente = data.textoPendente;
  } else if (data.textoPendente) {
    await storageRemove(['textoPendente', 'textoPendenteOrigem', 'textoPendenteEm']);
  }

  if (session?.access_token) {
    renderNavCategorias();
    // Se veio com texto pendente (menu de contexto), vai direto pro Chat — caso contrario, mostra Home
    if (textoPendente) {
      irPara('chat');
    } else {
      irPara('home');
    }
  } else {
    renderNavCategorias();
    renderLogin();
  }
}

// ============================================================
// v0.25.0 — MODAIS OPERACIONAIS (não-chat, formulário estruturado)
// ============================================================
// Roteamento: renderChat detecta agente com capabilities.tipo='operacional'
// e chama abrirModalOperacional. Cada modal_slug aponta pra uma função.
// ============================================================

function abrirModalOperacional(agente) {
  const cap = agente.capabilities || {};
  const slug = cap.modal_slug;
  if (slug === 'cadastrar-editar-sirius') return abrirModalSiriusGestao(agente);
  if (slug === 'cadastrar-editar-proalt') return abrirModalProAltGestao(agente);
  if (slug === 'cadastrar-editar-elo') return abrirModalEloGestao(agente);
  if (slug === 'analise-perfil-instagram') return abrirModalAnalisePerfilIG(agente);
  if (slug === 'triar-email-workspace') return abrirModalTriarEmail(agente);
  // Fallback (não deveria acontecer)
  console.warn('[modal-operacional] slug desconhecido:', slug);
  renderCategoriaAtual();
}

// ============================================================
// MODAL: Cadastrar/Editar Sirius
// ============================================================
async function abrirModalSiriusGestao(agente) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:680px;max-height:94vh;overflow-y:auto' });

  // Header
  box.append(el('div', { style: 'display:flex;align-items:center;gap:10px;margin-bottom:8px' }, [
    el('div', { style: 'font-size:28px' }, '🔓'),
    el('div', {}, [
      el('h3', { class: 'modal-pinguim-titulo', style: 'margin:0' }, 'Cadastrar/Editar Sirius'),
      el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Gestão completa de usuários da Sirius — plano, vigência, funcionalidades, créditos.'),
    ]),
  ]));

  // Toast inline pra feedback
  let toastEl = null;
  function toast(msg, tipo = 'info') {
    if (!toastEl) {
      toastEl = el('div', { style: 'position:sticky;top:0;margin:0 0 12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4' });
      box.insertBefore(toastEl, box.firstChild.nextSibling);
    }
    const cores = {
      info: 'background:rgba(64,134,237,0.12);border:1px solid rgba(64,134,237,0.3);color:#7fb3ff',
      ok: 'background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);color:#86efac',
      erro: 'background:rgba(231,76,60,0.12);border:1px solid rgba(231,76,60,0.3);color:#ffb4ab',
    };
    toastEl.style.cssText = 'position:sticky;top:0;margin:0 0 12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4;' + (cores[tipo] || cores.info);
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
    clearTimeout(toastEl._t);
    if (tipo !== 'erro') toastEl._t = setTimeout(() => { toastEl.style.display = 'none'; }, 6000);
  }

  // Helper pra chamar Edge tool-gestao-sirius
  async function callSirius(action, body = {}) {
    const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-gestao-sirius`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action, ...body }),
    });
    if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);
    return r.body;
  }

  // Estado do form
  let modoEdicao = false;        // false = cadastro, true = edição
  let usuarioAtual = null;        // dados do usuário sendo editado (null no cadastro)
  let planos = [];                // catálogo de planos da Sirius

  // ============= BUSCA NO TOPO =============
  const buscaWrap = el('div', { style: 'background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);padding:10px;margin-bottom:12px' });
  buscaWrap.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:6px' }, '🔍 Buscar usuário existente (email, nome ou telefone)'));
  const buscaRow = el('div', { style: 'display:flex;gap:6px' });
  const inputBusca = el('input', {
    type: 'text',
    placeholder: 'Ex: joao@email.com, João Silva, 5511...',
    style: 'flex:1;padding:8px 10px;background:var(--cor-fundo);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px',
  });
  const btnBuscar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Buscar');
  buscaRow.append(inputBusca, btnBuscar);
  buscaWrap.append(buscaRow);
  const resultadosBusca = el('div', { style: 'margin-top:8px' });
  buscaWrap.append(resultadosBusca);
  box.append(buscaWrap);

  // ============= ABAS =============
  const tabsNav = el('div', { style: 'display:flex;gap:4px;margin-bottom:12px;border-bottom:1px solid var(--cor-borda)' });
  const tabsConteudo = el('div', {});
  let tabAtivaIdx = 0; // indice da aba ativa (0..N-1)
  const tabsBtns = []; // lista de botoes das abas (pra navegar Proximo/Anterior)
  function criarTab(label, conteudoEl) {
    const btn = el('button', {
      type: 'button',
      style: 'background:transparent;border:none;color:var(--cor-texto-2);font-size:13px;padding:8px 14px;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px',
    }, label);
    btn._conteudo = conteudoEl;
    btn._idx = tabsBtns.length;
    btn.addEventListener('click', () => ativarTab(btn));
    tabsNav.append(btn);
    tabsBtns.push(btn);
    conteudoEl.style.display = 'none';
    tabsConteudo.append(conteudoEl);
    return btn;
  }
  function ativarTab(btn) {
    tabAtivaIdx = btn._idx;
    // atualizarBotoesNavegacao só existe após declaração dos botões — checa.
    if (typeof atualizarBotoesNavegacao === 'function') {
      try { atualizarBotoesNavegacao(); } catch (_) { /* TDZ se chamado antes da declaração */ }
    }
    for (const b of tabsNav.children) {
      const ativo = b === btn;
      b.style.color = ativo ? 'var(--cor-acento)' : 'var(--cor-texto-2)';
      b.style.borderBottomColor = ativo ? 'var(--cor-acento)' : 'transparent';
      b.style.fontWeight = ativo ? '600' : '400';
      b._conteudo.style.display = ativo ? 'block' : 'none';
    }
  }

  // ---- Aba 1: Dados pessoais ----
  const aba1 = el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:10px' });
  const inpNome = inputField('Nome completo *', 'João Silva');
  const inpEmail = inputField('Email *', 'joao@empresa.com', 'email');
  const inpTelefone = inputField('Telefone (WhatsApp)', '+55 11 91234-5678');
  const inpFuncao = inputField('Função', 'Diretor de Marketing');
  const inpAvatar = inputField('Avatar URL', 'https://...');
  const selIdioma = selectField('Idioma', [
    { v: 'pt', t: 'Português' }, { v: 'en', t: 'English' }, { v: 'es', t: 'Español' },
  ], 'pt');
  aba1.append(inpNome.wrap, inpEmail.wrap, inpTelefone.wrap, inpFuncao.wrap, inpAvatar.wrap, selIdioma.wrap);

  // ---- Aba 2: Acesso ----
  const aba2 = el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:10px' });
  const selPapel = selectField('Papel *', [
    { v: 'user', t: 'user (padrão)' }, { v: 'manager', t: 'manager' }, { v: 'admin', t: 'admin' },
  ], 'user');
  const selPlano = selectField('Plano', [{ v: '', t: '— sem plano —' }], '');
  const inpVigencia = inputField('Vigência (último pagamento)', '2026-05-29', 'date');
  const inpSenha = inputField('Senha inicial *', 'mínimo 8 chars', 'password');
  const btnGerarSenha = el('button', { class: 'modal-pinguim-btn', type: 'button', style: 'margin-top:6px;font-size:11px;padding:4px 10px;height:auto' }, '🎲 Gerar senha forte');
  btnGerarSenha.addEventListener('click', () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%';
    let s = '';
    for (let i = 0; i < 14; i++) s += chars[Math.floor(Math.random() * chars.length)];
    inpSenha.input.value = s;
    inpSenha.input.type = 'text';
  });
  inpSenha.wrap.append(btnGerarSenha);
  const inpTokenOverride = inputField('Token limit override', 'opcional', 'number');
  const inpScriptOverride = inputField('Script limit override', 'opcional', 'number');
  aba2.append(selPapel.wrap, selPlano.wrap, inpVigencia.wrap, inpSenha.wrap, inpTokenOverride.wrap, inpScriptOverride.wrap);

  // ---- Aba 3: Funcionalidades (10 toggles em português) ----
  const FEATURES_PT = [
    ['access_personas', 'Personas'],
    ['access_viral_scripts', 'Roteiros Virais'],
    ['access_products', 'Produtos'],
    ['access_headlines', 'Headlines'],
    ['access_marketing_creatives', 'Criativos de Marketing'],
    ['access_challenges', 'Desafios'],
    ['access_challenge_templates', 'Templates de Desafio'],
    ['access_templates', 'Templates'],
    ['access_stories', 'Stories'],
    ['access_analysis', 'Análises'],
  ];
  const aba3 = el('div', {});
  aba3.append(el('div', { class: 'px-meta', style: 'margin-bottom:10px;font-size:11px' },
    'Ao trocar o plano, os toggles são pré-preenchidos com os defaults. Você pode liberar ou tirar manualmente.'));
  const togglesGrid = el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:8px' });
  const toggleInputs = {};
  for (const [key, label] of FEATURES_PT) {
    const lab = el('label', {
      style: 'display:flex;gap:8px;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer;align-items:center',
    });
    const cb = el('input', { type: 'checkbox', style: 'margin:0;accent-color:var(--cor-acento)' });
    cb.addEventListener('change', () => {
      lab.style.borderColor = cb.checked ? 'var(--cor-acento)' : 'var(--cor-borda)';
    });
    toggleInputs[key] = cb;
    lab.append(cb, el('span', { style: 'font-size:12px' }, label));
    togglesGrid.append(lab);
  }
  aba3.append(togglesGrid);

  const tab1 = criarTab('Dados pessoais', aba1);
  const tab2 = criarTab('Acesso', aba2);
  const tab3 = criarTab('Funcionalidades', aba3);
  // v0.25.4 — NÃO ativa tab1 ainda! Precisa esperar declaração dos botões
  // (btnAnterior, btnProximo, btnSalvar) abaixo, senão TDZ ReferenceError.
  // Tab1 é ativada manualmente após declaração dos botões + atualizarBotoesNavegacao.

  box.append(tabsNav, tabsConteudo);

  // ============= AÇÕES DO RODAPÉ =============
  const acoesEdicao = el('div', {
    style: 'display:none;border-top:1px solid var(--cor-borda);margin-top:14px;padding-top:12px;display:none;flex-wrap:wrap;gap:6px',
  });
  // (mostrado só em modo edição)
  acoesEdicao.append(
    btnSec('💰 Adicionar créditos', async () => {
      const amount = parseInt(prompt('Quantos créditos adicionar?'), 10);
      if (!amount || amount <= 0) return;
      const reason = prompt('Motivo:', 'Bônus concedido via Pinguim');
      if (!reason) return;
      try { await callSirius('adicionar_creditos', { user_id: usuarioAtual.user_id, amount, reason }); toast(`✓ ${amount} créditos adicionados`, 'ok'); }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }),
    btnSec('🔒 Resetar senha', async () => {
      const nova = prompt('Nova senha (mínimo 8 chars):');
      if (!nova || nova.length < 8) { toast('Senha inválida (mínimo 8)', 'erro'); return; }
      try { await callSirius('resetar_senha', { user_id: usuarioAtual.user_id, new_password: nova }); toast('✓ Senha resetada', 'ok'); }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }),
    btnSec('✉️ Trocar email', async () => {
      const novo = prompt('Novo email:', usuarioAtual?.email || '');
      if (!novo || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(novo)) { toast('Email inválido', 'erro'); return; }
      try { await callSirius('trocar_email', { user_id: usuarioAtual.user_id, new_email: novo }); toast('✓ Email trocado pra ' + novo, 'ok'); usuarioAtual.email = novo; inpEmail.input.value = novo; }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }),
    btnSec('🚫 Desativar', async () => {
      if (!confirm('Desativar este usuário (plan_status=cancelled)?')) return;
      try { await callSirius('desativar', { user_id: usuarioAtual.user_id }); toast('✓ Usuário desativado', 'ok'); }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }, 'aviso'),
    btnSec('🗑 Excluir', async () => {
      if (!confirm(`EXCLUIR DEFINITIVAMENTE o usuário ${usuarioAtual?.email}? Esta ação é IRREVERSÍVEL.`)) return;
      if (!confirm('Confirma de novo (última chance)?')) return;
      try { await callSirius('excluir', { user_id: usuarioAtual.user_id }); toast('✓ Usuário excluído', 'ok'); setTimeout(() => overlay.remove(), 1500); }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }, 'destrutivo'),
  );
  box.append(acoesEdicao);

  // ============= BOTÕES PRINCIPAIS =============
  // Navegação por abas: aba 1/2 = "Próximo →", aba final = "✓ Criar usuário" (ou "💾 Salvar" em edição)
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap' });
  const lado1 = el('div', { style: 'display:flex;gap:6px' });
  const lado2 = el('div', { style: 'display:flex;gap:6px' });
  const btnFechar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  const btnAnterior = el('button', { class: 'modal-pinguim-btn', type: 'button' }, '← Anterior');
  btnAnterior.addEventListener('click', () => { if (tabAtivaIdx > 0) ativarTab(tabsBtns[tabAtivaIdx - 1]); });
  lado1.append(btnFechar, btnAnterior);

  const btnProximo = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, 'Próximo →');
  btnProximo.addEventListener('click', () => { if (tabAtivaIdx < tabsBtns.length - 1) ativarTab(tabsBtns[tabAtivaIdx + 1]); });
  const btnSalvar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, '✓ Criar usuário');
  btnSalvar.addEventListener('click', salvarUsuario);
  lado2.append(btnProximo, btnSalvar);

  acoes.append(lado1, lado2);
  box.append(acoes);

  // Atualiza visibilidade/texto dos botões conforme aba e modo (cadastro/edição)
  function atualizarBotoesNavegacao() {
    const ehUltimaAba = tabAtivaIdx === tabsBtns.length - 1;
    const ehPrimeiraAba = tabAtivaIdx === 0;
    btnAnterior.style.display = ehPrimeiraAba ? 'none' : '';
    btnProximo.style.display = ehUltimaAba ? 'none' : '';
    btnSalvar.style.display = ehUltimaAba ? '' : 'none';
    btnSalvar.textContent = modoEdicao ? '💾 Salvar alterações' : '✓ Criar usuário';
  }

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);

  // v0.25.4 — Agora SIM ativa a primeira aba. Os botões já foram declarados
  // (btnAnterior, btnProximo, btnSalvar), atualizarBotoesNavegacao já existe.
  ativarTab(tab1);

  // ============= LÓGICA =============

  // Helper: cria campo de input com label
  function inputField(label, placeholder, type = 'text') {
    const wrap = el('div', {});
    wrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, label));
    const input = el('input', {
      type, placeholder,
      style: 'width:100%;padding:7px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;box-sizing:border-box',
    });
    wrap.append(input);
    return { wrap, input };
  }
  function selectField(label, options, defaultV = '') {
    const wrap = el('div', {});
    wrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, label));
    const sel = el('select', {
      style: 'width:100%;padding:7px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;box-sizing:border-box',
    });
    for (const o of options) {
      const opt = el('option', { value: o.v }, o.t);
      if (o.v === defaultV) opt.selected = true;
      sel.append(opt);
    }
    wrap.append(sel);
    return { wrap, input: sel };
  }
  function btnSec(label, onClick, variante = 'normal') {
    const styles = {
      normal: 'background:var(--cor-fundo-2);color:var(--cor-texto);border:1px solid var(--cor-borda)',
      aviso: 'background:rgba(234,179,8,0.12);color:#fde047;border:1px solid rgba(234,179,8,0.3)',
      destrutivo: 'background:rgba(231,76,60,0.12);color:#ffb4ab;border:1px solid rgba(231,76,60,0.3)',
    };
    const b = el('button', {
      type: 'button',
      style: 'padding:6px 12px;border-radius:var(--raio-2);font-size:12px;cursor:pointer;' + styles[variante],
    }, label);
    b.addEventListener('click', onClick);
    return b;
  }

  // Carrega catálogo de planos
  async function carregarPlanos() {
    try {
      const r = await callSirius('listar_planos');
      planos = r.planos || [];
      // Popula select
      selPlano.input.innerHTML = '';
      selPlano.input.append(el('option', { value: '' }, '— sem plano —'));
      for (const p of planos) {
        const label = `${p.name} · ${p.currency} ${p.price} · ${p.cycle_type}`;
        const opt = el('option', { value: p.id }, label);
        selPlano.input.append(opt);
      }
    } catch (e) { toast('Falha ao carregar planos: ' + e.message, 'erro'); }
  }

  // Quando muda plano → reaplica defaults dos toggles
  selPlano.input.addEventListener('change', async () => {
    const planId = selPlano.input.value;
    if (!planId) return;
    const plano = planos.find(p => p.id === planId);
    if (!plano) return;
    try {
      const r = await callSirius('default_acesso', { plan_name: plano.name });
      const defaults = r.defaults || {};
      for (const [key, cb] of Object.entries(toggleInputs)) {
        cb.checked = !!defaults[key];
        cb.parentElement.style.borderColor = cb.checked ? 'var(--cor-acento)' : 'var(--cor-borda)';
      }
      toast(`Toggles atualizados pelo plano ${plano.name}`, 'info');
    } catch (e) { toast('Falha ao buscar defaults: ' + e.message, 'erro'); }
  });

  // Busca
  async function buscar() {
    const termo = inputBusca.value.trim();
    if (!termo || termo.length < 2) { toast('Digite ao menos 2 caracteres', 'erro'); return; }
    resultadosBusca.innerHTML = '';
    resultadosBusca.append(el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Buscando…'));
    try {
      const r = await callSirius('buscar_usuario', { termo });
      resultadosBusca.innerHTML = '';
      if (!r.usuarios?.length) {
        resultadosBusca.append(el('div', { class: 'px-meta', style: 'font-size:12px;padding:6px' }, '😶 Nenhum usuário encontrado'));
        return;
      }
      for (const u of r.usuarios) {
        const item = el('div', {
          style: 'padding:8px 10px;background:var(--cor-fundo);border:1px solid var(--cor-borda);border-radius:var(--raio-2);margin-bottom:4px;cursor:pointer;font-size:12px',
        });
        item.append(el('div', { style: 'font-weight:600' }, u.nome || '(sem nome)'));
        item.append(el('div', { class: 'px-meta', style: 'font-size:11px;margin-top:2px' },
          `${u.email}${u.telefone ? ' · ' + u.telefone : ''}${u.plan_nome ? ' · ' + u.plan_nome : ''} · ${u.papel}`));
        item.addEventListener('click', () => carregarUsuarioParaEdicao(u.user_id));
        item.addEventListener('mouseenter', () => item.style.borderColor = 'var(--cor-acento)');
        item.addEventListener('mouseleave', () => item.style.borderColor = 'var(--cor-borda)');
        resultadosBusca.append(item);
      }
    } catch (e) {
      resultadosBusca.innerHTML = '';
      resultadosBusca.append(el('div', { style: 'color:var(--cor-aviso);font-size:12px;padding:6px' }, '✗ ' + e.message));
    }
  }
  btnBuscar.addEventListener('click', buscar);
  inputBusca.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); buscar(); } });

  // Carrega usuário pra edição
  async function carregarUsuarioParaEdicao(user_id) {
    try {
      const r = await callSirius('obter_usuario', { user_id });
      const u = r.usuario;
      usuarioAtual = u;
      modoEdicao = true;

      // Preenche form
      inpNome.input.value = u.nome || '';
      inpEmail.input.value = u.email || '';
      inpEmail.input.disabled = true; // email é trocado via botão dedicado
      inpTelefone.input.value = u.telefone || '';
      inpFuncao.input.value = u.funcao || '';
      inpAvatar.input.value = u.avatar_url || '';
      selIdioma.input.value = u.preferred_language || 'pt';
      selPapel.input.value = u.papel || 'user';
      selPlano.input.value = u.plan_id || '';
      inpVigencia.input.value = u.last_payment_at ? u.last_payment_at.slice(0, 10) : '';
      inpSenha.wrap.style.display = 'none'; // senha só no cadastro
      inpTokenOverride.input.value = u.token_limit_override ?? '';
      inpScriptOverride.input.value = u.script_limit_override ?? '';
      for (const [key, cb] of Object.entries(toggleInputs)) {
        cb.checked = !!u[key];
        cb.parentElement.style.borderColor = cb.checked ? 'var(--cor-acento)' : 'var(--cor-borda)';
      }

      // Mostra ações de edição
      acoesEdicao.style.display = 'flex';
      resultadosBusca.innerHTML = '';
      inputBusca.value = '';
      atualizarBotoesNavegacao(); // re-aplica label "💾 Salvar alterações" se na última aba

      toast(`Editando: ${u.nome || u.email}`, 'info');
    } catch (e) { toast('Erro: ' + e.message, 'erro'); }
  }

  // Salvar (criar ou editar)
  async function salvarUsuario() {
    btnSalvar.disabled = true;
    const labelOriginal = btnSalvar.textContent;
    btnSalvar.textContent = modoEdicao ? 'Salvando…' : 'Criando…';
    try {
      const features = {};
      for (const [key, cb] of Object.entries(toggleInputs)) features[key] = cb.checked;

      if (modoEdicao) {
        // UPDATE
        const patch = {
          user_id: usuarioAtual.user_id,
          nome: inpNome.input.value.trim() || null,
          telefone: inpTelefone.input.value.trim() || null,
          funcao: inpFuncao.input.value.trim() || null,
          avatar_url: inpAvatar.input.value.trim() || null,
          preferred_language: selIdioma.input.value,
          papel: selPapel.input.value,
          plan_id: selPlano.input.value || null,
          last_payment_at: inpVigencia.input.value ? new Date(inpVigencia.input.value).toISOString() : null,
          token_limit_override: inpTokenOverride.input.value ? parseInt(inpTokenOverride.input.value, 10) : null,
          script_limit_override: inpScriptOverride.input.value ? parseInt(inpScriptOverride.input.value, 10) : null,
          ...features,
        };
        await callSirius('atualizar_usuario', patch);
        toast('✓ Usuário atualizado', 'ok');
      } else {
        // INSERT
        const email = inpEmail.input.value.trim();
        const senha = inpSenha.input.value;
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('Email inválido', 'erro'); btnSalvar.disabled = false; btnSalvar.textContent = labelOriginal; return; }
        if (!senha || senha.length < 8) { toast('Senha mínima 8 chars', 'erro'); btnSalvar.disabled = false; btnSalvar.textContent = labelOriginal; return; }
        if (!inpNome.input.value.trim()) { toast('Nome obrigatório', 'erro'); btnSalvar.disabled = false; btnSalvar.textContent = labelOriginal; return; }

        const r = await callSirius('criar_usuario', {
          email,
          password: senha,
          nome: inpNome.input.value.trim(),
          telefone: inpTelefone.input.value.trim() || null,
          funcao: inpFuncao.input.value.trim() || null,
          avatar_url: inpAvatar.input.value.trim() || null,
          preferred_language: selIdioma.input.value,
          papel: selPapel.input.value,
          plan_id: selPlano.input.value || null,
          vigencia_brt: inpVigencia.input.value ? new Date(inpVigencia.input.value).toISOString() : null,
          token_limit_override: inpTokenOverride.input.value ? parseInt(inpTokenOverride.input.value, 10) : null,
          script_limit_override: inpScriptOverride.input.value ? parseInt(inpScriptOverride.input.value, 10) : null,
          features,
        });
        toast(`✓ Usuário criado (id ${r.user_id?.slice(0, 8)}…)`, 'ok');
        // Carrega o usuário recém-criado em modo edição (pra ajustes posteriores)
        setTimeout(() => carregarUsuarioParaEdicao(r.user_id), 800);
      }
    } catch (e) {
      toast('Erro ao salvar: ' + e.message, 'erro');
    } finally {
      btnSalvar.disabled = false;
      btnSalvar.textContent = labelOriginal;
    }
  }

  // Bootstrap
  carregarPlanos();
}

// ============================================================
// MODAL: Cadastrar/Editar ProAlt
// ============================================================
// Versao SIMPLIFICADA do modal — ProAlt nao tem plano/features/creditos.
// Campos: nome, email, telefone, papel, senha.
async function abrirModalProAltGestao(agente) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:560px;max-height:94vh;overflow-y:auto' });

  // Header
  box.append(el('div', { style: 'display:flex;align-items:center;gap:10px;margin-bottom:12px' }, [
    el('div', { style: 'font-size:28px' }, '🔓'),
    el('div', {}, [
      el('h3', { class: 'modal-pinguim-titulo', style: 'margin:0' }, 'Cadastrar/Editar ProAlt'),
      el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Gestão de usuários da ProAlt — nome, email, telefone, papel, senha.'),
    ]),
  ]));

  // Toast
  let toastEl = null;
  function toast(msg, tipo = 'info') {
    if (!toastEl) {
      toastEl = el('div', { style: 'margin-bottom:12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4' });
      box.insertBefore(toastEl, box.firstChild.nextSibling);
    }
    const cores = {
      info: 'background:rgba(64,134,237,0.12);border:1px solid rgba(64,134,237,0.3);color:#7fb3ff',
      ok: 'background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);color:#86efac',
      erro: 'background:rgba(231,76,60,0.12);border:1px solid rgba(231,76,60,0.3);color:#ffb4ab',
    };
    toastEl.style.cssText = 'margin-bottom:12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4;' + (cores[tipo] || cores.info);
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
    clearTimeout(toastEl._t);
    if (tipo !== 'erro') toastEl._t = setTimeout(() => { toastEl.style.display = 'none'; }, 6000);
  }

  // Helper Edge
  async function callProAlt(action, body = {}) {
    const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-gestao-proalt`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action, ...body }),
    });
    if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);
    return r.body;
  }

  // Estado
  let modoEdicao = false;
  let usuarioAtual = null;

  // Helpers de input
  function inputField(label, placeholder, type = 'text') {
    const wrap = el('div', { style: 'margin-bottom:10px' });
    wrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, label));
    const input = el('input', {
      type, placeholder,
      style: 'width:100%;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;box-sizing:border-box',
    });
    wrap.append(input);
    return { wrap, input };
  }
  function selectField(label, options, defaultV = '') {
    const wrap = el('div', { style: 'margin-bottom:10px' });
    wrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, label));
    const sel = el('select', {
      style: 'width:100%;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;box-sizing:border-box',
    });
    for (const o of options) {
      const opt = el('option', { value: o.v }, o.t);
      if (o.v === defaultV) opt.selected = true;
      sel.append(opt);
    }
    wrap.append(sel);
    return { wrap, input: sel };
  }
  function btnSec(label, onClick, variante = 'normal') {
    const styles = {
      normal: 'background:var(--cor-fundo-2);color:var(--cor-texto);border:1px solid var(--cor-borda)',
      destrutivo: 'background:rgba(231,76,60,0.12);color:#ffb4ab;border:1px solid rgba(231,76,60,0.3)',
    };
    const b = el('button', {
      type: 'button',
      style: 'padding:6px 12px;border-radius:var(--raio-2);font-size:12px;cursor:pointer;' + styles[variante],
    }, label);
    b.addEventListener('click', onClick);
    return b;
  }

  // Busca topo
  const buscaWrap = el('div', { style: 'background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);padding:10px;margin-bottom:12px' });
  buscaWrap.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:6px' }, '🔍 Buscar usuário existente (email, nome ou telefone)'));
  const buscaRow = el('div', { style: 'display:flex;gap:6px' });
  const inputBusca = el('input', {
    type: 'text',
    placeholder: 'Ex: pedro@email.com, Pedro Aredes, 5511...',
    style: 'flex:1;padding:8px 10px;background:var(--cor-fundo);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px',
  });
  const btnBuscar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Buscar');
  buscaRow.append(inputBusca, btnBuscar);
  buscaWrap.append(buscaRow);
  const resultadosBusca = el('div', { style: 'margin-top:8px' });
  buscaWrap.append(resultadosBusca);
  box.append(buscaWrap);

  // Form (sem abas — ProAlt é simples)
  const inpNome = inputField('Nome completo *', 'Pedro Aredes');
  const inpEmail = inputField('Email *', 'pedro@empresa.com', 'email');
  const inpTelefone = inputField('Telefone (WhatsApp)', '+55 11 91234-5678');
  const selPapel = selectField('Papel *', [
    { v: 'user', t: 'user (padrão — aluno do ProAlt)' },
    { v: 'manager', t: 'manager (admin painel)' },
    { v: 'admin', t: 'admin (admin painel)' },
  ], 'user');
  const inpSenha = inputField('Senha inicial', 'Deixe vazio pra usar padrão "mudar@1234"', 'text');
  inpSenha.input.value = 'mudar@1234';

  box.append(inpNome.wrap, inpEmail.wrap, inpTelefone.wrap, selPapel.wrap, inpSenha.wrap);

  // Acoes de edicao (escondidas no cadastro)
  const acoesEdicao = el('div', {
    style: 'display:none;border-top:1px solid var(--cor-borda);margin-top:14px;padding-top:12px;flex-wrap:wrap;gap:6px',
  });
  acoesEdicao.append(
    btnSec('🔒 Resetar senha', async () => {
      const nova = prompt('Nova senha (mínimo 6 chars):', 'mudar@1234');
      if (!nova || nova.length < 6) { toast('Senha inválida', 'erro'); return; }
      try { await callProAlt('resetar_senha', { user_id: usuarioAtual.user_id, new_password: nova }); toast('✓ Senha resetada', 'ok'); }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }),
    btnSec('✉️ Trocar email', async () => {
      const novo = prompt('Novo email:', usuarioAtual?.email || '');
      if (!novo || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(novo)) { toast('Email inválido', 'erro'); return; }
      try { await callProAlt('trocar_email', { user_id: usuarioAtual.user_id, new_email: novo }); toast('✓ Email trocado pra ' + novo, 'ok'); usuarioAtual.email = novo; inpEmail.input.value = novo; }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }),
    btnSec('🗑 Excluir', async () => {
      if (!confirm(`EXCLUIR DEFINITIVAMENTE o usuário ${usuarioAtual?.email}? IRREVERSÍVEL.`)) return;
      if (!confirm('Confirma de novo (última chance)?')) return;
      try { await callProAlt('excluir', { user_id: usuarioAtual.user_id }); toast('✓ Usuário excluído', 'ok'); setTimeout(() => overlay.remove(), 1500); }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }, 'destrutivo'),
  );
  box.append(acoesEdicao);

  // Botoes principais
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap' });
  const btnFechar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  const btnSalvar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, '✓ Criar usuário');
  btnSalvar.addEventListener('click', salvarUsuario);
  acoes.append(btnFechar, btnSalvar);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);

  // Logica
  async function buscar() {
    const termo = inputBusca.value.trim();
    if (!termo || termo.length < 2) { toast('Digite ao menos 2 caracteres', 'erro'); return; }
    resultadosBusca.innerHTML = '';
    resultadosBusca.append(el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Buscando…'));
    try {
      const r = await callProAlt('buscar_usuario', { termo });
      resultadosBusca.innerHTML = '';
      if (!r.usuarios?.length) {
        resultadosBusca.append(el('div', { class: 'px-meta', style: 'font-size:12px;padding:6px' }, '😶 Nenhum usuário encontrado'));
        return;
      }
      for (const u of r.usuarios) {
        const item = el('div', {
          style: 'padding:8px 10px;background:var(--cor-fundo);border:1px solid var(--cor-borda);border-radius:var(--raio-2);margin-bottom:4px;cursor:pointer;font-size:12px',
        });
        item.append(el('div', { style: 'font-weight:600' }, u.full_name || '(sem nome)'));
        item.append(el('div', { class: 'px-meta', style: 'font-size:11px;margin-top:2px' },
          `${u.email}${u.phone ? ' · ' + u.phone : ''} · ${u.role}${u.access_count ? ' · ' + u.access_count + ' acessos' : ''}`));
        item.addEventListener('click', () => carregarUsuarioParaEdicao(u.user_id));
        item.addEventListener('mouseenter', () => item.style.borderColor = 'var(--cor-acento)');
        item.addEventListener('mouseleave', () => item.style.borderColor = 'var(--cor-borda)');
        resultadosBusca.append(item);
      }
    } catch (e) {
      resultadosBusca.innerHTML = '';
      resultadosBusca.append(el('div', { style: 'color:var(--cor-aviso);font-size:12px;padding:6px' }, '✗ ' + e.message));
    }
  }
  btnBuscar.addEventListener('click', buscar);
  inputBusca.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); buscar(); } });

  async function carregarUsuarioParaEdicao(user_id) {
    try {
      const r = await callProAlt('obter_usuario', { user_id });
      const u = r.usuario;
      usuarioAtual = u;
      modoEdicao = true;

      inpNome.input.value = u.full_name || '';
      inpEmail.input.value = u.email || '';
      inpEmail.input.disabled = true; // troca via botão
      inpTelefone.input.value = u.phone || '';
      selPapel.input.value = u.role || 'user';
      inpSenha.wrap.style.display = 'none';

      acoesEdicao.style.display = 'flex';
      btnSalvar.textContent = '💾 Salvar alterações';
      resultadosBusca.innerHTML = '';
      inputBusca.value = '';
      toast(`Editando: ${u.full_name || u.email}`, 'info');
    } catch (e) { toast('Erro: ' + e.message, 'erro'); }
  }

  async function salvarUsuario() {
    btnSalvar.disabled = true;
    const labelOriginal = btnSalvar.textContent;
    btnSalvar.textContent = modoEdicao ? 'Salvando…' : 'Criando…';
    try {
      if (modoEdicao) {
        await callProAlt('atualizar_usuario', {
          user_id: usuarioAtual.user_id,
          full_name: inpNome.input.value.trim() || null,
          phone: inpTelefone.input.value.trim() || null,
          role: selPapel.input.value,
        });
        toast('✓ Usuário atualizado', 'ok');
      } else {
        const email = inpEmail.input.value.trim();
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('Email inválido', 'erro'); return; }
        if (!inpNome.input.value.trim()) { toast('Nome obrigatório', 'erro'); return; }
        const senha = inpSenha.input.value.trim() || 'mudar@1234';

        const r = await callProAlt('criar_usuario', {
          email,
          password: senha,
          full_name: inpNome.input.value.trim(),
          phone: inpTelefone.input.value.trim() || null,
          role: selPapel.input.value,
        });
        toast(`✓ Usuário criado (id ${r.user_id?.slice(0, 8)}…) — senha: ${senha}`, 'ok');
        setTimeout(() => carregarUsuarioParaEdicao(r.user_id), 800);
      }
    } catch (e) {
      toast('Erro ao salvar: ' + e.message, 'erro');
    } finally {
      btnSalvar.disabled = false;
      btnSalvar.textContent = labelOriginal;
    }
  }
}

// ============================================================
// MODAL: Cadastrar/Editar Elo (3 abas — Dados pessoais, Acesso, Programa)
// ============================================================
async function abrirModalEloGestao(agente) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:680px;max-height:94vh;overflow-y:auto' });

  box.append(el('div', { style: 'display:flex;align-items:center;gap:10px;margin-bottom:8px' }, [
    el('div', { style: 'font-size:28px' }, '🔓'),
    el('div', {}, [
      el('h3', { class: 'modal-pinguim-titulo', style: 'margin:0' }, 'Cadastrar/Editar Elo'),
      el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Gestão de alunos do Elo — dados, plano, vigência, ciclo/semana, Instagram, elo_10k.'),
    ]),
  ]));

  let toastEl = null;
  function toast(msg, tipo = 'info') {
    if (!toastEl) {
      toastEl = el('div', { style: 'position:sticky;top:0;margin:0 0 12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4' });
      box.insertBefore(toastEl, box.firstChild.nextSibling);
    }
    const cores = {
      info: 'background:rgba(64,134,237,0.12);border:1px solid rgba(64,134,237,0.3);color:#7fb3ff',
      ok: 'background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);color:#86efac',
      erro: 'background:rgba(231,76,60,0.12);border:1px solid rgba(231,76,60,0.3);color:#ffb4ab',
    };
    toastEl.style.cssText = 'position:sticky;top:0;margin:0 0 12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4;' + (cores[tipo] || cores.info);
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
    clearTimeout(toastEl._t);
    if (tipo !== 'erro') toastEl._t = setTimeout(() => { toastEl.style.display = 'none'; }, 6000);
  }

  async function callElo(action, body = {}) {
    const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-gestao-elo`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${session.access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ action, ...body }),
    });
    if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);
    return r.body;
  }

  let modoEdicao = false;
  let usuarioAtual = null;

  // Helpers
  function inputField(label, placeholder, type = 'text') {
    const wrap = el('div', {});
    wrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, label));
    const input = el('input', {
      type, placeholder,
      style: 'width:100%;padding:7px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;box-sizing:border-box',
    });
    wrap.append(input);
    return { wrap, input };
  }
  function selectField(label, options, defaultV = '') {
    const wrap = el('div', {});
    wrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, label));
    const sel = el('select', {
      style: 'width:100%;padding:7px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;box-sizing:border-box',
    });
    for (const o of options) {
      const opt = el('option', { value: o.v }, o.t);
      if (o.v === defaultV) opt.selected = true;
      sel.append(opt);
    }
    wrap.append(sel);
    return { wrap, input: sel };
  }
  function btnSec(label, onClick, variante = 'normal') {
    const styles = {
      normal: 'background:var(--cor-fundo-2);color:var(--cor-texto);border:1px solid var(--cor-borda)',
      aviso: 'background:rgba(234,179,8,0.12);color:#fde047;border:1px solid rgba(234,179,8,0.3)',
      destrutivo: 'background:rgba(231,76,60,0.12);color:#ffb4ab;border:1px solid rgba(231,76,60,0.3)',
    };
    const b = el('button', {
      type: 'button',
      style: 'padding:6px 12px;border-radius:var(--raio-2);font-size:12px;cursor:pointer;' + styles[variante],
    }, label);
    b.addEventListener('click', onClick);
    return b;
  }

  // Busca topo
  const buscaWrap = el('div', { style: 'background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);padding:10px;margin-bottom:12px' });
  buscaWrap.append(el('div', { class: 'px-rotulo', style: 'margin-bottom:6px' }, '🔍 Buscar aluno existente (email, nome, telefone ou @instagram)'));
  const buscaRow = el('div', { style: 'display:flex;gap:6px' });
  const inputBusca = el('input', {
    type: 'text',
    placeholder: 'Ex: maria@email.com, Maria Silva, 5511..., mariasilva',
    style: 'flex:1;padding:8px 10px;background:var(--cor-fundo);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px',
  });
  const btnBuscar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Buscar');
  buscaRow.append(inputBusca, btnBuscar);
  buscaWrap.append(buscaRow);
  const resultadosBusca = el('div', { style: 'margin-top:8px' });
  buscaWrap.append(resultadosBusca);
  box.append(buscaWrap);

  // Abas
  const tabsNav = el('div', { style: 'display:flex;gap:4px;margin-bottom:12px;border-bottom:1px solid var(--cor-borda)' });
  const tabsConteudo = el('div', {});
  let tabAtivaIdx = 0;
  const tabsBtns = [];
  function criarTab(label, conteudoEl) {
    const btn = el('button', {
      type: 'button',
      style: 'background:transparent;border:none;color:var(--cor-texto-2);font-size:13px;padding:8px 14px;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px',
    }, label);
    btn._conteudo = conteudoEl;
    btn._idx = tabsBtns.length;
    btn.addEventListener('click', () => ativarTab(btn));
    tabsNav.append(btn);
    tabsBtns.push(btn);
    conteudoEl.style.display = 'none';
    tabsConteudo.append(conteudoEl);
    return btn;
  }
  function ativarTab(btn) {
    tabAtivaIdx = btn._idx;
    if (typeof atualizarBotoesNavegacao === 'function') {
      try { atualizarBotoesNavegacao(); } catch (_) {}
    }
    for (const b of tabsNav.children) {
      const ativo = b === btn;
      b.style.color = ativo ? 'var(--cor-acento)' : 'var(--cor-texto-2)';
      b.style.borderBottomColor = ativo ? 'var(--cor-acento)' : 'transparent';
      b.style.fontWeight = ativo ? '600' : '400';
      b._conteudo.style.display = ativo ? 'block' : 'none';
    }
  }

  // ---- Aba 1: Dados pessoais ----
  const aba1 = el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:10px' });
  const inpNome = inputField('Nome curto *', 'Maria');
  const inpNomeCompleto = inputField('Nome completo', 'Maria Silva');
  const inpEmail = inputField('Email *', 'maria@empresa.com', 'email');
  const inpTelefone = inputField('Telefone (WhatsApp)', '+55 11 91234-5678');
  const inpInstagram = inputField('Instagram (sem @)', 'mariasilva');
  aba1.append(inpNome.wrap, inpNomeCompleto.wrap, inpEmail.wrap, inpTelefone.wrap, inpInstagram.wrap);

  // ---- Aba 2: Acesso ----
  const aba2 = el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:10px' });
  const selPapel = selectField('Papel *', [
    { v: 'aluno', t: 'aluno (padrão)' },
    { v: 'gs', t: 'gs (Growth Specialist)' },
    { v: 'mentor', t: 'mentor' },
    { v: 'admin', t: 'admin' },
  ], 'aluno');
  const inpPlano = inputField('Plano', 'Elo');
  inpPlano.input.value = 'Elo';
  const selStatus = selectField('Status do plano', [
    { v: 'active', t: 'active (ativo)' },
    { v: 'inactive', t: 'inactive (inativo)' },
    { v: 'cancelled', t: 'cancelled (cancelado)' },
  ], 'active');
  const inpVigencia = inputField('Vigência até', '', 'date');
  // Default vigência: hoje + 1 ano
  const v1 = new Date(); v1.setFullYear(v1.getFullYear() + 1);
  inpVigencia.input.value = v1.toISOString().slice(0, 10);
  const inpSenha = inputField('Senha inicial', 'Deixe vazio pra usar "mudar@1234"', 'text');
  inpSenha.input.value = 'mudar@1234';
  aba2.append(selPapel.wrap, inpPlano.wrap, selStatus.wrap, inpVigencia.wrap, inpSenha.wrap);

  // ---- Aba 3: Programa ----
  const aba3 = el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:10px' });
  const inpCiclo = inputField('Ciclo atual', '1', 'number');
  inpCiclo.input.value = '1'; inpCiclo.input.min = '1';
  const inpSemana = inputField('Semana atual (0 = ativação)', '0', 'number');
  inpSemana.input.value = '0'; inpSemana.input.min = '0'; inpSemana.input.max = '12';
  const inpSeguidores = inputField('Seguidores Instagram', 'opcional', 'number');
  // Toggle elo_10k
  const togWrap = el('div', { style: 'grid-column:span 2' });
  togWrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, 'Elo 10K (acesso à área especial)'));
  const togLabel = el('label', {
    style: 'display:flex;gap:8px;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);cursor:pointer;align-items:center',
  });
  const cb10k = el('input', { type: 'checkbox', style: 'margin:0;accent-color:var(--cor-acento)' });
  cb10k.addEventListener('change', () => {
    togLabel.style.borderColor = cb10k.checked ? 'var(--cor-acento)' : 'var(--cor-borda)';
  });
  togLabel.append(cb10k, el('span', { style: 'font-size:12px' }, '⭐ Liberar área Elo 10K'));
  togWrap.append(togLabel);
  aba3.append(inpCiclo.wrap, inpSemana.wrap, inpSeguidores.wrap, togWrap);

  const tab1 = criarTab('Dados pessoais', aba1);
  const tab2 = criarTab('Acesso', aba2);
  const tab3 = criarTab('Programa', aba3);

  box.append(tabsNav, tabsConteudo);

  // Ações de edição
  const acoesEdicao = el('div', {
    style: 'display:none;border-top:1px solid var(--cor-borda);margin-top:14px;padding-top:12px;flex-wrap:wrap;gap:6px',
  });
  acoesEdicao.append(
    btnSec('🔒 Resetar senha', async () => {
      const nova = prompt('Nova senha (mínimo 6 chars):', 'mudar@1234');
      if (!nova || nova.length < 6) { toast('Senha inválida', 'erro'); return; }
      try { await callElo('resetar_senha', { user_id: usuarioAtual.id, new_password: nova }); toast('✓ Senha resetada', 'ok'); }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }),
    btnSec('✉️ Trocar email', async () => {
      const novo = prompt('Novo email:', usuarioAtual?.email || '');
      if (!novo || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(novo)) { toast('Email inválido', 'erro'); return; }
      try { await callElo('trocar_email', { user_id: usuarioAtual.id, new_email: novo }); toast('✓ Email trocado pra ' + novo, 'ok'); usuarioAtual.email = novo; inpEmail.input.value = novo; }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }),
    btnSec('🚫 Desativar', async () => {
      if (!confirm('Desativar este aluno (plan_status=inactive)?')) return;
      try { await callElo('desativar', { user_id: usuarioAtual.id }); toast('✓ Aluno desativado', 'ok'); selStatus.input.value = 'inactive'; }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }, 'aviso'),
    btnSec('🗑 Excluir', async () => {
      if (!confirm(`EXCLUIR DEFINITIVAMENTE ${usuarioAtual?.email}? IRREVERSÍVEL.`)) return;
      if (!confirm('Confirma de novo (última chance)?')) return;
      try { await callElo('excluir', { user_id: usuarioAtual.id }); toast('✓ Aluno excluído', 'ok'); setTimeout(() => overlay.remove(), 1500); }
      catch (e) { toast('Erro: ' + e.message, 'erro'); }
    }, 'destrutivo'),
  );
  box.append(acoesEdicao);

  // Botões navegação
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap' });
  const lado1 = el('div', { style: 'display:flex;gap:6px' });
  const lado2 = el('div', { style: 'display:flex;gap:6px' });
  const btnFechar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  const btnAnterior = el('button', { class: 'modal-pinguim-btn', type: 'button' }, '← Anterior');
  btnAnterior.addEventListener('click', () => { if (tabAtivaIdx > 0) ativarTab(tabsBtns[tabAtivaIdx - 1]); });
  lado1.append(btnFechar, btnAnterior);

  const btnProximo = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, 'Próximo →');
  btnProximo.addEventListener('click', () => { if (tabAtivaIdx < tabsBtns.length - 1) ativarTab(tabsBtns[tabAtivaIdx + 1]); });
  const btnSalvar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, '✓ Criar aluno');
  btnSalvar.addEventListener('click', salvarUsuario);
  lado2.append(btnProximo, btnSalvar);

  acoes.append(lado1, lado2);
  box.append(acoes);

  function atualizarBotoesNavegacao() {
    const ehUltimaAba = tabAtivaIdx === tabsBtns.length - 1;
    const ehPrimeiraAba = tabAtivaIdx === 0;
    btnAnterior.style.display = ehPrimeiraAba ? 'none' : '';
    btnProximo.style.display = ehUltimaAba ? 'none' : '';
    btnSalvar.style.display = ehUltimaAba ? '' : 'none';
    btnSalvar.textContent = modoEdicao ? '💾 Salvar alterações' : '✓ Criar aluno';
  }

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);

  ativarTab(tab1);

  // Busca
  async function buscar() {
    const termo = inputBusca.value.trim();
    if (!termo || termo.length < 2) { toast('Digite ao menos 2 caracteres', 'erro'); return; }
    resultadosBusca.innerHTML = '';
    resultadosBusca.append(el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Buscando…'));
    try {
      const r = await callElo('buscar_usuario', { termo });
      resultadosBusca.innerHTML = '';
      if (!r.usuarios?.length) {
        resultadosBusca.append(el('div', { class: 'px-meta', style: 'font-size:12px;padding:6px' }, '😶 Nenhum aluno encontrado'));
        return;
      }
      for (const u of r.usuarios) {
        const item = el('div', {
          style: 'padding:8px 10px;background:var(--cor-fundo);border:1px solid var(--cor-borda);border-radius:var(--raio-2);margin-bottom:4px;cursor:pointer;font-size:12px',
        });
        item.append(el('div', { style: 'font-weight:600' }, (u.nome_completo || u.nome || '(sem nome)') + (u.elo_10k ? ' ⭐' : '')));
        item.append(el('div', { class: 'px-meta', style: 'font-size:11px;margin-top:2px' },
          `${u.email}${u.telefone ? ' · ' + u.telefone : ''}${u.instagram ? ' · @' + u.instagram : ''} · ${u.role} · sem ${u.semana_atual || 0}/ciclo ${u.ciclo_atual || 1}`));
        item.addEventListener('click', () => carregarUsuarioParaEdicao(u.id));
        item.addEventListener('mouseenter', () => item.style.borderColor = 'var(--cor-acento)');
        item.addEventListener('mouseleave', () => item.style.borderColor = 'var(--cor-borda)');
        resultadosBusca.append(item);
      }
    } catch (e) {
      resultadosBusca.innerHTML = '';
      resultadosBusca.append(el('div', { style: 'color:var(--cor-aviso);font-size:12px;padding:6px' }, '✗ ' + e.message));
    }
  }
  btnBuscar.addEventListener('click', buscar);
  inputBusca.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') { ev.preventDefault(); buscar(); } });

  async function carregarUsuarioParaEdicao(user_id) {
    try {
      const r = await callElo('obter_usuario', { user_id });
      const u = r.usuario;
      usuarioAtual = u;
      modoEdicao = true;

      inpNome.input.value = u.nome || '';
      inpNomeCompleto.input.value = u.nome_completo || '';
      inpEmail.input.value = u.email || '';
      inpEmail.input.disabled = true;
      inpTelefone.input.value = u.telefone || '';
      inpInstagram.input.value = u.instagram || '';
      selPapel.input.value = u.role || 'aluno';
      inpPlano.input.value = u.plano || 'Elo';
      selStatus.input.value = u.plan_status || 'active';
      inpVigencia.input.value = u.vigencia_ate ? u.vigencia_ate.slice(0, 10) : '';
      inpSenha.wrap.style.display = 'none';
      inpCiclo.input.value = u.ciclo_atual ?? 1;
      inpSemana.input.value = u.semana_atual ?? 0;
      inpSeguidores.input.value = u.seguidores ?? '';
      cb10k.checked = !!u.elo_10k;
      cb10k.parentElement.style.borderColor = cb10k.checked ? 'var(--cor-acento)' : 'var(--cor-borda)';

      acoesEdicao.style.display = 'flex';
      resultadosBusca.innerHTML = '';
      inputBusca.value = '';
      atualizarBotoesNavegacao();
      toast(`Editando: ${u.nome_completo || u.nome || u.email}`, 'info');
    } catch (e) { toast('Erro: ' + e.message, 'erro'); }
  }

  async function salvarUsuario() {
    btnSalvar.disabled = true;
    const labelOriginal = btnSalvar.textContent;
    btnSalvar.textContent = modoEdicao ? 'Salvando…' : 'Criando…';
    try {
      const baseCampos = {
        nome: inpNome.input.value.trim() || null,
        nome_completo: inpNomeCompleto.input.value.trim() || inpNome.input.value.trim() || null,
        telefone: inpTelefone.input.value.trim() || null,
        instagram: inpInstagram.input.value.trim().replace(/^@/, '') || null,
        role: selPapel.input.value,
        plano: inpPlano.input.value.trim() || 'Elo',
        plan_status: selStatus.input.value,
        vigencia_ate: inpVigencia.input.value ? new Date(inpVigencia.input.value).toISOString() : null,
        ciclo_atual: parseInt(inpCiclo.input.value, 10) || 1,
        semana_atual: parseInt(inpSemana.input.value, 10) || 0,
        elo_10k: cb10k.checked,
        seguidores: inpSeguidores.input.value ? parseInt(inpSeguidores.input.value, 10) : null,
      };

      if (modoEdicao) {
        await callElo('atualizar_usuario', { user_id: usuarioAtual.id, ...baseCampos });
        toast('✓ Aluno atualizado', 'ok');
      } else {
        const email = inpEmail.input.value.trim();
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('Email inválido', 'erro'); btnSalvar.disabled = false; btnSalvar.textContent = labelOriginal; return; }
        if (!baseCampos.nome) { toast('Nome obrigatório', 'erro'); btnSalvar.disabled = false; btnSalvar.textContent = labelOriginal; return; }
        const senha = inpSenha.input.value.trim() || 'mudar@1234';

        const r = await callElo('criar_usuario', { email, password: senha, ...baseCampos });
        toast(`✓ Aluno criado (id ${r.user_id?.slice(0, 8)}…) — senha: ${senha}`, 'ok');
        setTimeout(() => carregarUsuarioParaEdicao(r.user_id), 800);
      }
    } catch (e) {
      toast('Erro ao salvar: ' + e.message, 'erro');
    } finally {
      btnSalvar.disabled = false;
      btnSalvar.textContent = labelOriginal;
    }
  }
}

// ============================================================
// MODAL: Análise de Perfil Instagram (Raio-X)
// ============================================================
async function abrirModalAnalisePerfilIG(agente) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:560px;max-height:94vh;overflow-y:auto' });

  // Header
  box.append(el('div', { style: 'display:flex;align-items:center;gap:10px;margin-bottom:12px' }, [
    el('div', { style: 'font-size:28px' }, '🔍'),
    el('div', {}, [
      el('h3', { class: 'modal-pinguim-titulo', style: 'margin:0' }, 'Raio-X de Perfil Instagram'),
      el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Diagnóstico estratégico completo: bio, posts (top/worst), oportunidades, riscos.'),
    ]),
  ]));

  // Aviso de custo
  box.append(el('div', {
    style: 'background:rgba(232,92,0,0.08);border:1px solid rgba(232,92,0,0.3);border-radius:var(--raio-2);padding:10px 12px;margin-bottom:14px;font-size:11px;color:#FB923C;line-height:1.5',
  }, '⚠ Análise demora ~60-90s e custa ~$1 USD (Apify + GPT-4o + Whisper). Use com critério.'));

  let toastEl = null;
  function toast(msg, tipo = 'info') {
    if (!toastEl) {
      toastEl = el('div', { style: 'margin-bottom:12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4' });
      box.insertBefore(toastEl, box.firstChild.nextSibling);
    }
    const cores = {
      info: 'background:rgba(64,134,237,0.12);border:1px solid rgba(64,134,237,0.3);color:#7fb3ff',
      ok: 'background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);color:#86efac',
      erro: 'background:rgba(231,76,60,0.12);border:1px solid rgba(231,76,60,0.3);color:#ffb4ab',
    };
    toastEl.style.cssText = 'margin-bottom:12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4;' + (cores[tipo] || cores.info);
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
  }

  function inputField(label, placeholder, type = 'text') {
    const wrap = el('div', { style: 'margin-bottom:12px' });
    wrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, label));
    const input = el('input', {
      type, placeholder,
      style: 'width:100%;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;box-sizing:border-box',
    });
    wrap.append(input);
    return { wrap, input };
  }
  function selectField(label, options, defaultV = '') {
    const wrap = el('div', { style: 'margin-bottom:12px' });
    wrap.append(el('div', { style: 'font-size:11px;color:var(--cor-texto-2);margin-bottom:3px' }, label));
    const sel = el('select', {
      style: 'width:100%;padding:8px 10px;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);color:var(--cor-texto);font-size:13px;box-sizing:border-box',
    });
    for (const o of options) {
      const opt = el('option', { value: o.v }, o.t);
      if (o.v === defaultV) opt.selected = true;
      sel.append(opt);
    }
    wrap.append(sel);
    return { wrap, input: sel };
  }

  const inpHandle = inputField('Handle do Instagram (sem @) *', 'ex: dra.lilianalimongi');
  const inpNicho = inputField('Nicho do perfil *', 'ex: saúde da mulher (menopausa, hormônios)');
  const selObjetivo = selectField('Objetivo do perfil', [
    { v: 'autoridade', t: 'Autoridade (default)' },
    { v: 'crescer', t: 'Crescer audiência' },
    { v: 'vender', t: 'Vender' },
    { v: 'engajar', t: 'Engajar' },
    { v: 'consistencia', t: 'Consistência' },
  ], 'autoridade');

  box.append(inpHandle.wrap, inpNicho.wrap, selObjetivo.wrap);

  // Painel de progresso (escondido inicialmente)
  const progresso = el('div', { style: 'display:none;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);padding:14px;margin-top:8px' });
  const progTitulo = el('div', { style: 'font-size:13px;font-weight:600;color:var(--cor-acento);margin-bottom:8px' }, '🔄 Pipeline rodando...');
  const progEtapa = el('div', { style: 'font-size:12px;color:var(--cor-texto-2);line-height:1.6' });
  const progTempo = el('div', { style: 'font-size:11px;color:var(--cor-texto-3);margin-top:6px;font-family:monospace' });
  progresso.append(progTitulo, progEtapa, progTempo);
  box.append(progresso);

  // Botões
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap' });
  const btnFechar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  const btnAnalisar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, '🔍 Iniciar análise');
  acoes.append(btnFechar, btnAnalisar);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);

  btnAnalisar.addEventListener('click', async () => {
    const handle = inpHandle.input.value.trim().replace(/^@/, '').toLowerCase();
    const nicho = inpNicho.input.value.trim();
    const objetivo = selObjetivo.input.value;
    if (!handle || !/^[a-zA-Z0-9._]{1,30}$/.test(handle)) { toast('Handle inválido (a-z, 0-9, ponto, underscore)', 'erro'); return; }
    if (!nicho) { toast('Nicho obrigatório', 'erro'); return; }

    btnAnalisar.disabled = true;
    btnAnalisar.textContent = 'Analisando...';
    progresso.style.display = 'block';
    progEtapa.textContent = '📡 Buscando perfil via Apify (pode levar 30-60s)...';

    // Cronômetro
    const tInicio = Date.now();
    const cronTimer = setInterval(() => {
      const s = Math.round((Date.now() - tInicio) / 1000);
      progTempo.textContent = `Decorrido: ${s}s · estimativa total: 60-90s`;
      if (s === 30) progEtapa.textContent = '🎤 Transcrevendo áudios via Whisper...';
      if (s === 50) progEtapa.textContent = '🧠 Rodando análises (Bio + Posts + Overview) em paralelo...';
      if (s === 70) progEtapa.textContent = '📊 Analisando posts intermediários...';
      if (s === 85) progEtapa.textContent = '🎨 Renderizando HTML...';
    }, 1000);

    try {
      const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-analise-perfil-ig`, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ handle, nicho, objetivo }),
      });
      clearInterval(cronTimer);
      if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);

      // Sucesso — mostra tela de download
      const html = r.body.html;
      const duration = r.body.duration_seconds;

      progresso.style.display = 'none';
      // Esconde inputs
      inpHandle.wrap.style.display = 'none';
      inpNicho.wrap.style.display = 'none';
      selObjetivo.wrap.style.display = 'none';

      // Resultado
      const resultado = el('div', { style: 'background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.3);border-radius:var(--raio-2);padding:20px;text-align:center' });
      resultado.append(el('div', { style: 'font-size:48px;margin-bottom:8px' }, '✓'));
      resultado.append(el('div', { style: 'font-size:16px;font-weight:600;margin-bottom:4px' }, 'Raio-X gerado com sucesso'));
      resultado.append(el('div', { class: 'px-meta', style: 'font-size:12px;margin-bottom:14px' }, `@${handle} · ${duration}s · ${Math.round(html.length / 1024)} KB`));

      const btnDownload = el('button', {
        class: 'modal-pinguim-btn modal-pinguim-btn-primary',
        style: 'font-size:14px;padding:10px 20px',
      }, '📥 Baixar HTML');
      btnDownload.addEventListener('click', () => {
        const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `raio-x-${handle}.html`;
        a.click();
        URL.revokeObjectURL(url);
      });

      const btnAbrir = el('button', {
        class: 'modal-pinguim-btn',
        style: 'font-size:14px;padding:10px 20px;margin-left:8px',
      }, '👁 Abrir no browser');
      btnAbrir.addEventListener('click', () => {
        const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        window.open(url, '_blank');
      });

      resultado.append(btnDownload, btnAbrir);
      box.append(resultado);
      acoes.style.display = 'none';
    } catch (e) {
      clearInterval(cronTimer);
      progresso.style.display = 'none';
      btnAnalisar.disabled = false;
      btnAnalisar.textContent = '🔍 Iniciar análise';
      toast('Erro: ' + e.message, 'erro');
    }
  });
}

// ============================================================
// MODAL: Triar minha caixa de email (Workspace)
// ============================================================
async function abrirModalTriarEmail(agente) {
  const overlay = el('div', { class: 'modal-pinguim' });
  const box = el('div', { class: 'modal-pinguim-box', style: 'max-width:560px;max-height:94vh;overflow-y:auto' });

  // Header
  box.append(el('div', { style: 'display:flex;align-items:center;gap:10px;margin-bottom:12px' }, [
    el('div', { style: 'font-size:28px' }, '📧'),
    el('div', {}, [
      el('h3', { class: 'modal-pinguim-titulo', style: 'margin:0' }, 'Triar minha caixa'),
      el('div', { class: 'px-meta', style: 'font-size:11px' }, 'Emails das últimas 24h em 6 baldes de ação + Top 3 prioridades.'),
    ]),
  ]));

  // Aviso custo
  box.append(el('div', {
    style: 'background:rgba(232,92,0,0.08);border:1px solid rgba(232,92,0,0.3);border-radius:var(--raio-2);padding:10px 12px;margin-bottom:14px;font-size:11px;color:#FB923C;line-height:1.5',
  }, '⚠ Análise demora ~15-25s e custa ~$0.05-0.10 (GPT-4o). Usa sua conta Google já conectada.'));

  let toastEl = null;
  function toast(msg, tipo = 'info') {
    if (!toastEl) {
      toastEl = el('div', { style: 'margin-bottom:12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4' });
      box.insertBefore(toastEl, box.firstChild.nextSibling);
    }
    const cores = {
      info: 'background:rgba(64,134,237,0.12);border:1px solid rgba(64,134,237,0.3);color:#7fb3ff',
      ok: 'background:rgba(34,197,94,0.12);border:1px solid rgba(34,197,94,0.3);color:#86efac',
      erro: 'background:rgba(231,76,60,0.12);border:1px solid rgba(231,76,60,0.3);color:#ffb4ab',
    };
    toastEl.style.cssText = 'margin-bottom:12px;padding:10px 12px;border-radius:var(--raio-2);font-size:12px;line-height:1.4;' + (cores[tipo] || cores.info);
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
  }

  // Painel de listagem de contas (caso sócio tenha múltiplas)
  const infoConta = el('div', { style: 'background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);padding:12px;margin-bottom:14px;font-size:12px;color:var(--cor-texto-2)' }, 'Carregando sua conexão Google…');
  box.append(infoConta);

  // Estado: conexão escolhida
  let conexaoEscolhida = null;
  let contasDisponiveis = [];

  // Painel de progresso
  const progresso = el('div', { style: 'display:none;background:var(--cor-fundo-2);border:1px solid var(--cor-borda);border-radius:var(--raio-2);padding:14px;margin-top:8px' });
  const progTitulo = el('div', { style: 'font-size:13px;font-weight:600;color:var(--cor-acento);margin-bottom:8px' }, '🔄 Pipeline rodando...');
  const progEtapa = el('div', { style: 'font-size:12px;color:var(--cor-texto-2);line-height:1.6' });
  const progTempo = el('div', { style: 'font-size:11px;color:var(--cor-texto-3);margin-top:6px;font-family:monospace' });
  progresso.append(progTitulo, progEtapa, progTempo);
  box.append(progresso);

  // Botões
  const acoes = el('div', { class: 'modal-pinguim-botoes', style: 'justify-content:space-between;gap:8px;margin-top:14px;flex-wrap:wrap' });
  const btnFechar = el('button', { class: 'modal-pinguim-btn', type: 'button' }, 'Fechar');
  btnFechar.addEventListener('click', () => overlay.remove());
  const btnTriar = el('button', { class: 'modal-pinguim-btn modal-pinguim-btn-primary', type: 'button' }, '📧 Triar agora');
  btnTriar.disabled = true;
  acoes.append(btnFechar, btnTriar);
  box.append(acoes);

  overlay.append(box);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.append(overlay);

  // 1) Carrega contas disponíveis
  (async () => {
    try {
      const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-triar-email-sidebar`, {
        method: 'POST',
        headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'listar_contas', cliente_id: session.user.id }),
      });
      if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);
      contasDisponiveis = r.body.contas || [];
      if (contasDisponiveis.length === 0) {
        infoConta.style.background = 'rgba(231,76,60,0.08)';
        infoConta.style.borderColor = 'rgba(231,76,60,0.3)';
        infoConta.style.color = '#ffb4ab';
        infoConta.textContent = '⚠ Você não tem conta Google conectada. Acesse https://mission-control-pink-three.vercel.app/integracoes pra conectar antes.';
        return;
      }
      if (contasDisponiveis.length === 1) {
        conexaoEscolhida = contasDisponiveis[0];
        infoConta.innerHTML = '';
        infoConta.append(
          el('div', { style: 'font-weight:600;color:var(--cor-texto);font-size:13px;margin-bottom:4px' }, `📧 ${conexaoEscolhida.email_google}`),
          el('div', { style: 'font-size:11px;color:var(--cor-texto-2)' }, `Conta "${conexaoEscolhida.label}" ${conexaoEscolhida.is_padrao ? '· ⭐ padrão' : ''}`),
        );
        btnTriar.disabled = false;
        return;
      }
      // Múltiplas — mostra seletor
      infoConta.innerHTML = '';
      infoConta.append(el('div', { style: 'font-weight:600;color:var(--cor-texto);font-size:13px;margin-bottom:6px' }, '📧 Escolha a conta pra triar:'));
      for (const c of contasDisponiveis) {
        const opcao = el('label', {
          style: 'display:flex;gap:8px;align-items:center;padding:8px 10px;background:var(--cor-fundo);border:1px solid var(--cor-borda);border-radius:var(--raio-2);margin-top:6px;cursor:pointer',
        });
        const radio = el('input', { type: 'radio', name: 'conta-google', style: 'margin:0' });
        if (c.is_padrao) radio.checked = true;
        radio.addEventListener('change', () => {
          if (radio.checked) {
            conexaoEscolhida = c;
            btnTriar.disabled = false;
          }
        });
        if (c.is_padrao) {
          conexaoEscolhida = c;
          btnTriar.disabled = false;
        }
        opcao.append(radio, el('div', { style: 'flex:1' }, [
          el('div', { style: 'font-size:13px;color:var(--cor-texto)' }, c.email_google),
          el('div', { style: 'font-size:11px;color:var(--cor-texto-2)' }, `"${c.label}"${c.is_padrao ? ' · ⭐ padrão' : ''}`),
        ]));
        infoConta.append(opcao);
      }
    } catch (e) {
      infoConta.style.background = 'rgba(231,76,60,0.08)';
      infoConta.style.borderColor = 'rgba(231,76,60,0.3)';
      infoConta.style.color = '#ffb4ab';
      infoConta.textContent = '⚠ Erro ao listar contas: ' + e.message;
    }
  })();

  btnTriar.addEventListener('click', async () => {
    if (!conexaoEscolhida) { toast('Escolha uma conta', 'erro'); return; }
    btnTriar.disabled = true;
    btnTriar.textContent = 'Triando...';
    progresso.style.display = 'block';
    progEtapa.textContent = '📡 Buscando emails das últimas 24h...';

    const tInicio = Date.now();
    const cronTimer = setInterval(() => {
      const s = Math.round((Date.now() - tInicio) / 1000);
      progTempo.textContent = `Decorrido: ${s}s · estimativa: 15-25s`;
      if (s === 5) progEtapa.textContent = '📥 Carregando metadados de cada email...';
      if (s === 12) progEtapa.textContent = '🧠 Classificando em 6 baldes (GPT-4o)...';
      if (s === 20) progEtapa.textContent = '✨ Gerando Top 3 prioridades...';
    }, 1000);

    try {
      const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-triar-email-sidebar`, {
        method: 'POST',
        headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cliente_id: session.user.id,
          conexao_id: conexaoEscolhida.id,
        }),
      });
      clearInterval(cronTimer);
      if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);

      const json = r.body.json;
      const html = r.body.html;

      progresso.style.display = 'none';
      // Fecha o modal pequeno e abre o overlay grande da triagem inline
      overlay.remove();
      abrirOverlayTriagem({ json, htmlEstatico: html, conexao: conexaoEscolhida });
      return;
    } catch (e) {
      clearInterval(cronTimer);
      progresso.style.display = 'none';
      btnTriar.disabled = false;
      btnTriar.textContent = '📧 Triar agora';
      toast('Erro: ' + e.message, 'erro');
    }
  });
}

// ============================================================
// OVERLAY GRANDE — TRIAGEM EMAIL INLINE COM AÇÕES FUNCIONANDO
// ============================================================
// Recebe { json, htmlEstatico, conexao } e renderiza dentro do sidebar
// (overlay full-screen). Botões inline funcionam via Edge tool-acao-gmail.
// Botão "Baixar HTML" exporta versão estática (sem botões) pra arquivo.
// ============================================================
function abrirOverlayTriagem({ json, htmlEstatico, conexao }) {
  const overlay = el('div', {
    class: 'modal-pinguim',
    style: 'background:rgba(0,0,0,0.85);padding:0;align-items:flex-start',
  });
  const box = el('div', {
    style: 'background:#0A0A0A;width:100%;max-width:100%;height:100vh;overflow-y:auto;border-radius:0;padding:0;color:#EDEDED;font-family:-apple-system,system-ui,sans-serif',
  });
  overlay.append(box);

  // ============ HEADER STICKY ============
  const header = el('div', {
    style: 'position:sticky;top:0;z-index:10;background:#060606;border-bottom:1px solid #1F1F1F;padding:14px 20px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap',
  });
  const headerLeft = el('div', { style: 'min-width:0;flex:1' });
  headerLeft.append(
    el('div', { style: 'font-size:11px;letter-spacing:0.18em;text-transform:uppercase;color:#7E7E7E;font-family:monospace' }, `TRIAGEM · ${json.meta.email_conta}`),
    el('div', { style: 'font-size:14px;font-weight:600;margin-top:2px' }, `${json.meta.total_emails} emails · ${json.meta.duracao_s}s`),
  );
  const headerRight = el('div', { style: 'display:flex;gap:8px;flex-wrap:wrap' });

  const btnBaixar = el('button', {
    type: 'button',
    style: 'background:transparent;border:1px solid #2A2A2A;color:#B4B4B4;padding:6px 12px;border-radius:6px;font-size:11px;letter-spacing:0.05em;text-transform:uppercase;cursor:pointer;font-family:inherit',
  }, '📥 Baixar HTML');
  btnBaixar.addEventListener('click', () => {
    const blob = new Blob([htmlEstatico], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const dataStr = new Date().toISOString().slice(0, 10);
    a.download = `triagem-${dataStr}.html`;
    a.click();
    URL.revokeObjectURL(url);
  });

  const btnFechar = el('button', {
    type: 'button',
    style: 'background:#E85C00;border:0;color:#fff;padding:6px 14px;border-radius:6px;font-size:11px;letter-spacing:0.05em;text-transform:uppercase;cursor:pointer;font-weight:600;font-family:inherit',
  }, 'Fechar ✕');
  btnFechar.addEventListener('click', () => overlay.remove());

  headerRight.append(btnBaixar, btnFechar);
  header.append(headerLeft, headerRight);
  box.append(header);

  // ============ TOAST CONTAINER ============
  const toastContainer = el('div', {
    style: 'position:fixed;top:80px;right:20px;z-index:100;display:flex;flex-direction:column;gap:8px;max-width:380px',
  });
  document.body.append(toastContainer);

  function toast({ msg, tipo = 'sucesso', undoFn = null, duracao = 6000 }) {
    const cor = tipo === 'erro' ? '#EF4444' : '#4ADE80';
    const bg = tipo === 'erro' ? 'rgba(239,68,68,0.12)' : 'rgba(74,222,128,0.12)';
    const t = el('div', {
      style: `background:${bg};border:1px solid ${cor};color:#EDEDED;padding:10px 14px;border-radius:8px;font-size:13px;display:flex;justify-content:space-between;align-items:center;gap:12px;animation:slideIn 0.2s ease`,
    });
    const m = el('div', { style: 'flex:1', html: msg });
    const acoesT = el('div', { style: 'display:flex;gap:6px' });
    if (undoFn) {
      const btnU = el('button', {
        type: 'button',
        style: `background:transparent;border:1px solid ${cor};color:${cor};padding:3px 8px;border-radius:4px;font-size:11px;text-transform:uppercase;cursor:pointer;font-family:inherit;letter-spacing:0.05em`,
      }, 'Desfazer');
      btnU.addEventListener('click', () => { t.remove(); undoFn(); });
      acoesT.append(btnU);
    }
    const btnX = el('button', {
      type: 'button',
      style: 'background:transparent;border:0;color:#7E7E7E;cursor:pointer;font-size:14px',
    }, '✕');
    btnX.addEventListener('click', () => t.remove());
    acoesT.append(btnX);
    t.append(m, acoesT);
    toastContainer.append(t);
    setTimeout(() => t.remove(), duracao);
  }

  // ============ CORPO ============
  const corpo = el('div', { style: 'max-width:920px;margin:0 auto;padding:24px 20px' });

  // Stats no topo
  const totalRespHoje = json.baldes.find((b) => b.slug === 'responder_hoje')?.emails.length || 0;
  const totalPagar = json.baldes.find((b) => b.slug === 'pagar')?.emails.length || 0;
  const totalDecidir = json.baldes.find((b) => b.slug === 'decidir')?.emails.length || 0;
  const stats = el('div', { style: 'display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px' });
  function statCard(num, label, cor) {
    return el('div', { style: 'background:#121212;border:1px solid #1F1F1F;border-radius:10px;padding:14px;text-align:center' }, [
      el('div', { style: `font-size:24px;font-weight:600;color:${cor || '#E85C00'};letter-spacing:-0.02em` }, String(num)),
      el('div', { style: 'font-size:10px;letter-spacing:0.18em;text-transform:uppercase;color:#7E7E7E;margin-top:4px;font-family:monospace' }, label),
    ]);
  }
  stats.append(
    statCard(json.meta.total_emails, 'Total 24h', '#E85C00'),
    statCard(totalRespHoje, 'Responder hoje', '#EF4444'),
    statCard(totalDecidir, 'Decidir'),
    statCard(totalPagar, 'Pagar'),
  );
  corpo.append(stats);

  // Top 3
  const emailPorId = new Map();
  for (const b of json.baldes) for (const e of b.emails) emailPorId.set(e.id, e);

  if (json.top3?.length > 0) {
    corpo.append(el('div', {
      style: 'font-size:11px;letter-spacing:0.18em;text-transform:uppercase;color:#E85C00;margin:24px 0 12px;font-family:monospace;font-weight:600',
    }, '🎯 Top 3 · Resolver primeiro'));

    for (const t of json.top3) {
      const e = emailPorId.get(t.id);
      if (!e) continue;
      const card = el('div', {
        style: 'background:linear-gradient(135deg,rgba(239,68,68,0.06) 0%,#121212 60%);border:1px solid #1F1F1F;border-left:3px solid #EF4444;border-radius:10px;padding:16px 18px;margin-bottom:12px',
      });
      card.append(
        el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:8px' }, [
          el('div', { style: 'display:flex;align-items:center;gap:12px' }, [
            el('div', { style: 'font-size:28px;font-weight:600;color:#EF4444;letter-spacing:-0.03em' }, String(t.prioridade || '?')),
            el('div', {}, [
              el('div', { style: 'font-size:14px;font-weight:600' }, e.de_nome || e.de_email),
              el('div', { style: 'font-size:11px;color:#7E7E7E;font-family:monospace' }, `${t.tempo_estimado_min || '?'} MIN`),
            ]),
          ]),
        ]),
        el('div', { style: 'font-size:13px;color:#B4B4B4;margin-bottom:8px' }, e.assunto || '(sem assunto)'),
        el('div', { style: 'background:#161616;border-left:3px solid #E85C00;padding:10px 12px;border-radius:0 6px 6px 0;margin:8px 0' }, [
          el('div', { style: 'font-weight:600;color:#EDEDED;font-size:13px;margin-bottom:4px' }, `→ ${t.acao_curta || ''}`),
          el('div', { style: 'font-size:12px;color:#B4B4B4;line-height:1.5' }, t.acao_completa || ''),
        ]),
        el('a', {
          href: e.link_gmail,
          target: '_blank',
          style: 'display:inline-block;background:#E85C00;color:#fff;padding:6px 12px;border-radius:5px;font-size:11px;letter-spacing:0.05em;text-transform:uppercase;text-decoration:none;font-weight:600',
        }, 'Abrir no Gmail ↗'),
      );
      corpo.append(card);
    }
  }

  // Baldes (cada um expansível com botões inline)
  for (const balde of json.baldes) {
    if (balde.emails.length === 0) continue;
    corpo.append(renderBaldeCard(balde));
  }

  box.append(corpo);
  document.body.append(overlay);

  // ============ HELPERS ============
  async function callAcao(messageIds, op) {
    const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-acao-gmail`, {
      method: 'POST',
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'executar',
        cliente_id: session.user.id,
        conexao_id: conexao.id,
        messageIds,
        op,
      }),
    });
    if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);
    return r.body;
  }

  const OP_INVERSA = {
    arquivar: 'unarchive',
    lido_arquivar: 'unread_unarchive',
    starred: 'unstarred',
    lixo: 'untrash',
  };
  const OP_LABEL = {
    arquivar: 'arquivado',
    lido_arquivar: 'arquivado',
    starred: 'marcado como importante',
    unstarred: 'estrela removida',
    lixo: 'movido pra lixeira',
    unarchive: 'restaurado',
    unread_unarchive: 'restaurado',
    untrash: 'restaurado',
  };

  function atualizarContagens() {
    overlay.querySelectorAll('[data-balde-slug]').forEach((baldeEl) => {
      const slug = baldeEl.getAttribute('data-balde-slug');
      const items = baldeEl.querySelectorAll('.balde-item:not(.is-removendo)');
      const countEl = baldeEl.querySelector('[data-count]');
      if (countEl) countEl.textContent = String(items.length);
    });
  }

  async function acaoIndividual(messageId, op, item, btn) {
    if (op === 'lixo' && !confirm('Mover esse email pra Lixeira do Gmail?')) return;
    if (btn) btn.disabled = true;
    item.classList.add('is-removendo');
    item.style.opacity = '0.3';
    item.style.transition = 'opacity 0.2s';
    atualizarContagens();
    try {
      const r = await callAcao([messageId], op);
      if (r.falhas > 0 && r.sucessos === 0) throw new Error('falha gmail');
      // Sucesso — remove de fato após 250ms
      setTimeout(() => { item.style.display = 'none'; }, 250);
      const label = OP_LABEL[op] || op;
      const podeDesfazer = !!OP_INVERSA[op] && op !== 'lixo';
      toast({
        msg: `<strong>✓</strong> 1 email ${label}`,
        tipo: 'sucesso',
        undoFn: podeDesfazer ? async () => {
          item.style.display = '';
          item.style.opacity = '1';
          item.classList.remove('is-removendo');
          atualizarContagens();
          try {
            await callAcao([messageId], OP_INVERSA[op]);
          } catch (_) {
            item.style.display = 'none';
            atualizarContagens();
            toast({ msg: '<strong>⚠</strong> Falha ao desfazer', tipo: 'erro' });
          }
        } : null,
      });
    } catch (e) {
      item.classList.remove('is-removendo');
      item.style.opacity = '1';
      atualizarContagens();
      if (btn) btn.disabled = false;
      toast({ msg: `<strong>⚠</strong> ${e.message || 'falhou'}`, tipo: 'erro' });
    }
  }

  async function acaoEmMassa(slug, op, label) {
    const baldeEl = overlay.querySelector(`[data-balde-slug="${slug}"]`);
    if (!baldeEl) return;
    const items = Array.from(baldeEl.querySelectorAll('.balde-item:not(.is-removendo)'));
    if (items.length === 0) return;
    const acaoTxt = op === 'lixo' ? 'mover pra lixeira' : op === 'arquivar' ? 'arquivar' : 'marcar como lido e arquivar';
    if (!confirm(`Vai ${acaoTxt} ${items.length} emails. Continuar?`)) return;
    const ids = items.map((it) => it.getAttribute('data-message-id')).filter(Boolean);
    items.forEach((it) => { it.classList.add('is-removendo'); it.style.opacity = '0.3'; });
    atualizarContagens();
    try {
      const r = await callAcao(ids, op);
      const sucessos = r.sucessos || 0;
      const falhas = r.falhas || 0;
      setTimeout(() => {
        items.forEach((it, i) => {
          const det = (r.detalhes || []).find((d) => d.messageId === ids[i]);
          if (det?.ok !== false) it.style.display = 'none';
          else { it.style.opacity = '1'; it.classList.remove('is-removendo'); }
        });
        atualizarContagens();
      }, 250);
      let msg = `<strong>✓</strong> ${sucessos} email${sucessos > 1 ? 's' : ''} ${OP_LABEL[op] || op}`;
      if (falhas > 0) msg += ` · ${falhas} falharam`;
      toast({
        msg,
        tipo: falhas > 0 ? 'erro' : 'sucesso',
        undoFn: OP_INVERSA[op] && op !== 'lixo' && sucessos > 0 ? async () => {
          const idsSucesso = (r.detalhes || []).filter((d) => d.ok).map((d) => d.messageId);
          items.forEach((it) => {
            if (idsSucesso.includes(it.getAttribute('data-message-id'))) {
              it.style.display = '';
              it.style.opacity = '1';
              it.classList.remove('is-removendo');
            }
          });
          atualizarContagens();
          try { await callAcao(idsSucesso, OP_INVERSA[op]); }
          catch (_) {
            items.forEach((it) => { it.style.display = 'none'; });
            atualizarContagens();
          }
        } : null,
      });
    } catch (e) {
      items.forEach((it) => { it.classList.remove('is-removendo'); it.style.opacity = '1'; });
      atualizarContagens();
      toast({ msg: `<strong>⚠</strong> ${e.message}`, tipo: 'erro' });
    }
  }

  async function carregarCorpoEmail(messageId, corpoEl) {
    corpoEl.innerHTML = '<div style="color:#7E7E7E;font-size:12px;padding:8px">carregando...</div>';
    try {
      const r = await fetchProxy(`${SUPABASE_URL}/functions/v1/tool-acao-gmail`, {
        method: 'POST',
        headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'corpo',
          cliente_id: session.user.id,
          conexao_id: conexao.id,
          messageId,
        }),
      });
      if (!r.ok || !r.body?.ok) throw new Error(r.body?.erro || `HTTP ${r.status}`);
      const texto = (r.body.texto || '').slice(0, 4000);
      corpoEl.innerHTML = '';
      corpoEl.append(el('pre', {
        style: 'white-space:pre-wrap;font-family:inherit;font-size:12px;color:#B4B4B4;line-height:1.6;margin:0;padding:12px;background:#0A0A0A;border-radius:6px;max-height:400px;overflow-y:auto',
      }, texto || '(corpo vazio)'));
    } catch (e) {
      corpoEl.innerHTML = `<div style="color:#EF4444;font-size:12px;padding:8px">⚠ ${e.message}</div>`;
    }
  }

  // ============ RENDER BALDE ============
  function renderBaldeCard(balde) {
    const card = el('div', {
      'data-balde-slug': balde.slug,
      style: 'background:#121212;border:1px solid #1F1F1F;border-radius:10px;padding:14px 16px;margin-bottom:12px;position:relative',
    });
    const _header = el('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:8px' });
    const titulo = el('div', { style: 'display:flex;align-items:center;gap:10px' }, [
      el('span', { style: 'font-size:20px' }, balde.emoji || '📂'),
      el('div', {}, [
        el('div', { style: 'font-size:15px;font-weight:600' }, balde.nome),
        el('div', { style: 'font-size:11px;color:#7E7E7E' }, balde.desc || ''),
      ]),
    ]);
    const direita = el('div', { style: 'display:flex;align-items:center;gap:8px' });
    const countBadge = el('span', {
      'data-count': '1',
      style: 'background:rgba(232,92,0,0.15);color:#E85C00;padding:3px 10px;border-radius:4px;font-family:monospace;font-size:12px;font-weight:600',
    }, String(balde.emails.length));
    direita.append(countBadge);

    // Botões em massa (só pra arquivar e baldes não-críticos)
    if (balde.slug === 'arquivar' || balde.slug === 'acompanhar') {
      const btnMassaArq = el('button', {
        type: 'button',
        style: 'background:transparent;border:1px solid #2A2A2A;color:#B4B4B4;padding:4px 10px;border-radius:5px;font-size:10px;letter-spacing:0.05em;text-transform:uppercase;cursor:pointer;font-family:inherit',
      }, '📥 Arquivar todos');
      btnMassaArq.addEventListener('click', () => acaoEmMassa(balde.slug, 'arquivar'));
      direita.append(btnMassaArq);
    }

    _header.append(titulo, direita);
    card.append(_header);

    // Lista de emails
    const lista = el('div', { style: 'margin-top:8px' });
    for (const e of balde.emails) {
      lista.append(renderEmailItem(e, balde.slug));
    }
    card.append(lista);
    return card;
  }

  function renderEmailItem(e, baldeSlug) {
    const item = el('div', {
      class: 'balde-item',
      'data-message-id': e.id,
      style: 'padding:10px 0;border-top:1px solid #1F1F1F;display:grid;grid-template-columns:1fr auto;gap:12px;align-items:start',
    });
    const conteudo = el('div', { style: 'min-width:0' });
    conteudo.append(
      el('div', { style: 'display:flex;gap:10px;align-items:baseline;flex-wrap:wrap;margin-bottom:2px' }, [
        el('span', {
          style: `font-size:13px;font-weight:600;color:#EDEDED;opacity:${e.is_unread ? '1' : '0.85'}`,
        }, (e.is_unread ? '● ' : '') + (e.de_nome || e.de_email) + (e.is_starred ? ' ⭐' : '')),
        el('span', { style: 'font-family:monospace;font-size:10px;color:#7E7E7E' }, fmtDataEmail(e.data_iso)),
      ]),
      el('div', { style: 'font-size:13px;color:#B4B4B4;margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, e.assunto || '(sem assunto)'),
      el('div', { style: 'font-size:11px;color:#7E7E7E;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden' }, e.snippet || ''),
    );
    if (e.motivo_curto) {
      conteudo.append(el('div', {
        style: 'font-family:monospace;font-size:9px;color:#E85C00;letter-spacing:0.05em;margin-top:4px;text-transform:uppercase',
      }, e.motivo_curto));
    }
    // Container pro corpo expandido
    const corpoEl = el('div', { 'data-corpo': '1', style: 'display:none;margin-top:8px' });
    conteudo.append(corpoEl);

    // Botões de ação
    const acoes = el('div', { style: 'display:flex;gap:4px;flex-wrap:wrap;align-items:start' });
    function btn(emoji, op, titulo, perigo = false) {
      const b = el('button', {
        type: 'button',
        title: titulo,
        style: `background:#0A0A0A;border:1px solid #1F1F1F;color:${perigo ? '#EF4444' : '#7E7E7E'};padding:5px 8px;border-radius:5px;cursor:pointer;font-size:13px;line-height:1;transition:all 0.15s`,
      }, emoji);
      b.addEventListener('mouseenter', () => { b.style.borderColor = perigo ? '#EF4444' : '#E85C00'; b.style.color = perigo ? '#EF4444' : '#E85C00'; });
      b.addEventListener('mouseleave', () => { b.style.borderColor = '#1F1F1F'; b.style.color = perigo ? '#EF4444' : '#7E7E7E'; });
      b.addEventListener('click', () => acaoIndividual(e.id, op, item, b));
      return b;
    }
    // Ver mais (toggle corpo)
    const btnVerMais = el('button', {
      type: 'button',
      title: 'Ver corpo completo',
      style: 'background:#0A0A0A;border:1px solid #1F1F1F;color:#7E7E7E;padding:5px 8px;border-radius:5px;cursor:pointer;font-size:13px;line-height:1',
    }, '▾');
    let corpoCarregado = false;
    btnVerMais.addEventListener('click', () => {
      if (corpoEl.style.display === 'none') {
        corpoEl.style.display = 'block';
        btnVerMais.textContent = '▴';
        if (!corpoCarregado) {
          carregarCorpoEmail(e.id, corpoEl);
          corpoCarregado = true;
        }
      } else {
        corpoEl.style.display = 'none';
        btnVerMais.textContent = '▾';
      }
    });
    acoes.append(
      btnVerMais,
      btn('⭐', e.is_starred ? 'unstarred' : 'starred', e.is_starred ? 'Remover importante' : 'Marcar importante'),
      btn('📥', 'arquivar', 'Arquivar'),
      btn('✓', 'lido_arquivar', 'Marcar lido e arquivar'),
      btn('🗑', 'lixo', 'Mover pra Lixeira', true),
    );
    // Link Gmail
    const aGmail = el('a', {
      href: e.link_gmail,
      target: '_blank',
      title: 'Abrir no Gmail',
      style: 'background:#0A0A0A;border:1px solid #1F1F1F;color:#E85C00;padding:5px 8px;border-radius:5px;font-size:11px;text-decoration:none;line-height:1;display:inline-flex;align-items:center',
    }, '↗');
    acoes.append(aGmail);

    item.append(conteudo, acoes);
    return item;
  }

  function fmtDataEmail(iso) {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      const agora = Date.now();
      const diff = (agora - d.getTime()) / 1000;
      if (diff < 3600) return `${Math.round(diff / 60)}min`;
      if (diff < 86400) return `${Math.round(diff / 3600)}h`;
      return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
    } catch { return '—'; }
  }

  // Cleanup do toast container quando fechar
  overlay.addEventListener('remove', () => toastContainer.remove(), { once: true });
  const observer = new MutationObserver(() => {
    if (!document.body.contains(overlay)) {
      toastContainer.remove();
      observer.disconnect();
    }
  });
  observer.observe(document.body, { childList: true, subtree: false });
}

init();
