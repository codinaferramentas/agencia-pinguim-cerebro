// ============================================================
// Pinguim Agentes — Varredor WhatsApp Web (v0.24.0)
// ============================================================
// Injetado via chrome.scripting.executeScript com world:'MAIN' quando o socio
// clica "Varrer agora" na sidebar.
// Faz scroll programático do painel esquerdo do WhatsApp Web, coletando
// nome + preview + hora + nao_lidas + flags pra CADA conversa.
// Retorna o dataset completo. O filtro por palavra/perfil/tempo é feito na sidebar (local).
//
// Saída: { ok, conversas: [...], total, duracao_ms, erro? }
// ============================================================

(async function() {
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  if (!location.hostname.includes('whatsapp.com')) {
    return { ok: false, erro: 'aba ativa não é o WhatsApp Web' };
  }

  const aside = document.querySelector('div[aria-label="Lista de conversas"]')
    || document.querySelector('div[aria-label="Chat list"]')
    || document.querySelector('#pane-side');
  if (!aside) {
    return { ok: false, erro: 'painel de conversas não encontrado' };
  }

  // O scroller real é um filho do aside (geralmente um div com overflow-y).
  // Procura o container scrollável dentro do aside.
  function acharScroller(root) {
    const candidatos = root.querySelectorAll('div');
    let melhor = root;
    let maiorScrollHeight = 0;
    for (const d of candidatos) {
      const cs = window.getComputedStyle(d);
      if ((cs.overflowY === 'auto' || cs.overflowY === 'scroll') && d.scrollHeight > d.clientHeight) {
        if (d.scrollHeight > maiorScrollHeight) {
          maiorScrollHeight = d.scrollHeight;
          melhor = d;
        }
      }
    }
    return melhor;
  }
  const scroller = acharScroller(aside);

  // ============== HELPERS DE EXTRAÇÃO (copiados/adaptados do leitor-tela.js) ==============
  function detectarMidia(itemEl) {
    const icones = itemEl.querySelectorAll('span[data-icon]');
    for (const ic of icones) {
      const tipo = (ic.getAttribute('data-icon') || '').toLowerCase();
      if (tipo.includes('check') || tipo.includes('pinned') || tipo.includes('muted')
          || tipo.includes('archive') || tipo.includes('online') || tipo === 'default-group') continue;
      if (tipo.includes('audio') || tipo.includes('voice') || tipo.includes('mic') || tipo.includes('ptt')) return '🎤 Áudio';
      if (tipo.includes('image') || tipo.includes('photo') || tipo.includes('camera')) return '📷 Foto';
      if (tipo.includes('video')) return '🎥 Vídeo';
      if (tipo.includes('document') || tipo.includes('file')) return '📄 Documento';
      if (tipo.includes('sticker')) return '💟 Figurinha';
      if (tipo.includes('gif')) return '🎞 GIF';
      if (tipo.includes('location')) return '📍 Localização';
      if (tipo.includes('contact')) return '👤 Contato';
      if (tipo.includes('call')) return '📞 Chamada';
      if (tipo.includes('deleted')) return '🚫 Mensagem apagada';
      if (tipo.includes('poll')) return '📊 Enquete';
    }
    return null;
  }

  function limparPreview(s) {
    if (!s) return '';
    s = s.replace(/status-[a-z0-9-]+/gi, '').trim();
    return s.replace(/\s+/g, ' ').trim();
  }

  function ehPreviewInutil(s) {
    if (!s) return true;
    if (/^\d{1,3}:\d{2}$/.test(s)) return true;
    if (/^\d+\s+(mensagens?\s+não\s+lidas?|unread\s+messages?)$/i.test(s)) return true;
    if (/^\d+$/.test(s) && s.length <= 3) return true;
    if (s.length < 2) return true;
    return false;
  }

  // Parser de hora pra calcular se está dentro do período do filtro.
  // Formatos do WhatsApp: "14:08" (hoje), "ontem", "segunda-feira", "20/05/2026"
  function parsearTimestampPreview(horaStr) {
    if (!horaStr) return null;
    const agora = new Date();
    const h = horaStr.trim().toLowerCase();
    // HH:MM = hoje
    let m = h.match(/^(\d{1,2}):(\d{2})$/);
    if (m) {
      const d = new Date(agora);
      d.setHours(parseInt(m[1], 10), parseInt(m[2], 10), 0, 0);
      return d;
    }
    // "ontem"
    if (/^(ontem|yesterday|ayer)$/.test(h)) {
      const d = new Date(agora);
      d.setDate(d.getDate() - 1);
      return d;
    }
    // "hoje"
    if (/^(hoje|today|hoy)$/.test(h)) return new Date(agora);
    // Dia da semana (segunda-feira, terça-feira, etc) — assume últimos 7 dias
    const diasMap = { 'domingo': 0, 'segunda': 1, 'segunda-feira': 1, 'terça': 2, 'terça-feira': 2, 'terca': 2, 'terca-feira': 2, 'quarta': 3, 'quarta-feira': 3, 'quinta': 4, 'quinta-feira': 4, 'sexta': 5, 'sexta-feira': 5, 'sábado': 6, 'sabado': 6 };
    if (diasMap[h] !== undefined) {
      const d = new Date(agora);
      const diff = (d.getDay() - diasMap[h] + 7) % 7 || 7;
      d.setDate(d.getDate() - diff);
      return d;
    }
    // Data DD/MM/YYYY ou DD/MM/YY
    m = h.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
    if (m) {
      let ano = parseInt(m[3], 10);
      if (ano < 100) ano += 2000;
      return new Date(ano, parseInt(m[2], 10) - 1, parseInt(m[1], 10));
    }
    return null;
  }

  function extrairItem(item) {
    let nome = '';
    const tituloEl = item.querySelector('span[title]');
    if (tituloEl) nome = (tituloEl.getAttribute('title') || tituloEl.textContent || '').trim();
    if (!nome) {
      const sp0 = item.querySelector('span[dir="auto"]');
      if (sp0) nome = (sp0.textContent || '').trim();
    }
    if (!nome) return null;

    let hora = '';
    const spansHora = item.querySelectorAll('span, div');
    for (const sp of spansHora) {
      const t = (sp.textContent || '').trim();
      if (t.length > 16) continue;
      if (/^\d{1,2}:\d{2}$/.test(t)
          || /^(ontem|hoje|ayer|today|yesterday|hoy)$/i.test(t)
          || /^(segunda|terça|terca|quarta|quinta|sexta|sábado|sabado|domingo)(-feira)?$/i.test(t)
          || /^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(t)) {
        hora = t;
        break;
      }
    }

    let nao_lidas = 0;
    const naoLidasEl = item.querySelector('span[aria-label*="ão lida"], span[aria-label*="unread"], span[aria-label*="no leído"]');
    if (naoLidasEl) {
      const mm = (naoLidasEl.getAttribute('aria-label') || naoLidasEl.textContent || '').match(/\d+/);
      if (mm) nao_lidas = parseInt(mm[0], 10) || 0;
    }

    let ultimaMsg = '';
    const previewLabelEl = item.querySelector('div[aria-label]:not([role]):not([class*="badge"])');
    if (previewLabelEl) {
      const ariaTxt = (previewLabelEl.getAttribute('aria-label') || '').trim();
      if (ariaTxt && !ehPreviewInutil(ariaTxt) && ariaTxt !== nome) ultimaMsg = ariaTxt;
    }
    if (!ultimaMsg) {
      const candidatos = item.querySelectorAll('span[dir="ltr"], span[dir="auto"]');
      for (const sp of candidatos) {
        const t = limparPreview(sp.textContent || '');
        if (!t || t === nome || t === hora || ehPreviewInutil(t)) continue;
        if (/^\d{1,2}:\d{2}$/.test(t) || /^\d+$/.test(t)) continue;
        ultimaMsg = t.slice(0, 220);
      }
    }
    const tipoMidia = detectarMidia(item);
    if (tipoMidia) {
      if (!ultimaMsg || ehPreviewInutil(ultimaMsg) || /^\d{1,2}:\d{2}$/.test(ultimaMsg)) {
        ultimaMsg = tipoMidia;
      } else if (!ultimaMsg.includes(tipoMidia)) {
        ultimaMsg = `${tipoMidia} ${ultimaMsg}`.slice(0, 220);
      }
    }
    if (ehPreviewInutil(ultimaMsg)) ultimaMsg = '';

    const eh_grupo = !!item.querySelector('[data-icon="default-group"], [data-testid="default-group"]')
                  || /^[A-Z][\wÀ-ÿ\s]{1,30}: /.test(ultimaMsg);
    const eh_broadcast = !!item.querySelector('[data-icon="broadcast"]');
    const pinada = !!item.querySelector('[data-icon="pinned2"], [data-icon="pinned"], [aria-label*="ixada"]');
    const silenciada = !!item.querySelector('[data-icon="muted"], [aria-label*="ilenciada"]');

    const tsParsed = parsearTimestampPreview(hora);
    return {
      nome: nome.slice(0, 100),
      ultima_msg: ultimaMsg,
      hora,
      timestamp_iso: tsParsed ? tsParsed.toISOString() : null,
      nao_lidas,
      eh_grupo,
      eh_broadcast,
      pinada,
      silenciada,
    };
  }

  // ============== SCROLL LOOP ==============
  // Mantém um Map de nome -> dados (dedup).
  // Critério de parada: 3 scrolls seguidos sem novidade OU scrollTop não muda mais OU 60s timeout.
  const tInicio = Date.now();
  const coletadas = new Map();
  const TIMEOUT_MS = 60000;
  const MAX_SCROLLS = 200; // hard cap
  let scrollsConsecutivosSemNovidade = 0;
  let scrollTopAnterior = -1;

  // Volta pro topo primeiro pra não perder os pinados
  scroller.scrollTop = 0;
  await sleep(400);

  for (let i = 0; i < MAX_SCROLLS; i++) {
    if (Date.now() - tInicio > TIMEOUT_MS) break;

    // Coleta o que está visível no DOM AGORA
    const items = aside.querySelectorAll('div[role="listitem"], div[role="row"]');
    let novosNesseTick = 0;
    for (const item of items) {
      try {
        const dados = extrairItem(item);
        if (!dados || !dados.nome) continue;
        // Dedup por nome (com chance de colisão se 2 contatos têm mesmo nome — aceita)
        if (!coletadas.has(dados.nome)) {
          coletadas.set(dados.nome, dados);
          novosNesseTick++;
        }
      } catch (_) { /* item inválido */ }
    }

    if (novosNesseTick === 0) scrollsConsecutivosSemNovidade++;
    else scrollsConsecutivosSemNovidade = 0;

    // Para se 3 ticks seguidos sem novo OU scrollTop travou
    if (scrollsConsecutivosSemNovidade >= 3) break;
    if (scroller.scrollTop === scrollTopAnterior && i > 2) break;

    scrollTopAnterior = scroller.scrollTop;

    // Scroll de ~80% do viewport (não chega a "saltar" no WhatsApp)
    const delta = Math.floor(scroller.clientHeight * 0.8);
    scroller.scrollTop += delta;
    // Delay humano + tempo pro WhatsApp renderizar o próximo batch
    await sleep(350);
  }

  // Volta pro topo no fim pra deixar a UI no estado natural
  scroller.scrollTop = 0;

  const conversas = Array.from(coletadas.values());
  return {
    ok: true,
    total: conversas.length,
    duracao_ms: Date.now() - tInicio,
    conversas,
  };
})();
