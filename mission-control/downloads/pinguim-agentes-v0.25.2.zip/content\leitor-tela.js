// ============================================================
// Pinguim Agentes — Leitor de Tela Ativa (v0.13.0)
// ============================================================
// Executado on-demand via chrome.scripting.executeScript pelo service worker.
// Extrai informacao util do DOM da aba ativa pra mandar pro agente IA.
//
// Saida (return do script):
// {
//   url, titulo, dominio,
//   texto_visivel,         // texto principal limpo, max ~12k chars
//   tabelas,               // array de objetos representando tabelas HTML
//   formularios,           // labels + valores de inputs/selects visiveis
//   links_importantes,     // top links com texto (max 20)
//   meta,                  // tipo detectado (gmail, supabase, planilha, generico)
//   tamanho_chars,         // tamanho total do conteudo extraido
// }
// ============================================================

(function() {
  function limparTexto(t) {
    return String(t || '')
      .replace(/[​-‏﻿]/g, '')          // zero-width chars
      .replace(/\s+/g, ' ')                            // colapsa espacos
      .trim();
  }

  function ehVisivel(elem) {
    if (!elem || elem.nodeType !== 1) return false;
    if (elem.offsetParent === null && elem.tagName !== 'BODY') return false;
    const cs = window.getComputedStyle(elem);
    if (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) return false;
    return true;
  }

  // Detecta TIPO de tela pelo URL + heuristicas no DOM
  function detectarTipo() {
    const host = location.hostname.toLowerCase();
    const path = location.pathname.toLowerCase();
    if (host.includes('mail.google') || host.includes('outlook')) return 'email';
    if (host.includes('docs.google.com/spreadsheets') || host.includes('sheets.google')) return 'planilha';
    if (host.includes('docs.google.com/document') || host.includes('docs.google')) return 'documento';
    if (host.includes('supabase.com') || host.includes('supabase.co')) return 'supabase';
    if (host.includes('clint')) return 'clint';
    if (host.includes('hotmart')) return 'hotmart';
    if (host.includes('meta.com') || host.includes('facebook.com/business') || host.includes('business.facebook')) return 'meta-ads';
    if (host.includes('analytics.google')) return 'analytics';
    if (host.includes('discord.com')) return 'discord';
    if (host.includes('whatsapp.com') || host.includes('web.whatsapp')) return 'whatsapp';
    if (document.querySelector('table[data-table], .ag-root, .MuiDataGrid-root')) return 'dashboard';
    if (document.querySelector('article, .post-content, .entry-content')) return 'artigo';
    return 'generico';
  }

  // Extrai TEXTO VISIVEL principal do body (sem nav, footer, scripts, sidebar Pinguim)
  function extrairTextoVisivel(maxChars = 12000) {
    const ignorar = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'SVG', 'CANVAS', 'NAV', 'FOOTER', 'ASIDE']);
    const partes = [];
    let tamanho = 0;

    function walk(node) {
      if (tamanho >= maxChars) return;
      if (!node) return;
      if (node.nodeType === 3) {
        // text node
        const t = node.nodeValue;
        if (t && t.trim().length >= 2) {
          partes.push(t);
          tamanho += t.length;
        }
        return;
      }
      if (node.nodeType !== 1) return;
      if (ignorar.has(node.tagName)) return;
      // Filtra sidebar do Pinguim
      if (node.id === 'pinguim-agentes-sidebar-iframe') return;
      // Filtra elementos invisiveis
      if (!ehVisivel(node)) return;
      // Walk children
      for (const child of node.childNodes) walk(child);
    }
    walk(document.body);
    return limparTexto(partes.join(' ')).slice(0, maxChars);
  }

  // Extrai TABELAS HTML visiveis. Limita ate 5 tabelas, 50 linhas cada, 12 colunas
  function extrairTabelas(maxTabelas = 5, maxLinhas = 50, maxCols = 12) {
    const tabelas = [];
    const tables = document.querySelectorAll('table');
    for (const t of tables) {
      if (tabelas.length >= maxTabelas) break;
      if (!ehVisivel(t)) continue;
      // Cabecalho
      const headRow = t.querySelector('thead tr') || t.querySelector('tr');
      let cabecalho = [];
      if (headRow) {
        cabecalho = [...headRow.children].slice(0, maxCols).map(c => limparTexto(c.textContent).slice(0, 60));
      }
      // Linhas
      const rows = [...t.querySelectorAll('tr')].slice(0, maxLinhas + 1);
      const linhas = [];
      for (const r of rows) {
        if (r === headRow) continue;
        const cells = [...r.querySelectorAll('td, th')].slice(0, maxCols);
        if (cells.length === 0) continue;
        const linha = cells.map(c => limparTexto(c.textContent).slice(0, 80));
        linhas.push(linha);
        if (linhas.length >= maxLinhas) break;
      }
      if (linhas.length > 0 || cabecalho.length > 0) {
        tabelas.push({ cabecalho, linhas });
      }
    }
    return tabelas;
  }

  // Extrai formulario (input + label associada se houver)
  function extrairFormularios(maxCampos = 30) {
    const campos = [];
    const inputs = document.querySelectorAll('input, textarea, select');
    for (const inp of inputs) {
      if (campos.length >= maxCampos) break;
      if (!ehVisivel(inp)) continue;
      if (inp.type === 'hidden' || inp.type === 'password') continue;
      // Tenta achar label
      let label = '';
      if (inp.labels && inp.labels.length > 0) {
        label = limparTexto(inp.labels[0].textContent);
      } else if (inp.placeholder) {
        label = limparTexto(inp.placeholder);
      } else if (inp.name) {
        label = inp.name;
      } else if (inp.getAttribute('aria-label')) {
        label = limparTexto(inp.getAttribute('aria-label'));
      }
      let valor;
      if (inp.tagName === 'SELECT') {
        valor = inp.options[inp.selectedIndex]?.text || inp.value;
      } else {
        valor = String(inp.value || '').slice(0, 120);
      }
      if (!label && !valor) continue;
      campos.push({ label: label.slice(0, 60), valor });
    }
    return campos;
  }

  // Extrai top 20 links visiveis com texto util
  function extrairLinks(max = 20) {
    const links = [];
    const ahref = document.querySelectorAll('a[href]');
    for (const a of ahref) {
      if (links.length >= max) break;
      if (!ehVisivel(a)) continue;
      const texto = limparTexto(a.textContent);
      if (!texto || texto.length < 3 || texto.length > 100) continue;
      const href = a.href;
      if (!href || href.startsWith('javascript:')) continue;
      links.push({ texto: texto.slice(0, 80), url: href.slice(0, 200) });
    }
    return links;
  }

  // ============== WHATSAPP WEB COLLECTOR (v0.23.1) ==============
  // Detecta WhatsApp Web e extrai conversas visíveis do painel esquerdo.
  // DOM virtualizado: pega só o que está renderizado.
  // v0.23.1: corrige preview de áudio/mídia (era pegando classe CSS), badge não lidas
  // não vira preview, detecção de grupo melhor.
  function extrairConversasWhatsApp() {
    if (!location.hostname.includes('whatsapp.com')) return null;
    try {
      const aside = document.querySelector('div[aria-label="Lista de conversas"]')
        || document.querySelector('div[aria-label="Chat list"]')
        || document.querySelector('#pane-side');
      if (!aside) return { erro: 'painel de conversas nao encontrado (WhatsApp Web pode ter atualizado layout)' };

      // Detecta preview de mídia pelos ícones SVG do WhatsApp.
      // WhatsApp usa <span data-icon="..."> dentro do preview pra audio/foto/video/doc.
      function detectarMidia(itemEl) {
        // Lista de mapeamentos data-icon -> rótulo legível
        // (data-icon do WhatsApp Web 2026-05: status-audio, status-video, status-image,
        //  status-document, status-sticker, status-gif, status-deleted, status-call, etc)
        const icones = itemEl.querySelectorAll('span[data-icon]');
        for (const ic of icones) {
          const tipo = (ic.getAttribute('data-icon') || '').toLowerCase();
          // Ignora ícones que não são de preview (check, pinned, muted, etc)
          if (tipo.includes('check') || tipo.includes('pinned') || tipo.includes('muted')
              || tipo.includes('archive') || tipo.includes('online') || tipo === 'default-group') continue;
          if (tipo.includes('audio') || tipo.includes('voice') || tipo.includes('mic') || tipo.includes('ptt')) return '🎤 Áudio';
          if (tipo.includes('image') || tipo.includes('photo') || tipo.includes('camera')) return '📷 Foto';
          if (tipo.includes('video')) return '🎥 Vídeo';
          if (tipo.includes('document') || tipo.includes('file')) return '📄 Documento';
          if (tipo.includes('sticker')) return '💟 Figurinha';
          if (tipo.includes('gif')) return '🎞 GIF';
          if (tipo.includes('location')) return '📍 Localização';
          if (tipo.includes('contact')) return '👤 Contato';
          if (tipo.includes('call')) return '📞 Chamada';
          if (tipo.includes('deleted')) return '🚫 Mensagem apagada';
          if (tipo.includes('poll')) return '📊 Enquete';
        }
        return null;
      }

      // Limpa um texto de preview removendo lixo de classe CSS do WhatsApp
      // (ex: "status-dblcheckic-keyboard-voice-filled0:03" vira "0:03")
      function limparPreview(s) {
        if (!s) return '';
        // Remove tokens que parecem classe CSS (status-dblcheck, status-audio etc.)
        s = s.replace(/status-[a-z0-9-]+/gi, '').trim();
        // Remove emojis duplicados consecutivos e espaços excessivos
        s = s.replace(/\s+/g, ' ').trim();
        return s;
      }

      // Detecta se preview é só lixo (badge "X mensagens não lidas", duração de áudio, etc)
      function ehPreviewInutil(s) {
        if (!s) return true;
        if (/^\d{1,3}:\d{2}$/.test(s)) return true; // duração tipo "1:13"
        if (/^\d+\s+(mensagens?\s+não\s+lidas?|unread\s+messages?)$/i.test(s)) return true;
        if (/^\d+$/.test(s) && s.length <= 3) return true; // só número
        if (s.length < 2) return true;
        return false;
      }

      const items = aside.querySelectorAll('div[role="listitem"], div[role="row"]');
      const conversas = [];

      for (const item of items) {
        try {
          // ---------- NOME ----------
          // span[title] dentro do header da conversa é o nome (mais confiável)
          let nome = '';
          const tituloEl = item.querySelector('span[title]');
          if (tituloEl) {
            nome = (tituloEl.getAttribute('title') || tituloEl.textContent || '').trim();
          }
          if (!nome) {
            // fallback: primeiro span[dir="auto"] com texto razoável
            const span0 = item.querySelector('span[dir="auto"]');
            if (span0) nome = (span0.textContent || '').trim();
          }
          if (!nome || nome.length < 1) continue;

          // ---------- HORA ----------
          // Hora no canto direito superior (HH:MM ou "ontem"/"hoje" ou data)
          let hora = '';
          const spansHora = item.querySelectorAll('span, div');
          for (const sp of spansHora) {
            const t = (sp.textContent || '').trim();
            if (t.length > 12) continue;
            if (/^\d{1,2}:\d{2}$/.test(t)
                || /^(ontem|hoje|ayer|today|yesterday)$/i.test(t)
                || /^(segunda|terça|quarta|quinta|sexta|sábado|domingo|sabado)(-feira)?$/i.test(t)
                || /^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(t)) {
              hora = t;
              break;
            }
          }

          // ---------- NÃO LIDAS ----------
          let nao_lidas = 0;
          const naoLidasEl = item.querySelector('span[aria-label*="ão lida"], span[aria-label*="unread"], span[aria-label*="no leído"]');
          if (naoLidasEl) {
            const m = (naoLidasEl.getAttribute('aria-label') || naoLidasEl.textContent || '').match(/\d+/);
            if (m) nao_lidas = parseInt(m[0], 10) || 0;
          }

          // ---------- PREVIEW DA ÚLTIMA MENSAGEM ----------
          // Estratégia: WhatsApp coloca o preview num container específico.
          // Procura por div[aria-label] ou span[aria-label] que contenha o texto da última msg.
          // Como fallback, varre spans que NÃO sejam nome/hora/badge.
          let ultimaMsg = '';
          let remetente_preview = ''; // pra grupo: "Pedro:" antes da msg

          // Tenta pegar via aria-label do preview row (mais confiável quando existe)
          const previewLabelEl = item.querySelector('div[aria-label]:not([role]):not([class*="badge"])');
          if (previewLabelEl) {
            const ariaTxt = (previewLabelEl.getAttribute('aria-label') || '').trim();
            if (ariaTxt && !ehPreviewInutil(ariaTxt) && ariaTxt !== nome) {
              ultimaMsg = ariaTxt;
            }
          }

          // Fallback: varre todos spans, pega o texto "real"
          if (!ultimaMsg) {
            // Pega o ÚLTIMO span[dir="ltr"] ou span[dir="auto"] que tenha conteúdo de texto
            // útil e não seja nome/hora/badge
            const candidatos = item.querySelectorAll('span[dir="ltr"], span[dir="auto"]');
            for (const sp of candidatos) {
              // pula se contém spans aninhados de ícone (data-icon)
              const t = limparPreview(sp.textContent || '');
              if (!t) continue;
              if (t === nome) continue;
              if (t === hora) continue;
              if (ehPreviewInutil(t)) continue;
              if (/^\d+$/.test(t)) continue;
              // pula se é só horário/data
              if (/^\d{1,2}:\d{2}$/.test(t)) continue;
              // descobriu preview real
              ultimaMsg = t.slice(0, 200);
            }
          }

          // ---------- ÍCONE DE MÍDIA ----------
          const tipoMidia = detectarMidia(item);
          if (tipoMidia) {
            // Se a msg só era lixo de classe ou duração, usa só o tipo
            if (!ultimaMsg || ehPreviewInutil(ultimaMsg) || /^\d{1,2}:\d{2}$/.test(ultimaMsg)) {
              ultimaMsg = tipoMidia;
            } else {
              // Combina: "🎤 Áudio (0:03)" se for duração
              if (/^\d{1,2}:\d{2}$/.test(ultimaMsg)) {
                ultimaMsg = `${tipoMidia} (${ultimaMsg})`;
              } else if (!ultimaMsg.includes(tipoMidia)) {
                ultimaMsg = `${tipoMidia} ${ultimaMsg}`.slice(0, 200);
              }
            }
          }

          // Última verificação: se preview ainda é lixo, marca como vazio
          if (ehPreviewInutil(ultimaMsg)) ultimaMsg = '';

          // ---------- GRUPO ----------
          // (1) Avatar de grupo padrão
          const eh_grupo_img = !!item.querySelector('[data-icon="default-group"], [data-testid="default-group"]');
          // (2) Preview tipo "Nome: mensagem"
          const eh_grupo_preview = /^[A-Z][\wÀ-ÿ\s]{1,30}: /.test(ultimaMsg);
          // (3) Lista de transmissão (broadcast) — distinta de grupo mas geralmente passiva
          const eh_broadcast = !!item.querySelector('[data-icon="broadcast"]');
          const eh_grupo = eh_grupo_img || eh_grupo_preview || eh_broadcast;

          // Se for grupo e preview tem "Nome:", separa remetente
          if (eh_grupo_preview) {
            const m = ultimaMsg.match(/^([^:]{1,40}):\s*(.*)$/);
            if (m) {
              remetente_preview = m[1].trim();
              // mantém ultimaMsg como está pro contexto
            }
          }

          // ---------- FLAGS ----------
          const online = !!item.querySelector('span[data-icon="online"], [aria-label*="online"], [aria-label*="em linha"]');
          const pinada = !!item.querySelector('[data-icon="pinned2"], [data-icon="pinned"], [aria-label*="ixada"]');
          const silenciada = !!item.querySelector('[data-icon="muted"], [aria-label*="ilenciada"]');

          conversas.push({
            nome: nome.slice(0, 100),
            ultima_msg: ultimaMsg,
            remetente_preview, // só preenchido em grupos
            hora,
            nao_lidas,
            eh_grupo,
            eh_broadcast,
            online,
            pinada,
            silenciada,
          });
        } catch (e) { /* item invalido, pula */ }
      }

      const total_dms = conversas.filter(c => !c.eh_grupo).length;
      const total_grupos = conversas.filter(c => c.eh_grupo).length;

      return {
        ok: true,
        total: conversas.length,
        total_dms,
        total_grupos,
        conversas,
      };
    } catch (e) {
      return { erro: 'coletor falhou: ' + (e.message || e) };
    }
  }

  // ============== MAIN ==============
  const tipo = detectarTipo();
  const texto_visivel = extrairTextoVisivel();
  const tabelas = extrairTabelas();
  const formularios = extrairFormularios();
  const links_importantes = extrairLinks();
  const whatsapp_conversas = extrairConversasWhatsApp(); // null se nao for WhatsApp Web

  // v0.19.0: captura HTML completo (limpo, sem scripts) pra Clonador de Pagina de Venda.
  // Limita a 500KB pra nao estourar payload.
  let html_completo = null;
  try {
    const clone = document.documentElement.cloneNode(true);
    // Remove a sidebar do Pinguim do clone
    const sb = clone.querySelector('#pinguim-agentes-sidebar-iframe');
    if (sb) sb.remove();
    // Remove scripts (segurança + tamanho — Edge tambem remove)
    clone.querySelectorAll('script,noscript').forEach(n => n.remove());
    const htmlStr = '<!doctype html>\n' + clone.outerHTML;
    if (htmlStr.length < 500000) html_completo = htmlStr;
    else html_completo = htmlStr.slice(0, 500000);
  } catch (_) { html_completo = null; }

  const resultado = {
    url: location.href.slice(0, 500),
    titulo: limparTexto(document.title || '').slice(0, 200),
    dominio: location.hostname,
    meta: { tipo, lang: document.documentElement.lang || null },
    texto_visivel,
    tabelas,
    formularios,
    links_importantes,
    html_completo,
    whatsapp_conversas, // v0.23 — null se nao for WhatsApp Web
    tamanho_chars: texto_visivel.length +
      tabelas.reduce((s, t) => s + JSON.stringify(t).length, 0),
  };
  // Returna pro executeScript via ultimo statement
  return resultado;
})();
