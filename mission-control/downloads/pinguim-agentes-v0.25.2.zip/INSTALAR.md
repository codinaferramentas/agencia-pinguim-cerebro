# Pinguim Agentes — v0.19.0

## Replicador de Página de Venda + Arsenal navegável

Próximo especialista do botão 👁 Analisar Tela está vivo: **Clonador de Página de Venda**. Quando você abre uma página de venda concorrente (ou própria) e clica 👁 Analisar Tela, a extensão detecta sozinha que é página de venda e oferece clonar (em vez do análise genérica com GPT-4o vision).

### O que o Clonador entrega

- **HTML limpo da página** salvo no Supabase Storage (bucket `arsenal-pinguim`)
- **Briefing estruturado em 12 blocos canônicos**:
  - 🎯 Headline + sub-headline
  - 💰 Oferta (promessa, público, garantia)
  - ✓ Benefícios (bullets diretos)
  - ⭐ Prova social (depoimentos, números, mídia)
  - 🛡 Garantia
  - 🛒 CTA principal (texto botão, preço, urgência)
  - ⏰ Urgência / escassez
  - ❓ FAQ
  - 👤 Sobre o autor
  - 📋 Especificações (formato, duração, bônus)
  - 🎁 Bônus
  - 💡 **3 sugestões de otimização** (o que mudar pra subir conversão)
- **Tudo guardado** em `pinguim.itens_arsenal` (RLS por sócio) → vira biblioteca de templates

### Nova categoria Arsenal

Substitui visivelmente Cérebros + Skills na nav lateral (que ficaram **ocultos até estarem prontos** — você cobrou na última iteração).

Arsenal mostra todos os itens capturados pela extensão. Hoje só tem páginas clonadas. Próximos sprints: transcripts YouTube, reels Instagram/TikTok, análises de Doc.

### Como detecta automaticamente

O porteiro do botão 👁 Analisar Tela checa em ordem:
1. **Planilha Google Sheets** → Analista (intacto, continua igual)
2. **Página de venda** → Clonador (NOVO):
   - Por host: hotmart.com, kiwify.com, eduzz.com, monetizze.com, pay.* etc
   - Por path: /checkout, /oferta, /venda
   - Por sinais textuais: garantia + 12x R$ + "quero entrar" + depoimentos + "vagas limitadas" + bônus (≥3 sinais = página de venda)
3. **Genérico** → Analisador de tela (GPT-4o vision, intacto)

### Cuidado de aditividade

**Planilha NÃO foi tocada.** O caminho `editar-planilha` continua exatamente como na v0.18.2 (dry-run, desfazer, 8 ações). Smoke test passou: agente `editor-de-planilha` retorna `@EDICAO:` com `executar_direto` e `preencher_coluna_cond` certinho.

A detecção de página de venda foi **inserida DEPOIS** do bloco planilha — se for Sheets, nem chega a ser avaliada.

## Como instalar

1. Vá em `chrome://extensions/`
2. Modo desenvolvedor ON
3. Carregar sem compactação → aponta pra `C:\Pinguim-extensao\v0.19.0\`
4. Pin no Chrome

**Pasta dessa versão**: `C:\Pinguim-extensao\v0.19.0`

## O que testar

1. **Página de venda** (qualquer Hotmart/Kiwify): abre → clica 👁 → Clonador detecta → preview com thumbnail do screenshot → clica "📥 Clonar agora" → modal de progresso → modal de resultado com 8 cards de briefing + sugestões + botão "📥 Baixar HTML" + "📦 Ver no Arsenal"
2. **Arsenal**: clica 📦 na nav lateral → lista todos os itens clonados → clica um → re-abre modal com briefing completo
3. **Planilha continua funcionando**: abre Google Sheets → 👁 → Editar → "preenche os sem X com Y" → dry-run + desfazer
4. **Cérebros/Skills sumiram da nav**: a nav lateral agora tem 5 ícones visíveis (Home implícita, Chat, Agentes, Agendamentos, Arsenal, Tela)

## Próximos passos planejados

- Transcritor YouTube
- Triador Gmail
- Reels Instagram/TikTok (download + análise)
- Modal 3-painéis com preview do HTML clonado renderizado lado-a-lado com original
- Cérebros e Skills com funcionalidade real
