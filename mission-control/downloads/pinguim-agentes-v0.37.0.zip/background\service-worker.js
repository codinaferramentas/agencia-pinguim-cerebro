// Service worker — recebe clique no icone, abre sidebar, gerencia context menu.

import { inicializarAlertasCalendario, tratarAlarme, tratarClickNotificacao } from './alertas-calendario.js';

const SIDEBAR_URL = chrome.runtime.getURL('sidebar/sidebar.html');

// Cria menu de contexto quando user seleciona texto
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'pinguim-revisar-com-agente',
    title: 'Revisar com Pinguim Agentes',
    contexts: ['selection'],
  });
  // v0.32.0 — boot dos alertas de calendário
  inicializarAlertasCalendario().catch((e) => console.warn('[alertas-cal] boot:', e?.message));
});

// v0.32.0 — também tenta inicializar no startup (caso install já tenha acontecido)
chrome.runtime.onStartup.addListener(() => {
  inicializarAlertasCalendario().catch((e) => console.warn('[alertas-cal] startup:', e?.message));
});

// v0.32.0 — listener único de alarmes
chrome.alarms.onAlarm.addListener((alarm) => {
  tratarAlarme(alarm).catch((e) => console.warn('[alertas-cal] alarm:', e?.message));
});

// v0.32.0 — click em notificação (corpo ou botão)
chrome.notifications.onClicked.addListener((notifId) => {
  tratarClickNotificacao(notifId, -1).catch((e) => console.warn('[alertas-cal] notif click:', e?.message));
});
chrome.notifications.onButtonClicked.addListener((notifId, buttonIndex) => {
  tratarClickNotificacao(notifId, buttonIndex).catch((e) => console.warn('[alertas-cal] notif btn:', e?.message));
});

// Clique no menu de contexto -> envia texto pra sidebar
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'pinguim-revisar-com-agente' && info.selectionText && tab?.id) {
    try {
      await chrome.storage.local.set({
        textoPendente: info.selectionText.trim(),
        textoPendenteOrigem: tab.url || '',
        textoPendenteEm: Date.now(),
      });
      await garantirContentScript(tab.id);
      await chrome.tabs.sendMessage(tab.id, { tipo: 'ABRIR_SIDEBAR_COM_TEXTO' });
    } catch (e) {
      console.error('[Pinguim Agentes] erro context menu:', e);
    }
  }
});

// Helper: garante que content script esta injetado antes de enviar mensagem
async function garantirContentScript(tabId) {
  try {
    // Tenta mandar mensagem; se nao houver listener, injeta o script
    await chrome.tabs.sendMessage(tabId, { tipo: 'PING' });
    return true;
  } catch (_) {
    // Content script nao carregado, injeta agora
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content/content.js'],
      });
      // Pequeno delay pra script terminar de inicializar
      await new Promise(r => setTimeout(r, 100));
      return true;
    } catch (e) {
      console.warn('[Pinguim Agentes] nao consegui injetar content script:', e.message);
      return false;
    }
  }
}

// Clique no icone da action -> manda mensagem pro content script abrir/fechar sidebar
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  // Bloqueia em paginas internas do Chrome
  if (tab.url?.startsWith('chrome://') || tab.url?.startsWith('chrome-extension://') || tab.url?.startsWith('edge://')) {
    console.warn('[Pinguim Agentes] extensao nao funciona em paginas internas do Chrome. Use em qualquer site normal.');
    return;
  }
  const ok = await garantirContentScript(tab.id);
  if (!ok) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { tipo: 'TOGGLE_SIDEBAR' });
  } catch (e) {
    console.warn('[Pinguim Agentes] erro ao alternar sidebar:', e.message);
  }
});

// Proxy de fetch — content script (no DOM da pagina) nao pode chamar Edge Functions
// com headers customizados de forma confiavel. Service worker faz a chamada.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.tipo === 'FETCH_PROXY') {
    fetch(msg.url, msg.options)
      .then(async r => {
        const txt = await r.text();
        let body;
        try { body = JSON.parse(txt); } catch { body = txt; }
        sendResponse({ ok: r.ok, status: r.status, body });
      })
      .catch(e => sendResponse({ ok: false, erro: e.message }));
    return true; // mantem o canal aberto pra resposta async
  }
  // v0.13.0+v0.14.0: LER_TELA_ATIVA — executa leitor-tela.js + tira SCREENSHOT (visao)
  if (msg.tipo === 'LER_TELA_ATIVA') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) throw new Error('Aba ativa nao encontrada');
        if (tab.url?.startsWith('chrome://') || tab.url?.startsWith('chrome-extension://') || tab.url?.startsWith('edge://')) {
          throw new Error('Nao consigo ler paginas internas do navegador. Abre um site normal e tenta de novo.');
        }
        // 1) DOM via leitor-tela.js
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content/leitor-tela.js'],
        });
        const dadosTela = results?.[0]?.result;
        if (!dadosTela) throw new Error('Leitor nao retornou dados — pagina pode bloquear scripts.');

        // 2) v0.14.0: SCREENSHOT da aba visivel (resolve canvas-only sites tipo Google Sheets)
        // Esconde sidebar antes pra nao capturar ela no print
        let screenshotDataUrl = null;
        try {
          // Pede pro content script esconder a sidebar
          await chrome.tabs.sendMessage(tab.id, { tipo: 'OCULTAR_SIDEBAR_PRO_SCREENSHOT' }).catch(() => {});
          // Pequeno delay pra animacao terminar
          await new Promise(r => setTimeout(r, 350));
          screenshotDataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 80 });
        } catch (eShot) {
          console.warn('[Pinguim] screenshot falhou:', eShot.message);
          // segue sem screenshot — ainda tem DOM
        } finally {
          // Restaura sidebar
          chrome.tabs.sendMessage(tab.id, { tipo: 'MOSTRAR_SIDEBAR_POS_SCREENSHOT' }).catch(() => {});
        }

        sendResponse({ ok: true, dados: dadosTela, screenshot: screenshotDataUrl });
      } catch (e) {
        sendResponse({ ok: false, erro: e.message });
      }
    })();
    return true;
  }
  // v0.24.0 — Varredura completa do WhatsApp Web via scroll programatico
  if (msg.tipo === 'VARRER_WHATSAPP') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) throw new Error('Aba ativa nao encontrada');
        if (!tab.url?.includes('web.whatsapp.com')) {
          throw new Error('A aba ativa nao e o WhatsApp Web — abre web.whatsapp.com e tenta de novo.');
        }
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content/varredor-whatsapp.js'],
        });
        const dados = results?.[0]?.result;
        if (!dados) throw new Error('Varredor nao retornou dados.');
        sendResponse({ ok: true, ...dados });
      } catch (e) {
        sendResponse({ ok: false, erro: e.message });
      }
    })();
    return true;
  }
  if (msg.tipo === 'WHISPER_TRANSCRIBE') {
    (async () => {
      try {
        // Pega session do storage pra ter access_token
        const { session } = await chrome.storage.local.get(['session']);
        if (!session?.access_token) throw new Error('Sem sessao');
        // Chama Edge Function que tem OPENAI_API_KEY (vamos criar tool-transcrever-audio)
        const r = await fetch('https://wmelierxzpjamiofeemh.supabase.co/functions/v1/tool-transcrever-audio', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ audio_base64: msg.audioBase64, mime_type: msg.mimeType }),
        });
        const data = await r.json();
        if (!r.ok) throw new Error(data?.erro || `HTTP ${r.status}`);
        sendResponse({ ok: true, texto: data.texto });
      } catch (e) {
        sendResponse({ ok: false, erro: e.message });
      }
    })();
    return true;
  }
});

// v0.22.3: REMOVIDO listener de tabs.onActivated/onUpdated.
// Antes: service worker injetava content script + abria sidebar em CADA troca de aba.
// Custo: 1 executeScript + 1 sendMessage por troca, mesmo em abas sem foco do usuário.
// Agora: content.js (já carregado em <all_urls>) detecta foco via visibilitychange/focus
// e decide sozinho se abre sidebar. Service worker só atua em clique no ícone, Ctrl+B,
// context menu e fetch proxy. Reduz drasticamente trabalho do browser.
