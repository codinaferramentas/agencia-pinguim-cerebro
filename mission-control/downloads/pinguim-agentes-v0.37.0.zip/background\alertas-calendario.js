// ============================================================
// background/alertas-calendario.js
// ============================================================
// Alertas proativos de reuniões do Google Calendar.
//
// Arquitetura (zero impacto em content script / tabs):
//   - chrome.alarms 'sync-calendar' dispara a cada 5min
//   - Handler busca eventos do dia via Edge tool-listar-eventos-calendar
//   - Pra cada evento, agenda 3 alarmes pontuais (30min, 10min, 0min antes)
//   - Quando esses alarmes disparam: chrome.notifications.create()
//
// Salvaguardas:
//   1. Kill switch (chrome.storage.local.alertasCalendarioAtivo=false desliga tudo)
//   2. Quota dura: max 10 eventos x 3 alarmes = 30 alarmes simultâneos
//   3. Circuit breaker: 3 falhas seguidas no fetch → desativa por 1h
// ============================================================

const ALARME_SYNC = 'pinguim-sync-calendar';
const PREFIXO_ALARME_EVENTO = 'pinguim-evento-';
const STORAGE_KEY_FALHAS = 'pinguim_alertas_falhas';
const STORAGE_KEY_DESATIVADO_ATE = 'pinguim_alertas_desativado_ate';
const MAX_EVENTOS = 10;
const SYNC_INTERVALO_MIN = 5;
const ANTECEDENCIAS_MIN = [30, 10, 0];

// ============================================================
// Boot: chamado de service-worker.js no install/startup
// ============================================================
export async function inicializarAlertasCalendario() {
  // Cria alarme periódico (se não existir)
  const existente = await chrome.alarms.get(ALARME_SYNC);
  if (!existente) {
    chrome.alarms.create(ALARME_SYNC, {
      delayInMinutes: 1,
      periodInMinutes: SYNC_INTERVALO_MIN,
    });
    console.log('[alertas-cal] alarme sync criado, intervalo', SYNC_INTERVALO_MIN, 'min');
  }
}

// ============================================================
// Handler de alarmes (chamado de service-worker.js)
// ============================================================
export async function tratarAlarme(alarm) {
  if (alarm.name === ALARME_SYNC) {
    await sincronizarEventos();
    return;
  }
  if (alarm.name.startsWith(PREFIXO_ALARME_EVENTO)) {
    await dispararNotificacaoEvento(alarm.name);
    return;
  }
}

// ============================================================
// Sincronizar eventos do Calendar
// ============================================================
async function sincronizarEventos() {
  try {
    if (!(await alertasAtivos())) return;
    if (await emPausaPorFalha()) return;

    const eventos = await buscarEventos();
    if (!eventos) return; // falha já tratada

    // Reset circuit breaker
    await chrome.storage.local.set({ [STORAGE_KEY_FALHAS]: 0 });

    await reagendarAlarmesEventos(eventos);
  } catch (e) {
    console.warn('[alertas-cal] sync erro:', e?.message);
    await registrarFalha();
  }
}

async function alertasAtivos() {
  const { alertasCalendarioAtivo } = await chrome.storage.local.get(['alertasCalendarioAtivo']);
  // Default: ativado. Sócio precisa explicitamente desligar.
  return alertasCalendarioAtivo !== false;
}

async function emPausaPorFalha() {
  const { [STORAGE_KEY_DESATIVADO_ATE]: ate } = await chrome.storage.local.get([STORAGE_KEY_DESATIVADO_ATE]);
  if (ate && Date.now() < ate) return true;
  return false;
}

async function registrarFalha() {
  const { [STORAGE_KEY_FALHAS]: falhas = 0 } = await chrome.storage.local.get([STORAGE_KEY_FALHAS]);
  const novo = falhas + 1;
  await chrome.storage.local.set({ [STORAGE_KEY_FALHAS]: novo });
  if (novo >= 3) {
    const desativadoAte = Date.now() + 60 * 60 * 1000; // 1h
    await chrome.storage.local.set({
      [STORAGE_KEY_DESATIVADO_ATE]: desativadoAte,
      [STORAGE_KEY_FALHAS]: 0,
    });
    console.warn('[alertas-cal] 3 falhas, pausando 1h até', new Date(desativadoAte).toISOString());
  }
}

// ============================================================
// Buscar eventos via Edge
// ============================================================
async function buscarEventos() {
  const { session } = await chrome.storage.local.get(['session']);
  if (!session?.access_token) return null;

  const cliente_id = session.user?.id;
  if (!cliente_id) return null;

  // Busca janela de 24h
  const r = await fetch('https://wmelierxzpjamiofeemh.supabase.co/functions/v1/tool-listar-eventos-calendar', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ cliente_id, ate_minutos: 24 * 60 }),
  });
  if (!r.ok) {
    console.warn('[alertas-cal] Edge retornou', r.status);
    return null;
  }
  const j = await r.json();
  if (!j.ok) {
    // Sem conexão Google = não é falha do nosso lado, não conta pro circuit breaker
    if ((j.erro || '').includes('sem conexão') || (j.erro || '').toLowerCase().includes('socio')) {
      return [];
    }
    console.warn('[alertas-cal] Edge erro:', j.erro);
    return null;
  }
  return j.eventos || [];
}

// ============================================================
// Reagendar alarmes pontuais
// ============================================================
async function reagendarAlarmesEventos(eventos) {
  // 1. Limpa alarmes antigos de evento (pra refletir cancelamentos/mudanças)
  const todos = await chrome.alarms.getAll();
  for (const a of todos) {
    if (a.name.startsWith(PREFIXO_ALARME_EVENTO)) {
      await chrome.alarms.clear(a.name);
    }
  }

  // 2. Trunca pra quota dura
  const limitados = eventos.slice(0, MAX_EVENTOS);

  // 3. Cria alarme pra cada (evento × antecedência) futuro
  let criados = 0;
  for (const ev of limitados) {
    if (!ev.inicio_iso) continue;
    const inicioMs = new Date(ev.inicio_iso).getTime();
    if (isNaN(inicioMs)) continue;

    for (const ant of ANTECEDENCIAS_MIN) {
      const quandoMs = inicioMs - ant * 60_000;
      // Mín 30s no futuro pra Chrome aceitar
      if (quandoMs - Date.now() < 30_000) continue;
      const nome = `${PREFIXO_ALARME_EVENTO}${ev.id}__${ant}`;
      try {
        chrome.alarms.create(nome, { when: quandoMs });
        criados++;
      } catch (e) {
        console.warn('[alertas-cal] falha ao criar alarme', nome, e?.message);
      }
    }

    // Guarda metadados do evento pra usar quando disparar
    await chrome.storage.local.set({
      [`pinguim_evento_${ev.id}`]: {
        id: ev.id,
        titulo: ev.titulo,
        inicio_iso: ev.inicio_iso,
        local: ev.local,
        meet_url: ev.meet_url,
      },
    });
  }
  if (criados > 0) console.log('[alertas-cal]', criados, 'alarmes agendados pra', limitados.length, 'eventos');
}

// ============================================================
// Dispara notificação quando alarme bate
// ============================================================
async function dispararNotificacaoEvento(nomeAlarme) {
  if (!(await alertasAtivos())) return;

  // Formato: pinguim-evento-{eventId}__{antecedencia}
  const sem_prefixo = nomeAlarme.replace(PREFIXO_ALARME_EVENTO, '');
  const sep = sem_prefixo.lastIndexOf('__');
  if (sep === -1) return;
  const eventoId = sem_prefixo.slice(0, sep);
  const antecedencia = Number(sem_prefixo.slice(sep + 2));

  const { [`pinguim_evento_${eventoId}`]: evento } = await chrome.storage.local.get([`pinguim_evento_${eventoId}`]);
  if (!evento) return;

  const texto = antecedencia === 0
    ? 'Começou agora'
    : antecedencia === 10
    ? 'Começa em 10 minutos'
    : `Começa em ${antecedencia} minutos`;

  const hora = new Date(evento.inicio_iso).toLocaleTimeString('pt-BR', {
    hour: '2-digit', minute: '2-digit',
  });

  const opcoes = {
    type: 'basic',
    iconUrl: chrome.runtime.getURL('icons/icon-128.png'),
    title: `🗓 ${evento.titulo}`,
    message: `${texto} (${hora})`,
    priority: antecedencia === 0 ? 2 : 1,
    requireInteraction: antecedencia === 0,
  };

  if (evento.meet_url) {
    opcoes.buttons = [{ title: '🎥 Abrir Meet' }];
  }

  const notifId = `pinguim-notif-${eventoId}-${antecedencia}-${Date.now()}`;
  try {
    await chrome.notifications.create(notifId, opcoes);
    // Guarda meet_url pra quando clicar no botão
    if (evento.meet_url) {
      await chrome.storage.local.set({ [`pinguim_notif_${notifId}`]: { meet_url: evento.meet_url } });
    }
  } catch (e) {
    console.warn('[alertas-cal] falha notif:', e?.message);
  }

  // Notifica sidebar (se estiver aberta) — content script propaga
  try {
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      chrome.tabs.sendMessage(t.id, {
        tipo: 'ALERTA_CALENDARIO',
        evento,
        antecedencia,
      }).catch(() => {});
    }
  } catch (_) {}
}

// ============================================================
// Click handlers de notificação
// ============================================================
export async function tratarClickNotificacao(notifId, buttonIndex) {
  const { [`pinguim_notif_${notifId}`]: dados } = await chrome.storage.local.get([`pinguim_notif_${notifId}`]);
  if (dados?.meet_url) {
    chrome.tabs.create({ url: dados.meet_url });
  }
  chrome.notifications.clear(notifId);
  await chrome.storage.local.remove([`pinguim_notif_${notifId}`]);
}
