// Content script — injeta iframe da sidebar do lado direito da pagina.
// Persiste estado "fixar" no chrome.storage.

const SIDEBAR_IFRAME_ID = 'pinguim-agentes-sidebar-iframe';
const SIDEBAR_BACKDROP_ID = 'pinguim-agentes-backdrop';

let sidebarVisivel = false;
let sempreFixa = false;

// Carrega config inicial
chrome.storage.local.get(['sempreFixa'], (data) => {
  sempreFixa = !!data.sempreFixa;
  if (sempreFixa) abrirSidebar();
});

function montarIframeSeNaoExiste() {
  let iframe = document.getElementById(SIDEBAR_IFRAME_ID);
  if (iframe) return iframe;
  iframe = document.createElement('iframe');
  iframe.id = SIDEBAR_IFRAME_ID;
  iframe.src = chrome.runtime.getURL('sidebar/sidebar.html');
  // Permite que sidebar use microfone + clipboard
  iframe.setAttribute('allow', 'microphone; clipboard-read; clipboard-write');
  iframe.style.cssText = [
    'position: fixed',
    'top: 0',
    'right: 0',
    'width: 420px',
    'height: 100vh',
    'border: none',
    'border-left: 1px solid #2a2a2a',
    'box-shadow: -8px 0 32px rgba(0,0,0,0.4)',
    'background: #0a0a0a',
    'z-index: 2147483647',
    'transition: transform 0.25s ease',
    'transform: translateX(100%)',
    'color-scheme: dark',
  ].join('; ');
  document.documentElement.appendChild(iframe);
  return iframe;
}

function abrirSidebar() {
  const jaExistia = !!document.getElementById(SIDEBAR_IFRAME_ID);
  const iframe = montarIframeSeNaoExiste();
  // forca reflow antes de animar
  void iframe.offsetWidth;
  iframe.style.transform = 'translateX(0)';
  sidebarVisivel = true;
  // Se iframe ja existia (estava recolhido), avisa sidebar pra refresh
  if (jaExistia) {
    try {
      iframe.contentWindow?.postMessage({ pinguimTipo: 'SIDEBAR_REABRIU' }, '*');
    } catch (_) {}
  }
}

function fecharSidebar(force = false) {
  // Se "sempre fixa" e nao foi pedido force, ignora — sidebar permanece
  if (sempreFixa && !force) return;
  const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
  if (!iframe) return;
  iframe.style.transform = 'translateX(100%)';
  sidebarVisivel = false;
}

function toggleSidebar() {
  if (sidebarVisivel) fecharSidebar();
  else abrirSidebar();
}

// Mensagens vindas do service worker (clique no icone, menu contexto)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.tipo === 'PING') {
    sendResponse({ pong: true });
    return false;
  }
  if (msg.tipo === 'TOGGLE_SIDEBAR') {
    toggleSidebar();
    sendResponse({ visivel: sidebarVisivel });
    return false;
  }
  if (msg.tipo === 'ABRIR_SIDEBAR_COM_TEXTO') {
    abrirSidebar();
    sendResponse({ ok: true });
    return false;
  }
  if (msg.tipo === 'ABRIR_SIDEBAR_SE_NAO_ABERTA') {
    if (!sidebarVisivel) abrirSidebar();
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

// Mensagens vindas DA sidebar (iframe se comunica com content via postMessage)
window.addEventListener('message', async (ev) => {
  if (ev.data?.pinguimTipo === 'FECHAR_SIDEBAR') {
    // Clicar no X desfixa global e fecha. Espera storage gravar antes de fechar
    // pra evitar race com chrome.tabs.onUpdated que poderia reabrir.
    if (sempreFixa) {
      sempreFixa = false;
      await new Promise(r => chrome.storage.local.set({ sempreFixa: false }, r));
    }
    fecharSidebar(true);
  }
  if (ev.data?.pinguimTipo === 'SET_FIXA') {
    sempreFixa = !!ev.data.valor;
    await new Promise(r => chrome.storage.local.set({ sempreFixa }, r));
  }
  if (ev.data?.pinguimTipo === 'RECARREGAR_PAGINA') {
    location.reload();
  }
});

// Mudanca de aba ou pagina recarregada: respeita "sempre fixa"
chrome.storage.onChanged.addListener((mudancas) => {
  if (mudancas.sempreFixa) {
    sempreFixa = !!mudancas.sempreFixa.newValue;
    if (sempreFixa && !sidebarVisivel) abrirSidebar();
    if (!sempreFixa && sidebarVisivel) {
      // mantem aberta na sessao, so para de forcar
    }
  }
});
