# Pinguim Agentes — instalação rápida

## 1. Baixar e descompactar

Você recebeu o arquivo `pinguim-agentes-v0.1.0.zip`. Descompacte numa pasta qualquer do computador. Exemplo: `C:\Users\seunome\PinguimAgentes\` ou `~/PinguimAgentes/`.

**Importante:** depois de descompactar, **não delete nem mova essa pasta** — se mover, a extensão para de funcionar e você precisa instalar de novo.

## 2. Instalar no Chrome

1. Abra o Chrome
2. Vá em `chrome://extensions` (digita na barra de URL)
3. No canto superior direito, **ligue "Modo do desenvolvedor"**
4. Vai aparecer 3 botões. Clique em **"Carregar sem compactação"**
5. Selecione a pasta onde você descompactou o zip
6. Pronto. Aparece um ícone do Pinguim na barra do navegador

> **Aviso amarelo:** o Chrome vai mostrar um aviso amarelo no topo dizendo "Desative as extensões em modo de desenvolvedor". Pode fechar — é só lembrete, não tem problema.

## 3. Logar

1. Clica no ícone do Pinguim na barra do navegador (ao lado da URL)
2. Sidebar abre à direita
3. Email: `contato@agenciapinguim.com`
4. Senha: `pinguim-u6ikkvhb` (vou te mandar a senha por canal privado)
5. Login

## 4. Usar

Depois de logado:

- **Lista de agentes** aparece — busca por nome/tag, filtra por squad
- **Clica num agente** → abre chat
- **Manda mensagem** → ele responde
- **Selecionar texto em qualquer página** → botão direito → "Revisar com Pinguim Agentes" → escolhe agente

## 5. Comportamento da sidebar

- Por padrão, fecha quando você clica no ✕ ou no ícone da extensão
- Clica no 📌 (canto superior direito da sidebar) pra "fixar" — fica sempre visível mesmo trocando de aba
- Clica de novo no 📌 pra desfixar

## Pra outras pessoas do time

Manda o `.zip` por WhatsApp/Drive/email e os mesmos 5 passos acima. Cada usuário precisa do email + senha próprio (cadastrado no Supabase Auth pelo admin).

## Limitações desta versão

- Histórico de conversas não é persistido (recarregou a aba, perde)
- Sem atalho de teclado pra abrir
- Sem rastreamento de uso por usuário ainda (vem na v0.2)

## Problemas?

Avisa o Andre.
