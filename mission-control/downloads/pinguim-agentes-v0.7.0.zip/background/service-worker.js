// Service worker — recebe clique no icone, abre sidebar, gerencia context menu.

const SIDEBAR_URL = chrome.runtime.getURL('sidebar/sidebar.html');

// Cria menu de contexto quando user seleciona texto
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'pinguim-revisar-com-agente',
    title: 'Revisar com Pinguim Agentes',
    contexts: ['selection'],
  });
});

// Clique no menu de contexto -> envia texto pra sidebar
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'pinguim-revisar-com-agente' && info.selectionText && tab?.id) {
    try {
      await chrome.storage.local.set({
        textoPendente: info.selectionText.trim(),
        textoPendenteOrigem: tab.url || '',
        textoPendenteEm: Date.now(),
      });
      await garantirContentScript(tab.id);
      await chrome.tabs.sendMessage(tab.id, { tipo: 'ABRIR_SIDEBAR_COM_TEXTO' });
    } catch (e) {
      console.error('[Pinguim Agentes] erro context menu:', e);
    }
  }
});

// Helper: garante que content script esta injetado antes de enviar mensagem
async function garantirContentScript(tabId) {
  try {
    // Tenta mandar mensagem; se nao houver listener, injeta o script
    await chrome.tabs.sendMessage(tabId, { tipo: 'PING' });
    return true;
  } catch (_) {
    // Content script nao carregado, injeta agora
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content/content.js'],
      });
      // Pequeno delay pra script terminar de inicializar
      await new Promise(r => setTimeout(r, 100));
      return true;
    } catch (e) {
      console.warn('[Pinguim Agentes] nao consegui injetar content script:', e.message);
      return false;
    }
  }
}

// Clique no icone da action -> manda mensagem pro content script abrir/fechar sidebar
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  // Bloqueia em paginas internas do Chrome
  if (tab.url?.startsWith('chrome://') || tab.url?.startsWith('chrome-extension://') || tab.url?.startsWith('edge://')) {
    console.warn('[Pinguim Agentes] extensao nao funciona em paginas internas do Chrome. Use em qualquer site normal.');
    return;
  }
  const ok = await garantirContentScript(tab.id);
  if (!ok) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { tipo: 'TOGGLE_SIDEBAR' });
  } catch (e) {
    console.warn('[Pinguim Agentes] erro ao alternar sidebar:', e.message);
  }
});

// Proxy de fetch — content script (no DOM da pagina) nao pode chamar Edge Functions
// com headers customizados de forma confiavel. Service worker faz a chamada.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.tipo === 'FETCH_PROXY') {
    fetch(msg.url, msg.options)
      .then(async r => {
        const txt = await r.text();
        let body;
        try { body = JSON.parse(txt); } catch { body = txt; }
        sendResponse({ ok: r.ok, status: r.status, body });
      })
      .catch(e => sendResponse({ ok: false, erro: e.message }));
    return true; // mantem o canal aberto pra resposta async
  }
  if (msg.tipo === 'WHISPER_TRANSCRIBE') {
    (async () => {
      try {
        // Pega session do storage pra ter access_token
        const { session } = await chrome.storage.local.get(['session']);
        if (!session?.access_token) throw new Error('Sem sessao');
        // Chama Edge Function que tem OPENAI_API_KEY (vamos criar tool-transcrever-audio)
        const r = await fetch('https://wmelierxzpjamiofeemh.supabase.co/functions/v1/tool-transcrever-audio', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ audio_base64: msg.audioBase64, mime_type: msg.mimeType }),
        });
        const data = await r.json();
        if (!r.ok) throw new Error(data?.erro || `HTTP ${r.status}`);
        sendResponse({ ok: true, texto: data.texto });
      } catch (e) {
        sendResponse({ ok: false, erro: e.message });
      }
    })();
    return true;
  }
});

// Quando user troca de aba ou navega: se sidebar esta fixada globalmente, injeta
// content script e abre sidebar automaticamente.
// Debounce por tab pra evitar storm de chamadas em SPAs que disparam onUpdated varias vezes.
const debouncePorTab = new Map();
async function abrirSeFixadaGlobal(tabId, url) {
  if (!tabId || !url) return;
  if (url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url.startsWith('edge://') || url.startsWith('about:')) return;
  // Debounce: cancela qualquer pendente pra este tab
  if (debouncePorTab.has(tabId)) clearTimeout(debouncePorTab.get(tabId));
  debouncePorTab.set(tabId, setTimeout(async () => {
    debouncePorTab.delete(tabId);
    try {
      const { sempreFixa } = await chrome.storage.local.get(['sempreFixa']);
      if (!sempreFixa) return; // dupla checagem pos-debounce
      await garantirContentScript(tabId);
      await chrome.tabs.sendMessage(tabId, { tipo: 'ABRIR_SIDEBAR_SE_NAO_ABERTA' });
    } catch (_) { /* silencia paginas que nao permitem */ }
  }, 250));
}

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab) abrirSeFixadaGlobal(tab.id, tab.url || '');
});

// onUpdated dispara MUITAS vezes em SPAs. So reagir quando navegar de fato (URL muda).
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Reage apenas a navegacao real (url mudou) — nao a re-renderizacao do SPA
  if (changeInfo.url && tab.active) {
    abrirSeFixadaGlobal(tabId, changeInfo.url);
  }
});
