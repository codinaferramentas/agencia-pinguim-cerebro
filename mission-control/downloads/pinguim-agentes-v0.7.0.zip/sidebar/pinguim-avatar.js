// Pinguim Squad — Gerador de avatar SVG paramétrico
// Sistema próprio de mascotes. Determinístico: mesmo slug = mesmo avatar sempre.
//
// API:
//   gerarAvatarSvg(slug, squadSlug) -> string SVG
//   gerarAvatarDataUri(slug, squadSlug) -> data URI pra <img src=...>

// =====================================================
// CORES de fundo por squad (identidade visual rápida)
// =====================================================
export const CORES_SQUAD = {
  copy: '#FF6B2C',
  storytelling: '#A855F7',
  'traffic-masters': '#3A8DFF',
  design: '#EC4899',
  'advisory-board': '#0EA5E9',
  data: '#06B6D4',
  'deep-research': '#8B5CF6',
  translate: '#10B981',
  cybersecurity: '#EF4444',
  finops: '#22C55E',
  legal: '#64748B',
  'squad-creator-pro': '#F59E0B',
  'socio_pinguim': '#1a1a1a',
};

// =====================================================
// PINGUIM BASE (silhueta magra, smart, profissional)
// =====================================================
function pinguimBase() {
  return `
    <ellipse cx="50" cy="60" rx="22" ry="30" fill="#1a1a1a"/>
    <path d="M 28 38 Q 28 28, 50 28 Q 72 28, 72 38" fill="#1a1a1a"/>
    <ellipse cx="50" cy="65" rx="14" ry="20" fill="#FFFFFF"/>
    <path d="M 47 52 L 50 56 L 53 52 Z" fill="#FF8C00"/>
    <ellipse cx="42" cy="89" rx="5" ry="2.5" fill="#FF8C00"/>
    <ellipse cx="58" cy="89" rx="5" ry="2.5" fill="#FF8C00"/>
  `;
}

// =====================================================
// ACESSÓRIOS (no rosto) — cada um inclui os olhos por dentro
// =====================================================
const ACESSORIOS = {
  // Sem acessório — só olhos normais com brilho
  nenhum: () => `
    <circle cx="41" cy="42" r="3" fill="#1a1a1a"/>
    <circle cx="59" cy="42" r="3" fill="#1a1a1a"/>
    <circle cx="42" cy="41" r="1" fill="#FFFFFF"/>
    <circle cx="60" cy="41" r="1" fill="#FFFFFF"/>`,

  oculos_redondos: () => `
    <g stroke="#1a1a1a" stroke-width="2.5" fill="none">
      <circle cx="41" cy="42" r="6.5" fill="#FFFFFF"/>
      <circle cx="59" cy="42" r="6.5" fill="#FFFFFF"/>
      <line x1="47.5" y1="42" x2="52.5" y2="42"/>
    </g>
    <circle cx="41" cy="42" r="2.2" fill="#1a1a1a"/>
    <circle cx="59" cy="42" r="2.2" fill="#1a1a1a"/>`,

  oculos_quadrados: () => `
    <g stroke="#1a1a1a" stroke-width="2.5" fill="#FFFFFF">
      <rect x="34" y="37" width="13" height="10" rx="1.5"/>
      <rect x="53" y="37" width="13" height="10" rx="1.5"/>
      <line x1="47" y1="42" x2="53" y2="42" stroke-linecap="round"/>
    </g>
    <circle cx="40.5" cy="42" r="2.2" fill="#1a1a1a"/>
    <circle cx="59.5" cy="42" r="2.2" fill="#1a1a1a"/>`,

  visor: () => `
    <path d="M 30 38 Q 30 33, 36 33 L 64 33 Q 70 33, 70 38 L 70 47 Q 70 50, 67 50 L 33 50 Q 30 50, 30 47 Z"
          fill="#1a1a1a" stroke="#1a1a1a" stroke-width="2"/>
    <rect x="34" y="38" width="12" height="9" rx="2" fill="#06B6D4"/>
    <rect x="54" y="38" width="12" height="9" rx="2" fill="#06B6D4"/>
    <line x1="36" y1="40.5" x2="40" y2="40.5" stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="round"/>
    <line x1="56" y1="40.5" x2="60" y2="40.5" stroke="#FFFFFF" stroke-width="1.5" stroke-linecap="round"/>`,

  // Olhos focados (sobrancelhas pra dentro)
  focado: () => `
    <circle cx="41" cy="42" r="3" fill="#1a1a1a"/>
    <circle cx="59" cy="42" r="3" fill="#1a1a1a"/>
    <line x1="35" y1="35" x2="44" y2="37" stroke="#1a1a1a" stroke-width="2.2" stroke-linecap="round"/>
    <line x1="56" y1="37" x2="65" y2="35" stroke="#1a1a1a" stroke-width="2.2" stroke-linecap="round"/>`,

  // Olhos criativos (sobrancelha levantada de 1 lado)
  criativo: () => `
    <circle cx="41" cy="42" r="3" fill="#1a1a1a"/>
    <circle cx="59" cy="42" r="3" fill="#1a1a1a"/>
    <circle cx="42" cy="41" r="1" fill="#FFFFFF"/>
    <circle cx="60" cy="41" r="1" fill="#FFFFFF"/>
    <path d="M 55 35 Q 60 32, 65 35" stroke="#1a1a1a" stroke-width="2" fill="none" stroke-linecap="round"/>`,

  // Olhos sorridentes (arcos pra cima)
  simpatico: () => `
    <path d="M 37 43 Q 41 39, 45 43" stroke="#1a1a1a" stroke-width="2.8" fill="none" stroke-linecap="round"/>
    <path d="M 55 43 Q 59 39, 63 43" stroke="#1a1a1a" stroke-width="2.8" fill="none" stroke-linecap="round"/>`,

  // Olhos sérios (linhas horizontais)
  serio: () => `
    <line x1="37" y1="42" x2="46" y2="42" stroke="#1a1a1a" stroke-width="2.8" stroke-linecap="round"/>
    <line x1="54" y1="42" x2="63" y2="42" stroke="#1a1a1a" stroke-width="2.8" stroke-linecap="round"/>`,
};

// =====================================================
// OBJETOS NA MÃO (incluem braço pra ficar realista)
// =====================================================
const OBJETOS = {
  nenhum: () => '',

  caneta: () => `
    <g transform="translate(78, 42) rotate(35)">
      <rect x="-1.5" y="0" width="3" height="14" rx="0.5" fill="#FFB800" stroke="#1a1a1a" stroke-width="1.2"/>
      <polygon points="-2,14 0,18 2,14" fill="#1a1a1a"/>
      <rect x="-1.5" y="-2" width="3" height="2" fill="#1a1a1a"/>
    </g>
    <path d="M 70 58 Q 78 55, 80 48" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  tablet: () => `
    <g>
      <rect x="55" y="58" width="22" height="16" rx="2" fill="#1a1a1a" stroke="#1a1a1a" stroke-width="1.5"/>
      <rect x="57" y="60" width="18" height="12" rx="1" fill="#06B6D4"/>
      <line x1="59" y1="63" x2="73" y2="63" stroke="#FFFFFF" stroke-width="1" stroke-linecap="round"/>
      <line x1="59" y1="66" x2="70" y2="66" stroke="#FFFFFF" stroke-width="1" stroke-linecap="round"/>
      <line x1="59" y1="69" x2="68" y2="69" stroke="#FFFFFF" stroke-width="1" stroke-linecap="round"/>
    </g>
    <path d="M 70 58 Q 70 60, 65 65" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  celular: () => `
    <g transform="translate(73, 62) rotate(15)">
      <rect x="-5" y="-9" width="10" height="16" rx="2" fill="#1a1a1a"/>
      <rect x="-4" y="-7" width="8" height="11" rx="1" fill="#FFB800"/>
      <circle cx="0" cy="5.5" r="0.8" fill="#FFFFFF"/>
    </g>
    <path d="M 70 58 Q 74 60, 73 64" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  lapis: () => `
    <g transform="translate(76, 50) rotate(45)">
      <rect x="-1.5" y="-8" width="3" height="16" fill="#FFB800" stroke="#1a1a1a" stroke-width="1.2"/>
      <rect x="-1.5" y="-10" width="3" height="2" fill="#EC4899"/>
      <polygon points="-2,8 0,12 2,8" fill="#FFCC99"/>
      <polygon points="-1,10 0,12 1,10" fill="#1a1a1a"/>
    </g>
    <path d="M 70 58 Q 76 56, 78 52" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  engrenagem: () => `
    <g transform="translate(78, 50)">
      <g fill="#888888" stroke="#1a1a1a" stroke-width="1.2">
        <path d="M 0,-9 L 2,-9 L 2,-6 L 5,-7 L 7,-5 L 6,-2 L 9,-2 L 9,2 L 6,2 L 7,5 L 5,7 L 2,6 L 2,9 L -2,9 L -2,6 L -5,7 L -7,5 L -6,2 L -9,2 L -9,-2 L -6,-2 L -7,-5 L -5,-7 L -2,-6 L -2,-9 Z"/>
        <circle cx="0" cy="0" r="3" fill="#1a1a1a"/>
      </g>
    </g>
    <path d="M 70 58 Q 75 55, 78 50" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  livro: () => `
    <g transform="translate(72, 65)">
      <rect x="-8" y="-7" width="16" height="11" fill="#3A8DFF" stroke="#1a1a1a" stroke-width="1.5"/>
      <line x1="0" y1="-7" x2="0" y2="4" stroke="#1a1a1a" stroke-width="1"/>
      <line x1="-5" y1="-3" x2="-2" y2="-3" stroke="#FFFFFF" stroke-width="0.8"/>
      <line x1="-5" y1="-1" x2="-2" y2="-1" stroke="#FFFFFF" stroke-width="0.8"/>
      <line x1="2" y1="-3" x2="5" y2="-3" stroke="#FFFFFF" stroke-width="0.8"/>
      <line x1="2" y1="-1" x2="5" y2="-1" stroke="#FFFFFF" stroke-width="0.8"/>
    </g>
    <path d="M 70 58 Q 72 62, 72 64" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  grafico: () => `
    <g transform="translate(72, 60)">
      <rect x="-9" y="-8" width="18" height="14" rx="1" fill="#FFFFFF" stroke="#1a1a1a" stroke-width="1.5"/>
      <polyline points="-6,3 -2,-2 2,1 6,-5" stroke="#22C55E" stroke-width="2" fill="none" stroke-linecap="round"/>
      <circle cx="-6" cy="3" r="1" fill="#22C55E"/>
      <circle cx="6" cy="-5" r="1" fill="#22C55E"/>
    </g>
    <path d="M 70 58 Q 72 60, 72 62" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  cifrao: () => `
    <g transform="translate(78, 52)">
      <circle cx="0" cy="0" r="8" fill="#22C55E" stroke="#1a1a1a" stroke-width="1.5"/>
      <text x="0" y="3" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="10" font-weight="900" fill="#FFFFFF">$</text>
    </g>
    <path d="M 70 58 Q 75 55, 78 52" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  cadeado: () => `
    <g transform="translate(76, 55)">
      <path d="M -4 -2 Q -4 -7, 0 -7 Q 4 -7, 4 -2" stroke="#1a1a1a" stroke-width="2" fill="none"/>
      <rect x="-6" y="-2" width="12" height="9" rx="1" fill="#888888" stroke="#1a1a1a" stroke-width="1.5"/>
      <circle cx="0" cy="2.5" r="1.5" fill="#1a1a1a"/>
    </g>
    <path d="M 70 58 Q 74 56, 76 55" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  martelo_juiz: () => `
    <g transform="translate(76, 52) rotate(-15)">
      <rect x="-9" y="-1" width="18" height="3" rx="0.5" fill="#8B5CF6" stroke="#1a1a1a" stroke-width="1.2"/>
      <rect x="-7" y="-4" width="6" height="9" rx="1" fill="#A855F7" stroke="#1a1a1a" stroke-width="1.2"/>
    </g>
    <path d="M 70 58 Q 73 55, 76 52" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  // Lupa pra research
  lupa: () => `
    <g transform="translate(76, 52)">
      <circle cx="0" cy="0" r="6" fill="none" stroke="#1a1a1a" stroke-width="2.5"/>
      <circle cx="0" cy="0" r="4.5" fill="#FFFFFF" opacity="0.6"/>
      <line x1="4" y1="4" x2="9" y2="9" stroke="#1a1a1a" stroke-width="2.5" stroke-linecap="round"/>
    </g>
    <path d="M 70 58 Q 74 56, 76 54" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,

  coroa: () => `
    <g fill="#FFB800" stroke="#1a1a1a" stroke-width="1.5">
      <path d="M 32 32 L 36 18 L 43 27 L 50 14 L 57 27 L 64 18 L 68 32 Z"/>
      <circle cx="50" cy="22" r="2" fill="#EF4444"/>
    </g>`,

  // Megafone pra social/copy
  megafone: () => `
    <g transform="translate(76, 55) rotate(-15)">
      <path d="M -6 -4 L 4 -7 L 4 5 L -6 2 Z" fill="#FF6B2C" stroke="#1a1a1a" stroke-width="1.5"/>
      <rect x="-9" y="-3" width="3" height="6" fill="#1a1a1a"/>
    </g>
    <path d="M 70 58 Q 73 56, 76 55" stroke="#1a1a1a" stroke-width="6" stroke-linecap="round" fill="none"/>`,
};

// =====================================================
// MAPEAMENTO INTELIGENTE: slug do agente → (acessório, objeto, expressão)
// =====================================================
// Mapeamento explícito por papel real do agente. Categorias por slug.

function decidirAvatar(slug, squadSlug) {
  const s = (slug || '').toLowerCase();

  // ===== Agentes operacionais Pinguim (que criamos) =====
  if (s === 'pinguim') return { acessorio: 'oculos_redondos', objeto: 'nenhum' };
  if (s.startsWith('consultor-')) return { acessorio: 'oculos_redondos', objeto: 'lupa' };
  if (s.startsWith('buscador-')) return { acessorio: 'oculos_redondos', objeto: 'lupa' };
  if (s.startsWith('analista-')) return { acessorio: 'oculos_quadrados', objeto: 'tablet' };
  if (s.startsWith('quebrador-')) return { acessorio: 'focado', objeto: 'megafone' };
  if (s.startsWith('briefing-')) return { acessorio: 'oculos_quadrados', objeto: 'livro' };
  if (s.includes('chief') || s.includes('board-chair')) return { acessorio: 'oculos_redondos', objeto: 'coroa' };
  if (s === 'gerador-variacao-anuncio') return { acessorio: 'criativo', objeto: 'lapis' };

  // ===== Por squad =====
  switch (squadSlug) {
    case 'copy':
      return { acessorio: 'oculos_redondos', objeto: 'caneta' };
    case 'storytelling':
      return { acessorio: 'criativo', objeto: 'livro' };
    case 'traffic-masters':
      return { acessorio: 'oculos_quadrados', objeto: 'grafico' };
    case 'design':
      return { acessorio: 'criativo', objeto: 'lapis' };
    case 'advisory-board':
      return { acessorio: 'oculos_redondos', objeto: 'livro' };
    case 'data':
      return { acessorio: 'oculos_quadrados', objeto: 'grafico' };
    case 'deep-research':
      return { acessorio: 'oculos_redondos', objeto: 'lupa' };
    case 'translate':
      return { acessorio: 'oculos_redondos', objeto: 'livro' };
    case 'cybersecurity':
      return { acessorio: 'visor', objeto: 'cadeado' };
    case 'finops':
      return { acessorio: 'oculos_quadrados', objeto: 'cifrao' };
    case 'legal':
      return { acessorio: 'oculos_redondos', objeto: 'martelo_juiz' };
    case 'squad-creator-pro':
      return { acessorio: 'simpatico', objeto: 'celular' };
    case 'socio_pinguim':
      return { acessorio: 'oculos_redondos', objeto: 'coroa' };
    default:
      return { acessorio: 'nenhum', objeto: 'nenhum' };
  }
}

// =====================================================
// API PRINCIPAL
// =====================================================
export function gerarAvatarSvg(slug, squadSlug) {
  const corFundo = CORES_SQUAD[squadSlug] || '#888888';
  const { acessorio, objeto } = decidirAvatar(slug, squadSlug);
  const acFn = ACESSORIOS[acessorio] || ACESSORIOS.nenhum;
  const objFn = OBJETOS[objeto] || OBJETOS.nenhum;

  return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%"><circle cx="50" cy="50" r="50" fill="${corFundo}"/>${pinguimBase()}${acFn()}${objFn()}</svg>`;
}

export function gerarAvatarDataUri(slug, squadSlug) {
  const svg = gerarAvatarSvg(slug, squadSlug);
  // Base64 eh mais compativel com setAttribute('src') que UTF-8 escaping
  // Browser/Chrome: btoa nao aceita UTF-8 direto, mas SVG eh ASCII puro entao OK
  try {
    return 'data:image/svg+xml;base64,' + btoa(svg);
  } catch (_) {
    // Fallback URI-encoded se algum char nao-ASCII apareceu
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
  }
}
