// Content script — injeta iframe da sidebar do lado direito da pagina.
// v0.22.3: Lazy load. Iframe SÓ é montado quando socio interage ou foca a aba.
// "Fixar" não significa mais "carregar tudo no background de toda aba" — significa
// "sidebar abre automaticamente quando você foca a aba". Economiza ~250KB JS por aba inativa.

const SIDEBAR_IFRAME_ID = 'pinguim-agentes-sidebar-iframe';

let sidebarVisivel = false;
let sempreFixa = false;
let abaFoiFocada = false; // flag pra lazy load — só monta iframe quando aba ganha foco

// Carrega config inicial (síncrono local, leve)
chrome.storage.local.get(['sempreFixa'], (data) => {
  sempreFixa = !!data.sempreFixa;
  // v0.22.3: NÃO abre automaticamente no startup
  // (antes: se sempreFixa, criava iframe imediatamente em CADA aba — pesado)
  // Agora: espera o sócio focar a aba primeiro
  if (sempreFixa && document.visibilityState === 'visible' && document.hasFocus()) {
    abrirSidebar();
  }
});

// v0.22.3: Detecta foco da aba — só monta iframe quando sócio realmente olha pra ela
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && sempreFixa && !sidebarVisivel && !abaFoiFocada) {
    abaFoiFocada = true;
    abrirSidebar();
  }
}, { passive: true });

window.addEventListener('focus', () => {
  if (sempreFixa && !sidebarVisivel && !abaFoiFocada) {
    abaFoiFocada = true;
    abrirSidebar();
  }
}, { passive: true });

function montarIframeSeNaoExiste() {
  let iframe = document.getElementById(SIDEBAR_IFRAME_ID);
  if (iframe) return iframe;
  iframe = document.createElement('iframe');
  iframe.id = SIDEBAR_IFRAME_ID;
  iframe.src = chrome.runtime.getURL('sidebar/sidebar.html');
  iframe.setAttribute('allow', 'microphone; clipboard-read; clipboard-write');
  // v0.22.3: loading lazy ajuda browser a adiar render
  iframe.loading = 'lazy';
  iframe.style.cssText = [
    'position: fixed',
    'top: 0',
    'right: 0',
    'width: 420px',
    'height: 100vh',
    'border: none',
    'border-left: 1px solid #262626',
    'box-shadow: -8px 0 32px rgba(0,0,0,0.5)',
    'background: #0a0a0a',
    'z-index: 2147483647',
    'transition: transform 0.25s cubic-bezier(0.4,0,0.2,1), width 0.32s cubic-bezier(0.4,0,0.2,1)',
    'transform: translateX(100%)',
    'color-scheme: dark',
  ].join('; ');
  document.documentElement.appendChild(iframe);
  return iframe;
}

function abrirSidebar() {
  const jaExistia = !!document.getElementById(SIDEBAR_IFRAME_ID);
  const iframe = montarIframeSeNaoExiste();
  void iframe.offsetWidth;
  iframe.style.transform = 'translateX(0)';
  sidebarVisivel = true;
  if (jaExistia) {
    try { iframe.contentWindow?.postMessage({ pinguimTipo: 'SIDEBAR_REABRIU' }, '*'); } catch (_) {}
  }
}

function fecharSidebar(force = false) {
  if (sempreFixa && !force) return;
  const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
  if (!iframe) return;
  iframe.style.transform = 'translateX(100%)';
  sidebarVisivel = false;
}

// v0.22.3: desmonta iframe completamente (libera memória)
function desmontarSidebar() {
  const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
  if (iframe) iframe.remove();
  sidebarVisivel = false;
}

function toggleSidebar() {
  abaFoiFocada = true; // clique manual conta como foco
  if (sidebarVisivel) fecharSidebar();
  else abrirSidebar();
}

// v0.22.3: quando aba perde visibilidade há muito tempo, desmonta sidebar pra liberar memória.
// Quando voltar a focar, remonta. Estado do sócio é persistido no chrome.storage.
let timerOcioso = null;
const TEMPO_OCIOSO_MS = 5 * 60 * 1000; // 5 min sem foco = desmonta

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') {
    // Aba foi pro background — agenda desmonte
    clearTimeout(timerOcioso);
    timerOcioso = setTimeout(() => {
      if (document.visibilityState === 'hidden') {
        desmontarSidebar();
        abaFoiFocada = false; // próximo foco vai remontar
      }
    }, TEMPO_OCIOSO_MS);
  } else {
    // Aba voltou ao foco — cancela desmonte agendado
    clearTimeout(timerOcioso);
  }
}, { passive: true });

// Mensagens vindas do service worker (clique no icone, menu contexto)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.tipo === 'PING') {
    sendResponse({ pong: true });
    return false;
  }
  if (msg.tipo === 'TOGGLE_SIDEBAR') {
    toggleSidebar();
    sendResponse({ visivel: sidebarVisivel });
    return false;
  }
  if (msg.tipo === 'ABRIR_SIDEBAR_COM_TEXTO') {
    abaFoiFocada = true;
    abrirSidebar();
    sendResponse({ ok: true });
    return false;
  }
  if (msg.tipo === 'ABRIR_SIDEBAR_SE_NAO_ABERTA') {
    abaFoiFocada = true;
    if (!sidebarVisivel) abrirSidebar();
    sendResponse({ ok: true });
    return false;
  }
  if (msg.tipo === 'OCULTAR_SIDEBAR_PRO_SCREENSHOT') {
    const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
    if (iframe) iframe.style.visibility = 'hidden';
    sendResponse({ ok: true });
    return false;
  }
  if (msg.tipo === 'MOSTRAR_SIDEBAR_POS_SCREENSHOT') {
    const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
    if (iframe) iframe.style.visibility = '';
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

// Mensagens vindas DA sidebar
window.addEventListener('message', async (ev) => {
  if (ev.data?.pinguimTipo === 'FECHAR_SIDEBAR') {
    if (sempreFixa) {
      sempreFixa = false;
      await new Promise(r => chrome.storage.local.set({ sempreFixa: false }, r));
    }
    fecharSidebar(true);
  }
  if (ev.data?.pinguimTipo === 'SET_FIXA') {
    sempreFixa = !!ev.data.valor;
    await new Promise(r => chrome.storage.local.set({ sempreFixa }, r));
  }
  if (ev.data?.pinguimTipo === 'RECARREGAR_PAGINA') {
    location.reload();
  }
  if (ev.data?.pinguimTipo === 'EXPANDIR_SIDEBAR') {
    const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
    if (iframe) {
      iframe.style.width = '80vw';
      iframe.style.minWidth = '720px';
      iframe.style.maxWidth = '1400px';
    }
  }
  if (ev.data?.pinguimTipo === 'RECOLHER_SIDEBAR') {
    const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
    if (iframe) {
      iframe.style.width = '420px';
      iframe.style.minWidth = '';
      iframe.style.maxWidth = '';
    }
  }
  // v0.31.0 — estado colapsado (só ícones de squad)
  if (ev.data?.pinguimTipo === 'COLAPSAR_SIDEBAR') {
    const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
    if (iframe) {
      iframe.style.width = '64px';
      iframe.style.minWidth = '';
      iframe.style.maxWidth = '';
    }
  }
  // v0.23.2 — sidebar pede pra abrir uma conversa específica no WhatsApp Web
  // Responde de volta pra sidebar com sucesso/falha (assim o modal só fecha quando deu certo)
  if (ev.data?.pinguimTipo === 'ABRIR_CONVERSA_WHATSAPP') {
    const alvo = (ev.data.nome || '').trim();
    const respId = ev.data.respId;
    function responder(ok, motivo) {
      try {
        const iframe = document.getElementById(SIDEBAR_IFRAME_ID);
        iframe?.contentWindow?.postMessage({
          pinguimTipo: 'ABRIR_CONVERSA_WHATSAPP_RESP',
          respId, ok, motivo,
        }, '*');
      } catch (_) {}
    }
    if (!alvo) return responder(false, 'nome vazio');
    if (!location.hostname.includes('whatsapp.com')) {
      return responder(false, 'aba ativa não é o WhatsApp Web');
    }
    try {
      const aside = document.querySelector('div[aria-label="Lista de conversas"]')
        || document.querySelector('div[aria-label="Chat list"]')
        || document.querySelector('#pane-side');
      if (!aside) return responder(false, 'painel de conversas não encontrado');

      function norm(s) {
        return (s || '').toLowerCase()
          .normalize('NFD').replace(/[̀-ͯ]/g, '')
          .replace(/\s+/g, ' ').trim();
      }
      const alvoNorm = norm(alvo);

      const items = aside.querySelectorAll('div[role="listitem"], div[role="row"]');
      let achouExato = null, achouPrefix = null, achouContem = null;
      for (const item of items) {
        const tituloEl = item.querySelector('span[title]');
        const nome = tituloEl ? (tituloEl.getAttribute('title') || '').trim() : '';
        if (!nome) continue;
        const nomeNorm = norm(nome);
        if (nomeNorm === alvoNorm) { achouExato = item; break; }
        if (!achouPrefix && nomeNorm.startsWith(alvoNorm)) achouPrefix = item;
        if (!achouContem && nomeNorm.includes(alvoNorm)) achouContem = item;
      }
      const achou = achouExato || achouPrefix || achouContem;
      if (!achou) {
        return responder(false, `"${alvo}" não está visível na lista — role o painel esquerdo do WhatsApp e tente de novo`);
      }
      const alvoClick = achou.querySelector('[role="button"], [tabindex]') || achou;
      alvoClick.scrollIntoView({ block: 'center', behavior: 'instant' });
      alvoClick.click();
      responder(true, null);
    } catch (e) {
      responder(false, 'erro ao clicar: ' + (e?.message || e));
    }
  }
});

// Ctrl+B abre/fecha
window.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && (e.key === 'b' || e.key === 'B') && !e.shiftKey && !e.altKey) {
    e.preventDefault();
    e.stopPropagation();
    toggleSidebar();
  }
}, true);

// Mudanca de aba ou pagina recarregada: respeita "sempre fixa"
// v0.22.3: só remonta se aba está visível
chrome.storage.onChanged.addListener((mudancas) => {
  if (mudancas.sempreFixa) {
    sempreFixa = !!mudancas.sempreFixa.newValue;
    if (sempreFixa && !sidebarVisivel && document.visibilityState === 'visible') {
      abaFoiFocada = true;
      abrirSidebar();
    }
  }
});
